"""Forward-looking tools: the what-if planner (a one-year pro forma ranked against today's peers) and the
early-warning flags (capital, asset quality, earnings, liquidity, rate sensitivity, growth).

Planner method (shown to the user on the Plan page):
  * Start from the latest quarter: balances at quarter end, income and expense year-to-date annualized
    (the same convention as the ratio library).
  * Apply the plan for the next 12 months: balance growth, changes in loan yield, other asset yield and cost of
    funds, growth in non-interest income and operating expense, and a provision rate. Average balances grow with
    the plan; borrowings fill any funding gap; net income goes to capital (banks keep their dividend payout).
  * Each projected ratio = today's library value + the change the model shows. This keeps every ratio on the
    exact definition the peers are ranked on, and a plan with no changes returns today's values exactly.
  * The projected value is ranked against the peers' values today ("if peers stood still").
"""
import math

import numpy as np

import analyzer
import formula as F

NAN = float('nan')

# --------------------------------------------------------------------------- base figures
_BASE = {
    'cu': dict(A='[010]', L='[025B]', D='[018]', B='nz([860C])', E='[997]',
               avgA='avg([010])', avgL='avg([025B])', avgF='avg([018] + nz([860C]))', avgE='avg([997])',
               LII='ann([110] - nz([119]))', II='ann([115])', IE='ann([350])',
               PROV='ann(nz([300]) + nz([IS0017]))', NONII='ann([117])', OPEX='ann([671])', NI='ann([661A])',
               gN='yoy([117])', gO='yoy([671])'),
    'bank': dict(A='[ASSET]', L='[LNLSGR]', D='[DEP]', B='nz([OTHBOR])', E='[EQ]',
                 avgA='[ASSET5]', avgL='[LNLSGR5]', avgF='[DEP5] + nz([OBOR5])', avgE='[EQ5]', EA='[ERNAST5]',
                 LII='ann([ILNLS])', II='ann([INTINC])', IE='ann([EINTEXP])', PROV='ann([ELNATR])',
                 NONII='ann([NONII])', OPEX='ann([NONIX])', PRETAX='ann([IBEFTAX])', TAX='ann([ITAX])',
                 NI='ann([NETINC])', DIV='ann(nz([EQCDIV]))', gN='yoy([NONII])', gO='yoy([NONIX])'),
}
GROWTH = {'cu': ('asset_growth', 'loan_growth', 'share_growth'), 'bank': ('asset_growth', 'loan_growth', 'deposit_growth')}

# projected ratios: library key -> model function of a state (delta method), or a driver (growth, ranked as is)
_RATIOS = {
    'cu': [('asset_growth', 'gA'), ('loan_growth', 'gL'), ('share_growth', 'gD'),
           ('roa', lambda s: s['NI'] / s['avgA']), ('roe', lambda s: s['NI'] / s['avgE']),
           ('nim', lambda s: (s['LII'] + s['OII'] - s['IE']) / s['avgA']),
           ('yield_loans', lambda s: s['LII'] / s['avgL']), ('cost_of_funds', lambda s: s['IE'] / s['avgF']),
           ('nonint_income', lambda s: s['NONII'] / s['avgA']), ('opex_ratio', lambda s: s['OPEX'] / s['avgA']),
           ('efficiency', lambda s: s['OPEX'] / (s['LII'] + s['OII'] - s['IE'] + s['NONII'])),
           ('provision_assets', lambda s: s['PROV'] / s['avgA']), ('net_worth', lambda s: s['E'] / s['A']),
           ('loan_to_share', lambda s: s['L'] / s['D']), ('borrowings_assets', lambda s: s['B'] / s['A'])],
    'bank': [('asset_growth', 'gA'), ('loan_growth', 'gL'), ('deposit_growth', 'gD'),
             ('roaa', lambda s: s['NI'] / s['avgA']), ('roae', lambda s: s['NI'] / s['avgE']),
             ('nim', lambda s: (s['LII'] + s['OII'] - s['IE']) / s['avgEA']),
             ('yield_loans', lambda s: s['LII'] / s['avgL']), ('cost_funding', lambda s: s['IE'] / s['avgEA']),
             ('nonint_income', lambda s: s['NONII'] / s['avgA']), ('nonint_expense', lambda s: s['OPEX'] / s['avgA']),
             ('efficiency', lambda s: s['OPEX'] / (s['LII'] + s['OII'] - s['IE'] + s['NONII'])),
             ('provision_assets', lambda s: s['PROV'] / s['avgA']), ('equity_assets', lambda s: s['E'] / s['A']),
             ('leverage', lambda s: s['E'] / s['A']),
             ('loans_deposits', lambda s: s['L'] / s['D']), ('borrowings_assets', lambda s: s['B'] / s['A'])],
}
DRIVERS = [  # key, label, unit ('pct' = percent per year, 'bp' = basis points)
    ('gA', 'Asset growth', 'pct'), ('gL', 'Loan growth', 'pct'), ('gD', 'Share / deposit growth', 'pct'),
    ('dYL', 'Change in loan yield', 'bp'), ('dYO', 'Change in yield on other assets', 'bp'),
    ('dCOF', 'Change in cost of funds', 'bp'), ('gN', 'Non-interest income growth', 'pct'),
    ('gO', 'Operating expense growth', 'pct'), ('prov', 'Provision / average loans', 'pct'),
]


def _ev(an, subj, period, text):
    try:
        v = an.formula(text).eval(F.MergedCtx(an.store, period, subj['ids']))
    except (F.FormulaError, KeyError, ZeroDivisionError):
        return NAN
    v = float(v) if v is not None and np.ndim(v) == 0 else NAN
    return v if math.isfinite(v) else NAN


def _primary(an, req, period, subj):
    groups = analyzer._build_groups(an, subj, req.get('groups') or [{'preset': 'default' if subj else 'national'}], period)
    g = next((g for g in groups if g['type'] == 'group' and g['kind'] == an.kind), None)
    if g is None:
        g = analyzer._build_groups(an, subj, [{'preset': 'default'}], period)[0]
    return g


def base_state(an, subj, period):
    b = {k: _ev(an, subj, period, t) for k, t in _BASE[an.kind].items()}
    for k in ('A', 'L', 'D', 'avgA', 'avgL', 'avgF', 'II', 'LII', 'IE', 'NONII', 'OPEX', 'NI', 'E'):
        if not math.isfinite(b.get(k, NAN)):
            raise ValueError('This institution does not report enough data for a plan this quarter.')
    for k in ('B', 'PROV', 'DIV'):
        if not math.isfinite(b.get(k, 0.0)):
            b[k] = 0.0
    b['OII'] = b['II'] - b['LII']
    b['avgEA'] = b.get('EA', NAN) if math.isfinite(b.get('EA', NAN)) else b['avgA']
    if not math.isfinite(b['avgE']) or b['avgE'] <= 0:
        b['avgE'] = b['E']
    return b


def defaults(an, subj, period, b):
    """Last year's pace: actual growth, rates unchanged, today's provision rate."""
    def clip(v, lo=-0.5, hi=1.0):
        return float(min(max(v, lo), hi)) if math.isfinite(v) else 0.0
    gA, gL, gD = (clip(an.subject_value(subj, k, period)) for k in GROWTH[an.kind])
    return dict(gA=gA, gL=gL, gD=gD, dYL=0.0, dYO=0.0, dCOF=0.0, gN=clip(b.get('gN', NAN)), gO=clip(b.get('gO', NAN)),
                prov=float(b['PROV'] / b['avgL']) if b['avgL'] > 0 else 0.0)


def project(kind, b, d):
    """One year forward. d: drivers (fractions; bp drivers already converted to fractions)."""
    gA, gL, gD = d['gA'], d['gL'], d['gD']
    s = dict(A=b['A'] * (1 + gA), L=b['L'] * (1 + gL), D=b['D'] * (1 + gD))
    s['avgA'], s['avgL'] = b['avgA'] * (1 + gA), b['avgL'] * (1 + gL)
    s['avgEA'] = b['avgEA'] * (1 + gA)
    other_liab = b['A'] - b['D'] - b['B'] - b['E']               # held at today's level
    if kind == 'bank':
        calc0 = b['LII'] + b['OII'] - b['IE'] - b['PROV'] + b['NONII'] - b['OPEX']
        pre = b.get('PRETAX', NAN)
        pre = pre if math.isfinite(pre) else calc0
        tax0 = b.get('TAX', NAN)
        t = min(max(tax0 / pre, 0.0), 0.35) if math.isfinite(tax0) and pre > 0 else 0.0
        other_pre = pre - calc0                                    # securities gains and other items, held
        after = b['NI'] - (pre - (tax0 if math.isfinite(tax0) else 0.0))
        payout = min(max(b['DIV'] / b['NI'], 0.0), 1.0) if b['NI'] > 0 else 0.0
    else:
        other0 = b['NI'] - (b['LII'] + b['OII'] - b['IE'] - b['PROV'] + b['NONII'] - b['OPEX'])
    nonloan0, nonloan1 = b['avgA'] - b['avgL'], s['avgA'] - s['avgL']
    s['LII'] = b['LII'] * (1 + gL) + s['avgL'] * d['dYL']
    s['OII'] = (b['OII'] * nonloan1 / nonloan0 if nonloan0 > 0 else b['OII']) + max(nonloan1, 0) * d['dYO']
    s['PROV'] = s['avgL'] * d['prov']
    s['NONII'] = b['NONII'] * (1 + d['gN'])
    s['OPEX'] = b['OPEX'] * (1 + d['gO'])
    E1 = b['E']
    for _ in range(6):                                             # borrowings <-> interest expense <-> capital
        s['B'] = max(0.0, s['A'] - s['D'] - E1 - other_liab)
        f0, f1 = b['D'] + b['B'], s['D'] + s['B']
        s['avgF'] = b['avgF'] * (f1 / f0) if f0 > 0 else b['avgF']
        s['IE'] = b['IE'] * (s['avgF'] / b['avgF'] if b['avgF'] > 0 else 1) + s['avgF'] * d['dCOF']
        calc = s['LII'] + s['OII'] - s['IE'] - s['PROV'] + s['NONII'] - s['OPEX']
        if kind == 'bank':
            s['PRETAX'] = calc + other_pre
            s['TAX'] = s['PRETAX'] * t
            s['NI'] = s['PRETAX'] - s['TAX'] + after
            s['DIV'] = payout * max(s['NI'], 0.0)
        else:
            s['NI'] = calc + other0
            s['DIV'] = 0.0
        E1 = b['E'] + s['NI'] - s['DIV']
    s['E'] = E1
    s['avgE'] = b['avgE'] * (E1 / b['E']) if b['E'] > 0 else b['avgE']
    s['funding_gap'] = s['A'] - s['D'] - E1 - other_liab
    return s


def _div(f, s):
    try:
        v = f(s)
    except ZeroDivisionError:
        return NAN
    return v if math.isfinite(v) else NAN


def plan(req):
    an = analyzer.get(req.get('type'))
    period = an.req_period(req)
    subj = an.subject(req.get('subject'), period)
    if subj is None:
        raise ValueError('Pick an institution to build a plan.')
    g = _primary(an, req, period, subj)
    mask = g['mask0']
    mode = req.get('mode') or analyzer.DEFAULT_MODE[an.kind]
    b = base_state(an, subj, period)
    base_d = defaults(an, subj, period, b)
    given = req.get('drivers') or {}
    d = dict(base_d)
    for k, _, unit in DRIVERS:                                     # UI sends percents and basis points
        v = given.get(k)
        if v not in (None, ''):
            d[k] = float(v) / (10000.0 if unit == 'bp' else 100.0)
    p = project(an.kind, b, d)
    rows = []
    for key, fn in _RATIOS[an.kind]:
        try:
            m = an.mdef(key)
        except F.FormulaError:
            continue
        now = an.subject_value(subj, key, period)
        if isinstance(fn, str):
            new = d[fn]
        else:
            mb, mp = _div(fn, b), _div(fn, p)
            new = (now if math.isfinite(now) else mb) + (mp - mb) if math.isfinite(mp) and math.isfinite(mb) else NAN
        st0 = an.standing(key, period, mask, now)
        st1 = an.standing(key, period, mask, new)
        hib = m.get('hib')
        rows.append(dict(key=key, label=m['label'], fmt=m['fmt'], hib=hib, now=analyzer._num(now), plan=analyzer._num(new),
                         peer=analyzer._num(an.peer_value(key, period, mask, mode)),
                         median=st0['dist']['p50'] if st0['dist'] else None,
                         top25=analyzer._num(an.peer_value(key, period, mask, 'top25')) if hib is not None else None,
                         now_pct=st0['pct'], plan_pct=st1['pct'], now_rank=st0['rank'], plan_rank=st1['rank'],
                         of=st1['of'], neutral=hib is None))
    money = _proforma(an.kind, b, p)
    goal = _roa_goal(an, rows, b, p, d)
    return dict(type=an.kind, period=period, subject=subj['name'], assets=subj['assets'], group=g['name'], n=g['n'],
                note=g['note'], mode_label=analyzer.MODES.get(mode, mode),
                drivers=[dict(key=k, label=l, unit=u, value=round(d[k] * (10000 if u == 'bp' else 100), 2),
                              base=round(base_d[k] * (10000 if u == 'bp' else 100), 2)) for k, l, u in DRIVERS],
                rows=rows, money=money, goal=goal, summary=_summary(subj['name'], rows, g),
                borrowing_note=('Deposits do not cover the planned asset growth, so the plan borrows the difference '
                                f'({_usd(p["B"] - b["B"])} more borrowings).' if p['B'] - b['B'] > 0.005 * b['A'] else None))


def _usd(v):
    a = abs(v)
    s = f'${a / 1e9:,.2f}B' if a >= 1e9 else f'${a / 1e6:,.1f}M' if a >= 1e6 else f'${a:,.0f}'
    return ('-' if v < 0 else '') + s


def _proforma(kind, b, p):
    dep = 'Shares' if kind == 'cu' else 'Deposits'
    cap = 'Net worth' if kind == 'cu' else 'Equity'
    lines = [('Total assets', 'A'), ('Loans', 'L'), (dep, 'D'), ('Borrowings', 'B'), (cap, 'E'), None,
             ('Interest income on loans', 'LII'), ('Other interest income', 'OII'), ('Interest expense', 'IE'),
             ('Net interest income', lambda s: s['LII'] + s['OII'] - s['IE']), ('Provision for credit losses', 'PROV'),
             ('Non-interest income', 'NONII'), ('Operating expense', 'OPEX')]
    if kind == 'bank':
        lines += [('Income taxes', 'TAX')]
    lines += [('Net income', 'NI')]
    out = []
    for ln in lines:
        if ln is None:
            out.append(dict(label='Next 12 months (annualized)', style='h'))
            continue
        lab, k = ln
        v0 = k(b) if callable(k) else b.get(k, NAN)
        v1 = k(p) if callable(k) else p.get(k, NAN)
        out.append(dict(label=lab, now=analyzer._num(v0), plan=analyzer._num(v1),
                        chg=analyzer._num(v1 / v0 - 1) if v0 and math.isfinite(v0) and v0 > 0 else None,
                        style='b' if lab in ('Net income', 'Total assets', 'Net interest income') else ''))
    return out


def _roa_goal(an, rows, b, p, d):
    """What it takes to reach the peer group's top-quartile ROA under this plan."""
    key = 'roa' if an.kind == 'cu' else 'roaa'
    r = next((x for x in rows if x['key'] == key), None)
    if not r or r['top25'] is None or r['plan'] is None or r['now'] is None:
        return None
    gap_ratio = r['top25'] - r['plan']
    if gap_ratio <= 0:
        return dict(met=True, target=r['top25'], text=f'This plan reaches the top-quartile {r["label"]} of the peer group '
                                                     f'({r["top25"] * 100:.2f}%).')
    ni_gap = gap_ratio * p['avgA']
    pre_gap = ni_gap
    if an.kind == 'bank' and p.get('PRETAX') and p.get('TAX') is not None and p['PRETAX'] > 0:
        t = p['TAX'] / p['PRETAX']
        pre_gap = ni_gap / (1 - t) if t < 1 else ni_gap
    opex_cut = pre_gap / p['OPEX'] if p['OPEX'] > 0 else NAN
    loan_bp = pre_gap / p['avgL'] * 1e4 if p['avgL'] > 0 else NAN
    cof_bp = pre_gap / p['avgF'] * 1e4 if p['avgF'] > 0 else NAN
    return dict(met=False, target=r['top25'], ni_gap=ni_gap,
                text=(f'To reach the top-quartile {r["label"]} of {r["top25"] * 100:.2f}%, this plan needs about '
                      f'{_usd(ni_gap)} more net income a year. Any one of these would do it: cut operating expense '
                      f'{opex_cut * 100:.1f}%, raise the loan yield {loan_bp:.0f} bp, or lower the cost of funds '
                      f'{cof_bp:.0f} bp.'))


def _summary(name, rows, g):
    out = []
    ranked = [r for r in rows if not r['neutral'] and r['now_pct'] is not None and r['plan_pct'] is not None]
    if ranked:
        movers = sorted(ranked, key=lambda r: -abs(r['plan_pct'] - r['now_pct']))[:3]
        for r in movers:
            if abs(r['plan_pct'] - r['now_pct']) < 1:
                continue
            f = (lambda v: f'{v * 100:.2f}%') if r['fmt'] in ('pct', 'rate') else (lambda v: f'{v:,.2f}')
            out.append(dict(kind='gain' if r['plan_pct'] > r['now_pct'] else 'slip', text=f'{r["label"]} moves from {f(r["now"])} to {f(r["plan"])}: from the {analyzer._ord(r["now_pct"])} '
                       f'to the {analyzer._ord(r["plan_pct"])} percentile of {g["n"]} peers.'))
        avg0 = float(np.mean([r['now_pct'] for r in ranked]))
        avg1 = float(np.mean([r['plan_pct'] for r in ranked]))
        out.insert(0, dict(kind='summary', text=f'Across {len(ranked)} ranked ratios, {name} moves from the {analyzer._ord(avg0)} to the '
                      f'{analyzer._ord(avg1)} percentile on average against {g["n"]} peers ({g["name"]}), '
                      f'assuming the peers stay where they are today.'))
    return out


# --------------------------------------------------------------------------- early-warning flags
# rule: (op, threshold, reason). Thresholds are regulatory lines or widely used rules of thumb, named in the reason.
FLAGS = {
    'cu': [
        ('Capital', 'net_worth', True, dict(red=('<', 0.07, "below NCUA's 7% well-capitalized level"),
                                            yellow=('<', 0.08, "within 1 point of NCUA's 7% well-capitalized level"))),
        ('Capital', 'rbc_ratio', True, dict(red=('<', 0.10, 'below the 10% well-capitalized risk-based capital level '
                                                            'for complex credit unions'))),
        ('Capital', 'capital_vs_asset_growth', False, {}),
        ('Asset quality', 'delinquency', True, {}),
        ('Asset quality', 'net_chargeoffs', True, {}),
        ('Asset quality', 'early_delinquency', False, {}),
        ('Asset quality', 'coverage', False, {}),
        ('Earnings', 'roa', True, dict(red=('<', 0.0, 'the credit union is losing money'))),
        ('Earnings', 'efficiency', False, dict(red=('>', 1.0, 'operating expense is larger than revenue'))),
        ('Earnings', 'nim', False, {}),
        ('Liquidity', 'liquid_assets', False, dict(concern='low')),
        ('Liquidity', 'borrowings_assets', False, dict(concern='high')),
        ('Liquidity', 'loan_to_share', False, dict(concern='high', yellow=('>', 1.0, 'loans are larger than shares'))),
        ('Sensitivity to rates', 'afs_unrealized_nw', False, {}),
        ('Sensitivity to rates', 'htm_unrealized_nw', False, {}),
        ('Growth', 'asset_growth', False, dict(concern='high', yellow=('>', 0.25, 'assets grew more than 25% in a year'))),
        ('Growth', 'member_growth', False, dict(yellow=('<', 0.0, 'membership is shrinking'))),
    ],
    'bank': [
        ('Capital', 'leverage', True, dict(red=('<', 0.05, 'below the 5% well-capitalized leverage level'))),
        ('Capital', 'cet1', True, dict(red=('<', 0.065, 'below the 6.5% well-capitalized CET1 level'))),
        ('Capital', 'tier1_rbc', True, dict(red=('<', 0.08, 'below the 8% well-capitalized Tier 1 level'))),
        ('Capital', 'total_rbc', True, dict(red=('<', 0.10, 'below the 10% well-capitalized total capital level'))),
        ('Capital', 'tce_ta', False, {}),
        ('Asset quality', 'noncurrent', True, {}),
        ('Asset quality', 'nco', True, {}),
        ('Asset quality', 'npa_assets', True, {}),
        ('Asset quality', 'texas', True, dict(red=('>', 1.0, 'a Texas ratio above 100%, a common sign of distress'),
                                              yellow=('>', 0.5, 'a Texas ratio above 50%'))),
        ('Asset quality', 'reserve_coverage', False, {}),
        ('Asset quality', 'cre_capital', False, dict(yellow=('>=', 3.0, 'CRE loans at or above 300% of capital, the level '
                                                                         'named in the 2006 interagency CRE guidance'))),
        ('Asset quality', 'construction_capital', False, dict(yellow=('>=', 1.0, 'construction loans at or above 100% of '
                                                                                  'capital (2006 interagency CRE guidance)'))),
        ('Earnings', 'roaa', True, dict(red=('<', 0.0, 'the bank is losing money'))),
        ('Earnings', 'efficiency', False, dict(red=('>', 1.0, 'non-interest expense is larger than revenue'))),
        ('Earnings', 'nim', False, {}),
        ('Liquidity', 'loans_deposits', False, dict(concern='high', yellow=('>', 1.0, 'loans are larger than deposits'))),
        ('Liquidity', 'brokered_share', False, {}),
        ('Liquidity', 'wholesale_funding', False, {}),
        ('Liquidity', 'uninsured_share', False, dict(concern='high')),
        ('Sensitivity to rates', 'aoci_equity', False, {}),
        ('Sensitivity to rates', 'htm_unrealized_equity', False, {}),
        ('Growth', 'asset_growth', False, dict(concern='high', yellow=('>', 0.25, 'assets grew more than 25% in a year'))),
    ],
}
AREAS = ['Capital', 'Asset quality', 'Earnings', 'Liquidity', 'Sensitivity to rates', 'Growth']
_RANK = {'green': 0, 'yellow': 1, 'red': 2, 'none': -1}


def _hit(rule, v):
    op, x, _ = rule
    return {'<': v < x, '>': v > x, '<=': v <= x, '>=': v >= x}[op]


def _fmtv(v, fmt):
    if fmt in ('pct', 'rate'):
        return f'{v * 100:.2f}%'
    if fmt == 'x':
        return f'{v:.2f}x'
    if fmt == 'usd':
        return _usd(v)
    return f'{v:,.2f}'


def flags(req):
    an = analyzer.get(req.get('type'))
    period = an.req_period(req)
    subj = an.subject(req.get('subject'), period)
    if subj is None:
        raise ValueError('Pick an institution to see its early-warning flags.')
    g = _primary(an, req, period, subj)
    mask = g['mask0']
    mode = req.get('mode') or analyzer.DEFAULT_MODE[an.kind]
    qs = [F.shift(period, 3 * i) for i in range(4, -1, -1)]       # shift() counts months back
    qs = [q for q in qs if q in an.periods()]
    items = []
    for area, key, core, rule in FLAGS[an.kind]:
        try:
            m = an.mdef(key)
        except F.FormulaError:
            continue
        v = an.subject_value(subj, key, period)
        if not math.isfinite(v):
            continue
        hib = m.get('hib')
        st = an.standing(key, period, mask, v)
        pv = an.values(key, period)[mask]
        pv = pv[~np.isnan(pv)]
        concern = 'low' if hib else 'high' if hib is False else rule.get('concern')
        trend = [an.subject_value(subj, key, q) for q in qs]
        run = 0
        if concern:
            for a, b in zip(trend[::-1][1:], trend[::-1]):               # walk back from the latest quarter
                if not (math.isfinite(a) and math.isfinite(b)) or not (b < a if concern == 'low' else b > a):
                    break
                run += 1
        yr_worse = (concern is not None and len(trend) == 5 and all(math.isfinite(x) for x in (trend[0], trend[-1]))
                    and (trend[-1] < trend[0] if concern == 'low' else trend[-1] > trend[0]))
        status, why = 'green', []
        if rule.get('red') and _hit(rule['red'], v):
            status = 'red'
            why.append(f'{_fmtv(v, m["fmt"])}: {rule["red"][2]}.')
        elif rule.get('yellow') and _hit(rule['yellow'], v):
            status = 'yellow'
            why.append(f'{_fmtv(v, m["fmt"])}: {rule["yellow"][2]}.')
        pct = None
        if len(pv) >= 5:
            better = int((pv > v).sum() if concern == 'low' else (pv < v).sum()) if concern else 0
            ties = int((pv == v).sum())
            pct = 100.0 * (len(pv) - better - ties + ties / 2) / len(pv)     # tie-aware, 100 = best
            where = ('the worst in the peer group' if better == len(pv) else
                     f'worse than {100 - pct:.0f}% of peers')
            if hib is not None and pct <= 10:
                if core and run >= 3:                                 # bottom 10% and worse 3 quarters running
                    status = max(status, 'red', key=_RANK.get)
                    why.append(f'{where[0].upper() + where[1:]} and worse for {run} quarters in a row.')
                else:
                    status = max(status, 'yellow', key=_RANK.get)
                    why.append(f'{where[0].upper() + where[1:]}.')
            elif hib is not None and pct <= 25:
                status = max(status, 'yellow', key=_RANK.get)
                why.append('In the bottom quarter of peers.')
            elif hib is None and concern and pct <= 10:
                status = max(status, 'yellow', key=_RANK.get)
                why.append(('Higher' if concern == 'high' else 'Lower') +
                           (' than every peer.' if better == len(pv) else f' than {100 - pct:.0f}% of peers.'))
        if run >= 3 and (pct is None or pct < 50):
            why.append(f'Worse for {run} quarters in a row.')
            status = max(status, 'yellow', key=_RANK.get)
        items.append(dict(area=area, key=key, label=m['label'], fmt=m['fmt'], hib=hib, value=analyzer._num(v),
                          peer=analyzer._num(an.peer_value(key, period, mask, mode)),
                          median=st['dist']['p50'] if st['dist'] else None, pct=pct, rank=st['rank'], of=st['of'],
                          status=status, why=why, run=run, peer_pct=pct, trend=[analyzer._num(x) for x in trend],
                          desc=m.get('desc', '')))
    areas = []
    for a in AREAS:
        its = [i for i in items if i['area'] == a]
        if its:
            areas.append(dict(name=a, status=max((i['status'] for i in its), key=_RANK.get), items=its))
    reds = sum(i['status'] == 'red' for i in items)
    yellows = sum(i['status'] == 'yellow' for i in items)
    worst = [a['name'].lower() for a in areas if a['status'] == 'red']
    head = (f'{subj["name"]}: {reds} red and {yellows} yellow flags across {len(items)} indicators.'
            + (f' Red flags in {", ".join(worst)}.' if worst else ' No red flags.'))
    return dict(type=an.kind, period=period, periods=qs, subject=subj['name'], group=g['name'], n=g['n'], note=g['note'],
                mode_label=analyzer.MODES.get(mode, mode), areas=areas, reds=reds, yellows=yellows, headline=head)
