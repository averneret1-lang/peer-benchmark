"""Runs inside the visitor's browser (Pyodide, in a Web Worker). Plays the part of app.py's HTTP server.

Data files are not downloaded up front. The first time the Python code opens a file under data/, it is
fetched from the site (xz-compressed), unpacked into the in-memory file system and then read normally,
so analyzer.py, api.py, peer_report.py and the rest run unchanged.
"""
import builtins
import lzma
import io
import json
import os
import sys
import urllib.parse

HERE = '/app'
DATA = os.path.join(HERE, 'data')
BASE = ''                     # site URL of the data folder, set by setup()
MANIFEST = set()              # data files that exist on the site (paths relative to data/)
DIRS = {}                     # directory (relative) -> names inside it
META = {}                     # institution directory, quarters and coverage, built when the site is built

_open, _exists, _isfile, _isdir, _listdir = builtins.open, os.path.exists, os.path.isfile, os.path.isdir, os.listdir


def _rel(path):
    try:
        p = os.path.abspath(os.fspath(path))
    except TypeError:
        return None
    return p[len(DATA) + 1:] if p.startswith(DATA + '/') else ('' if p == DATA else None)


def _get(url):
    """Synchronous download (allowed inside a Web Worker)."""
    from js import Uint8Array, XMLHttpRequest
    xhr = XMLHttpRequest.new()
    xhr.open('GET', url, False)
    xhr.responseType = 'arraybuffer'
    xhr.send(None)
    if xhr.status != 200:
        raise OSError(f'Could not download {url} (HTTP {xhr.status})')
    return bytes(Uint8Array.new(xhr.response).to_py())


def _ensure(path):
    rel = _rel(path)
    if rel and rel in MANIFEST and not _exists(path):
        raw = lzma.decompress(_get(f'{BASE}{urllib.parse.quote(rel)}.xz'))
        d, todo = os.path.dirname(os.path.abspath(path)), []
        while not _isdir(d):              # real folders (the patched checks say the site's folders exist)
            todo.append(d)
            d = os.path.dirname(d)
        for d in reversed(todo):
            os.mkdir(d)
        with _open(path, 'wb') as f:
            f.write(raw)


def _patched_open(file, *a, **k):
    if isinstance(file, (str, bytes, os.PathLike)):
        mode = a[0] if a else k.get('mode', 'r')
        if 'r' in mode or '+' in mode:
            _ensure(file)
    return _open(file, *a, **k)


def _patched_exists(p):
    rel = _rel(p)
    return (rel is not None and (rel in MANIFEST or rel in DIRS)) or _exists(p)


def _patched_isfile(p):
    rel = _rel(p)
    return (rel is not None and rel in MANIFEST) or _isfile(p)


def _patched_isdir(p):
    rel = _rel(p)
    return (rel is not None and rel in DIRS) or _isdir(p)


def _patched_listdir(p='.'):
    rel = _rel(p)
    names = set(DIRS.get(rel, ())) if rel is not None else set()
    if _isdir(p):
        names |= set(_listdir(p))
    elif not names:
        return _listdir(p)        # raises the usual error
    return sorted(names)


def setup(base_url):
    """base_url: site URL of the data folder, ending in '/'."""
    global BASE
    BASE = base_url
    files = json.loads(lzma.decompress(_get(BASE + 'manifest.json.xz')))
    MANIFEST.update(files)
    for f in files:
        parts = f.split('/')
        for i in range(len(parts)):
            DIRS.setdefault('/'.join(parts[:i]), set()).add(parts[i])
    META.update(json.loads(lzma.decompress(_get(BASE + 'static_meta.json.xz'))))

    builtins.open = io.open = _patched_open
    os.path.exists, os.path.isfile, os.path.isdir, os.listdir = _patched_exists, _patched_isfile, _patched_isdir, _patched_listdir
    import numpy as np
    _np_load = np.load
    np.load = lambda f, mmap_mode=None, **k: _np_load(f, **k)     # no memory-mapping in the browser
    os.environ['MPLBACKEND'] = 'Agg'
    os.makedirs(os.path.join(HERE, 'output'), exist_ok=True)

    sys.path.insert(0, HERE)
    global app, api
    import api
    import app
    app.DATA.update(META['data'])
    app.STATE.update(ready=True, error=None, message='')
    api.STATE.update(ready=True, error=None, message='')
    _limit_formulas(api)
    import time
    import market                    # newest branch-deposit year = the newest one shipped (no FDIC call)
    market._mem['year'] = (META['sod_year'], time.time() + 10 ** 9)


def _limit_formulas(api):
    """The site ships the accounts the ratio library uses. Say so if a custom formula needs another one."""
    import analyzer
    check = api.POST['formula_check']

    def checked(body):
        out = check(body)
        if out.get('ok'):
            an = analyzer.get(body.get('type'))
            try:
                codes = an.formula(body.get('f') or '').codes
            except Exception:
                codes = []
            missing = [c for c in codes if not an.store.has(an.store.latest(), c)]
            if missing:
                out = {'ok': False, 'message': 'The online version includes the accounts the ratio library uses. '
                                               'Not included: ' + ', '.join(missing[:8]) + '.'}
        return out
    api.POST['formula_check'] = checked


def _json(obj, status=200):
    return status, 'application/json', json.dumps(obj)


def handle(method, url, body):
    """One request from the page. Returns (status, content_type, text or bytes)."""
    u = urllib.parse.urlsplit(url)
    path, qs = u.path, urllib.parse.parse_qs(u.query)
    data = json.loads(body) if body else {}
    if path == '/api/status':
        return _json({'ready': True, 'error': None, 'message': '', 'static': True, 'data_version': 0,
                      'notice': None, 'coverage': META['coverage']})
    if path in ('/api/ping', '/api/reveal'):
        return _json({})
    if path == '/api/refresh':
        return _json({'message': 'This online version is refreshed when the site is republished. '
                                 f'Data runs through {META["coverage"]["cu"]["through"]}.'})
    kind = 'bank' if qs.get('type', ['cu'])[0] == 'bank' else 'cu'
    if path == '/api/meta':
        return _json({'periods': app.DATA[kind]['periods'], 'states': app.DATA[kind]['states']})
    if path == '/api/search':
        return _json(app.search(kind, qs.get('q', [''])[0]))
    if path.startswith('/api/x/'):
        name = path[len('/api/x/'):]
        code, out = api.handle_get(name, qs) if method == 'GET' else api.handle_post(name, data)
        return _json(out, code)
    if path == '/api/run':
        return _json(app.run_report(data))
    if path.startswith('/files/'):
        name = os.path.basename(urllib.parse.unquote(path[len('/files/'):]))
        full = os.path.join(HERE, 'output', name)
        if not _isfile(full):
            return 404, 'text/plain', 'not found'
        ext = os.path.splitext(name)[1]
        ctype = {'.pdf': 'application/pdf', '.png': 'image/png',
                 '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'}.get(
            ext, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        with _open(full, 'rb') as f:
            return 200, ctype, f.read()
    return 404, 'text/plain', 'not found'
