"""AV's Peer Benchmark brand, shared by every file the app produces (Excel, PowerPoint, PDF)."""
import os

from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Alignment, Border, Font, Side

BRAND = 'AV’s Peer Benchmark'
NAVY, GOLD, SLATE = '14233A', 'B08D57', '535B67'
SOURCE = 'Public NCUA 5300 and FDIC call report data'
_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets')
LOGO_NAVY = os.path.join(_ASSETS, 'logo-navy.png')
LOGO_GOLD = os.path.join(_ASSETS, 'logo-gold.png')
LOCKUP = os.path.join(_ASSETS, 'lockup-navy.png')      # AV mark + 'AV’s Peer Benchmark' as one picture


def brand_workbook(wb):
    """Brand line on top of every sheet, navy tabs, print header/footer and file properties."""
    wb.properties.creator = BRAND
    wb.properties.title = wb.properties.title or BRAND
    for ws in wb.worksheets:
        frz = ws.freeze_panes
        ws.insert_rows(1)
        if os.path.exists(LOCKUP):                    # one picture renders the same in Excel, Numbers, Sheets, LibreOffice
            img = XLImage(LOCKUP)
            img.height, img.width = 26, round(26 * img.width / img.height)
            ws.add_image(img, 'A1')
        else:
            c = ws.cell(1, 1, BRAND)
            c.font = Font(name='Georgia', italic=True, bold=True, size=12, color=GOLD)
            c.alignment = Alignment(vertical='center')
        for col in range(1, max(ws.max_column, 6) + 1):
            ws.cell(1, col).border = Border(bottom=Side(style='medium', color=GOLD))
        ws.row_dimensions[1].height = 26
        if frz:                                   # insert_rows does not move the freeze line
            ws.freeze_panes = ws.cell(ws[frz].row + 1, ws[frz].column)
        ws.sheet_properties.tabColor = NAVY
        ws.oddHeader.right.text = BRAND
        ws.oddFooter.left.text = f'Prepared with {BRAND} · {SOURCE}'
        ws.oddFooter.right.text = 'Page &P of &N'
    return wb
