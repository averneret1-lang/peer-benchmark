"""Formula language for the Peer Analyzer (covers Callahan's Peer Suite operators and functions).

    [010]            a raw account: NCUA 5300 code for credit unions, FDIC field name for banks ([ASSET])
    {roa}            another library or custom metric, by key
    + - * / ^ ( )    arithmetic; division by zero gives n/a

  Time
    py(x)            same quarter last year        (Callahan x:1)
    ago(x, n)        n years back                  (x:n)
    pq(x)            prior quarter                 (x:.25)
    pdec(x)          prior year-end                (x:dec)
  Growth and change
    yoy(x)           12-month growth               (Growth)
    grow(x, n)       n-year compound annual growth (GrowthN)
    ytdg(x)          growth since prior year-end   (GrowthYTD)
    ncuag(x)         ytdg annualized, as NCUA's FPR does (GrowthNCUA)
    qg(x)            quarter-over-quarter growth   (GrowthQtr)
    qga(x)           quarterly growth compounded to a year (GrowthQtrAnn)
    chg(x) qchg(x) ytdchg(x)   absolute change vs last year / last quarter / prior year-end
  Income-statement (year-to-date) items
    ann(x)           annualize: x * 4 / quarter number   (Annual)
    ttm(x)           trailing twelve months        (FullYear)
    booked(x)        the single quarter's amount   (Booked)
    anq(x)           the single quarter, annualized (x4)
  Averages
    avg(x)           (current + prior year-end) / 2      (QtrAve)
    avgf(x)          same, falling back to current when there is no prior year-end
    avg5(x)          average of every quarter-end from prior year-end through now
  Helpers
    nz(x)  n/a -> 0      pos(x)  keep only values > 0      abs(x) min(a,b) max(a,b)
    alt(a, b)        a, or b for quarters where a's account did not exist yet (form revisions)
    if(cond, a, b)   with comparisons  > >= < <= == !=
"""
import ast
import re

import numpy as np

_ACCT = re.compile(r'\[\s*([A-Za-z0-9_]+)\s*\]')
_REF = re.compile(r'\{\s*([A-Za-z0-9_.]+)\s*\}')


class FormulaError(ValueError):
    pass


def shift(period, months):
    y, m = map(int, period.split('-'))
    t = y * 12 + (m - 1) - months
    return f'{t // 12:04d}-{t % 12 + 1:02d}'


def prior_dec(period):
    return f'{int(period[:4]) - 1:04d}-12'


def qnum(period):
    return int(period[5:7]) // 3


def _div(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    with np.errstate(divide='ignore', invalid='ignore'):
        return np.where((b != 0) & ~np.isnan(b), a / np.where(b == 0, np.nan, b), np.nan)


def expand(text, lookup, _seen=()):
    """Replace {key} references with the referenced formula (recursively)."""
    def rep(m):
        key = m.group(1)
        if key in _seen:
            raise FormulaError(f'Circular reference: {key}')
        f = lookup(key)
        if f is None:
            raise FormulaError(f'Unknown metric: {{{key}}}')
        return '(' + expand(f, lookup, _seen + (key,)) + ')'
    return _REF.sub(rep, text)


_ALLOWED_FUNCS = {'py', 'ago', 'pq', 'pdec', 'yoy', 'grow', 'ytdg', 'ncuag', 'qg', 'qga', 'chg', 'qchg', 'ytdchg',
                  'ann', 'ttm', 'booked', 'anq', 'avg', 'avgf', 'avg5', 'nz', 'pos', 'alt', 'rng', 'abs', 'min', 'max', 'IF', '_a'}
_ARITY = {'ago': 2, 'grow': 2, 'alt': 2, 'min': 2, 'max': 2, 'rng': 3, 'IF': 3}   # every other function takes 1
_NUMERIC = {'ago': (1,), 'grow': (1,), 'rng': (1, 2)}                              # argument positions that must be numbers


class Formula:
    def __init__(self, text, lookup=None):
        self.text = text
        src = expand(text, lookup) if lookup else text
        if _REF.search(src):
            raise FormulaError('Metric references {..} are not available here.')
        self.codes = sorted({m.group(1).upper() for m in _ACCT.finditer(src)})
        src = _ACCT.sub(lambda m: f'_a("{m.group(1).upper()}")', src)
        src = src.replace('^', '**')
        src = re.sub(r'\bif\s*\(', 'IF(', src, flags=re.I)
        src = re.sub(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\(', lambda m: (m.group(1) if m.group(1) in ('IF', '_a') else m.group(1).lower()) + '(', src)
        try:
            self.tree = ast.parse(src.strip(), mode='eval').body
        except SyntaxError as e:
            raise FormulaError(f'Could not read the formula near "{(e.text or "")[max((e.offset or 1) - 8, 0):(e.offset or 1) + 8].strip()}".')
        self._check(self.tree)

    def _check(self, n):
        if isinstance(n, ast.Constant):
            if not isinstance(n.value, (int, float, str)):
                raise FormulaError('Unsupported constant.')
        elif isinstance(n, ast.BinOp):
            if not isinstance(n.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow)):
                raise FormulaError('Unsupported operator.')
            self._check(n.left); self._check(n.right)
        elif isinstance(n, ast.UnaryOp):
            if not isinstance(n.op, (ast.USub, ast.UAdd)):
                raise FormulaError('Unsupported operator.')
            self._check(n.operand)
        elif isinstance(n, ast.Compare):
            if len(n.ops) != 1 or not isinstance(n.ops[0], (ast.Gt, ast.GtE, ast.Lt, ast.LtE, ast.Eq, ast.NotEq)):
                raise FormulaError('Unsupported comparison.')
            self._check(n.left); self._check(n.comparators[0])
        elif isinstance(n, ast.Call):
            if not isinstance(n.func, ast.Name) or n.func.id not in _ALLOWED_FUNCS or n.keywords:
                name = getattr(n.func, 'id', '?')
                raise FormulaError(f'Unknown function: {name}(). See the formula help for the list.')
            f, k = n.func.id, len(n.args)
            want = _ARITY.get(f, 1)
            if k != want:
                raise FormulaError(f'{f}() takes {want} argument{"s" if want > 1 else ""}, not {k}.')
            for i in _NUMERIC.get(f, ()):
                c = n.args[i]
                if not (isinstance(c, ast.Constant) and isinstance(c.value, (int, float))):
                    raise FormulaError(f'{f}() needs a plain number as argument {i + 1}.')
            if f in ('grow', 'ago') and not n.args[1].value > 0:
                raise FormulaError(f'{f}() needs a number of years above 0.')
            for a in n.args:
                self._check(a)
        elif isinstance(n, ast.Name):
            raise FormulaError(f'"{n.id}" is not recognized. Put account codes in [brackets] and metric keys in {{braces}}.')
        else:
            raise FormulaError('Unsupported expression.')

    # ---- evaluation
    def eval(self, ctx):
        """ctx.get(code, period) -> array or scalar; ctx.period -> base period."""
        with np.errstate(all='ignore'):
            return self._ev(self.tree, ctx, ctx.period)

    def periods_used(self, period):
        rec = _Recorder(period)
        self._ev(self.tree, rec, period)
        return rec.seen

    def _ev(self, n, ctx, p):
        ev = self._ev
        if isinstance(n, ast.Constant):
            return float(n.value)
        if isinstance(n, ast.UnaryOp):
            v = ev(n.operand, ctx, p)
            return -v if isinstance(n.op, ast.USub) else v
        if isinstance(n, ast.BinOp):
            a, b = ev(n.left, ctx, p), ev(n.right, ctx, p)
            if isinstance(n.op, ast.Add):
                return a + b
            if isinstance(n.op, ast.Sub):
                return a - b
            if isinstance(n.op, ast.Mult):
                return a * b
            if isinstance(n.op, ast.Div):
                return _div(a, b)
            return np.power(a, b)
        if isinstance(n, ast.Compare):
            a, b = ev(n.left, ctx, p), ev(n.comparators[0], ctx, p)
            op = n.ops[0]
            r = (a > b if isinstance(op, ast.Gt) else a >= b if isinstance(op, ast.GtE) else a < b if isinstance(op, ast.Lt)
                 else a <= b if isinstance(op, ast.LtE) else a == b if isinstance(op, ast.Eq) else a != b)
            return np.where(r, 1.0, 0.0)
        f, args = n.func.id, n.args

        def arg(i=0, at=p):
            return ev(args[i], ctx, at)

        def num(i):
            if not isinstance(args[i], ast.Constant):
                raise FormulaError(f'{f}() needs a plain number as argument {i + 1}.')
            return args[i].value

        if f == '_a':
            return ctx.get(args[0].value, p)
        if f == 'py':
            return arg(0, shift(p, 12))
        if f == 'ago':
            return arg(0, shift(p, int(round(12 * float(num(1))))))
        if f == 'pq':
            return arg(0, shift(p, 3))
        if f == 'pdec':
            return arg(0, prior_dec(p))
        if f == 'yoy':
            b = arg(0, shift(p, 12))
            return _div(arg() - b, abs_(b))
        if f == 'grow':
            yrs = float(num(1))
            b = arg(0, shift(p, int(round(12 * yrs))))
            return np.power(_div(arg(), b), 1.0 / yrs) - 1
        if f in ('ytdg', 'ncuag'):
            b = arg(0, prior_dec(p))
            g = _div(arg() - b, abs_(b))
            return g * 4 / qnum(p) if f == 'ncuag' else g
        if f in ('qg', 'qga'):
            b = arg(0, shift(p, 3))
            g = _div(arg() - b, abs_(b))
            return np.power(1 + g, 4) - 1 if f == 'qga' else g
        if f == 'chg':
            return arg() - arg(0, shift(p, 12))
        if f == 'qchg':
            return arg() - arg(0, shift(p, 3))
        if f == 'ytdchg':
            return arg() - arg(0, prior_dec(p))
        if f == 'ann':
            return arg() * 4 / qnum(p)
        if f == 'ttm':
            return arg() if qnum(p) == 4 else arg() + arg(0, prior_dec(p)) - arg(0, shift(p, 12))
        if f in ('booked', 'anq'):
            v = arg() if qnum(p) == 1 else arg() - arg(0, shift(p, 3))
            return v * 4 if f == 'anq' else v
        if f == 'avg':
            return (arg() + arg(0, prior_dec(p))) / 2
        if f == 'avgf':
            c, d = arg(), arg(0, prior_dec(p))
            return (c + np.where(np.isnan(d), c, d)) / 2
        if f == 'avg5':
            pts, q = [arg(0, prior_dec(p))], p
            for _ in range(qnum(p)):
                pts.append(arg(0, q))
                q = shift(q, 3)
            return np.nanmean(np.vstack([np.atleast_1d(x) for x in pts]), axis=0) if np.ndim(pts[0]) else float(np.nanmean(pts))
        if f == 'nz':
            return np.nan_to_num(arg(), nan=0.0, posinf=0.0, neginf=0.0)
        if f == 'alt':                 # first argument, or the second where the first is not on the form
            a, b = arg(0), arg(1)
            return np.where(np.isnan(a), b, a)
        if f == 'rng':                 # drop implausible filings (keying errors) outside [lo, hi]
            v = arg(0)
            return np.where((v >= num(1)) & (v <= num(2)), v, np.nan)
        if f == 'pos':
            v = arg()
            return np.where(v > 0, v, np.nan)
        if f == 'abs':
            return np.abs(arg())
        if f == 'min':
            return np.minimum(arg(0), arg(1))
        if f == 'max':
            return np.maximum(arg(0), arg(1))
        if f == 'IF':
            return np.where(arg(0) != 0, arg(1), arg(2))
        raise FormulaError(f'Unknown function {f}')


def abs_(x):
    return np.abs(x)


class _Recorder:
    def __init__(self, period):
        self.period = period
        self.seen = {period}

    def get(self, code, p):
        self.seen.add(p)
        return 1.0


class VectorCtx:
    """Per-institution evaluation over every institution filing in `period`."""

    def __init__(self, store, period):
        self.store, self.period = store, period

    def get(self, code, p):
        return self.store.aligned(self.period, code, p)


class AggCtx:
    """Callahan-style peer aggregate: sum each account across the members, then apply the formula.
    Members are limited to those that filed in every quarter the formula touches (like-for-like)."""

    def __init__(self, store, period, mask, periods_used):
        self.store, self.period = store, period
        m = mask.copy()
        for p in periods_used:
            if p != period and store.exists(p):
                m &= store.present(period, p)
        self.mask = m
        self.n = int(m.sum())

    def get(self, code, p):
        if not self.store.has(p, code) or self.n == 0:
            return np.nan
        return float(np.nansum(self.store.aligned(self.period, code, p)[self.mask]))


class MergedCtx:
    """A hypothetical merger: member accounts summed in every quarter (no like-for-like restriction)."""

    def __init__(self, store, period, ids):
        self.store, self.period, self.ids = store, period, [str(i) for i in ids]
        self._masks = {}

    def get(self, code, p):
        if not self.store.has(p, code):
            return np.nan
        m = self._masks.get(p)
        if m is None:
            import pandas as pd
            pos = pd.Index(self.store.ids(p)).get_indexer(self.ids)
            m = np.zeros(len(self.store.ids(p)), dtype=bool)
            m[pos[pos >= 0]] = True
            self._masks[p] = m
        if not m.any():
            return np.nan
        return float(np.nansum(self.store.col(p, code)[m]))
