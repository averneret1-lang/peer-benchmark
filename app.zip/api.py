"""HTTP glue for the AV's Peer Benchmark workspace: JSON endpoints under /api/x/ and Excel export."""
import os
import re
import threading
import traceback

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

import brand  # noqa: E402
import analyzer
import formula as F
import market
import wide_store

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'output')
LOCK = threading.RLock()
STATE = {'ready': False, 'message': 'Preparing the full call report library (first run only)...', 'error': None}


def prepare(log=print):
    """Build any missing wide-store quarters, then mark the analyzer ready."""
    try:
        with LOCK:
            wide_store.build_all(log=lambda m: (STATE.update(message=m), log(m)))
            analyzer.Analyzer.reset_all()
        STATE.update(ready=True, message='', error=None)
    except Exception as e:
        STATE.update(ready=False, error=f'{type(e).__name__}: {e}')
        log('analyzer prepare failed: ' + traceback.format_exc())


def refresh(log=print):
    """After the updater pulled new data: index new NCUA quarters and re-pull the newest FDIC quarters."""
    with LOCK:
        built = wide_store.build_all(log=log, refresh_recent=True)
        analyzer.Analyzer.reset_all()
    return built


def _analyze(req):
    res = analyzer.analyze(req)
    if req.get('insights'):
        res['insights'] = analyzer.narrative(res)
    return res


def _formula_check(req):
    ok, msg, _ = analyzer.get(req.get('type')).check_formula(req.get('f') or '')
    return {'ok': ok, 'message': msg}


def _saved(req):
    kind = 'bank' if req.get('type') == 'bank' else 'cu'
    return {'peers': analyzer.saved_list('peer_groups', kind), 'dashboards': analyzer.saved_list('dashboards', kind)}


def _save(req):
    kind = 'bank' if req.get('type') == 'bank' else 'cu'
    what = {'peers': 'peer_groups', 'dashboards': 'dashboards'}[req['what']]
    if req.get('delete'):
        analyzer.saved_delete(what, kind, req['delete'])
    else:
        analyzer.saved_put(what, kind, req['item'])
    return _saved(req)


def _formula_save(req):
    kind = 'bank' if req.get('type') == 'bank' else 'cu'
    if req.get('delete'):
        analyzer.delete_formula(kind, req['delete'])
        return {'ok': True}
    return {'ok': True, 'key': analyzer.save_formula(kind, req['item'])}


_NUMFMT = {'pct': '0.00%', 'rate': '0.00%', 'usd': '$#,##0', 'int': '#,##0', 'num': '#,##0.0', 'num2': '#,##0.00',
           'x': '0.00"x"', 'pct0': '0%', 'pct1': '0.0%'}


def export_xlsx(req):
    """req: {filename, sheets: [{name, title, subtitle, columns: [{label, fmt, width}], rows: [[...]], bold: [row idx]}]}"""
    wb = Workbook()
    wb.remove(wb.active)
    red = PatternFill('solid', fgColor='14233A')
    for sh in req.get('sheets') or []:
        ws = wb.create_sheet(re.sub(r'[\[\]\*\?/\\:]', ' ', sh.get('name') or 'Sheet')[:31])
        r0 = 1
        if sh.get('title'):
            ws.cell(1, 1, sh['title']).font = Font(bold=True, size=14, color='14233A')
            r0 = 2
        for line in ([sh['subtitle']] if isinstance(sh.get('subtitle'), str) else sh.get('subtitle') or []):
            ws.cell(r0, 1, line).font = Font(italic=True, color='535B67')
            r0 += 1
        if r0 > 1:
            r0 += 1
        cols = sh.get('columns') or []
        for j, c in enumerate(cols, 1):
            cell = ws.cell(r0, j, c.get('label'))
            cell.fill, cell.font = red, Font(bold=True, color='FFFFFF')
            cell.alignment = Alignment(wrap_text=True, vertical='top', horizontal='left' if j == 1 else 'right')
            ws.column_dimensions[get_column_letter(j)].width = c.get('width') or (34 if j == 1 else 15)
        bold = set(sh.get('bold') or [])
        for i, row in enumerate(sh.get('rows') or []):
            for j, v in enumerate(row, 1):
                fmt = None
                if isinstance(v, dict):                 # per-cell format: {v, fmt}
                    v, fmt = v.get('v'), v.get('fmt')
                cell = ws.cell(r0 + 1 + i, j, v)
                fmt = fmt or (cols[j - 1].get('fmt') if j <= len(cols) else None)
                if isinstance(v, (int, float)) and fmt in _NUMFMT:
                    cell.number_format = _NUMFMT[fmt]
                if i in bold:
                    cell.font = Font(bold=True)
        ws.freeze_panes = ws.cell(r0 + 1, 2)
    if not wb.sheetnames:
        wb.create_sheet('Sheet')
    name = re.sub(r'[^\w\-. ()&,]+', ' ', req.get('filename') or 'AV’s Peer Benchmark export').strip()[:120] or 'export'
    os.makedirs(OUT, exist_ok=True)
    brand.brand_workbook(wb)
    wb.save(os.path.join(OUT, name + '.xlsx'))
    return {'name': name + '.xlsx'}


def _pptx(req):
    import pptx_lite
    name = re.sub(r'[^\w\-. ()&,]+', ' ', req.get('filename') or 'AV’s Peer Benchmark').strip()[:120] or 'deck'
    os.makedirs(OUT, exist_ok=True)
    pptx_lite.build(os.path.join(OUT, name + '.pptx'), req.get('slides') or [])
    return {'name': name + '.pptx'}


POST = {
    'analyze': _analyze, 'table': analyzer.table, 'scatter': analyzer.scatter, 'statements': analyzer.statements,
    'callreport': analyzer.callreport, 'rom': analyzer.rom, 'peers': analyzer.peers_preview,
    'market': market.analyze, 'formula_check': _formula_check, 'formula_save': _formula_save,
    'saved': _saved, 'save': _save, 'export': export_xlsx, 'pptx': _pptx,
}


def handle_post(name, body):
    fn = POST.get(name)
    if fn is None:
        return 404, {'error': 'not found'}
    if not STATE['ready'] and name not in ('export', 'pptx'):
        return 503, {'error': STATE['error'] or STATE['message'] or 'Still preparing data.', 'preparing': True}
    try:
        with LOCK:
            return 200, fn(body)
    except (ValueError, F.FormulaError, KeyError) as e:
        msg = str(e) if not isinstance(e, KeyError) else f'Missing field: {e}'
        return 200, {'error': msg}
    except Exception as e:
        traceback.print_exc()
        return 200, {'error': f'{type(e).__name__}: {e}'}


def handle_get(name, qs):
    g = lambda k, d='': qs.get(k, [d])[0]
    if name == 'state':
        return 200, STATE
    if not STATE['ready']:
        return 503, {'error': STATE['error'] or STATE['message'], 'preparing': True}
    try:
        with LOCK:
            if name == 'lib':
                return 200, analyzer.lib(g('type', 'cu'))
            if name == 'search':
                return 200, analyzer.get(g('type', 'cu')).search(g('q'), int(g('limit', '15')))
            if name == 'codes':
                return 200, analyzer.code_search(g('type', 'cu'), g('q'))
            if name == 'counties':
                return 200, market.counties(g('state').upper())
            if name == 'footprint':
                return 200, market.footprint(g('type', 'cu'), g('id'))
    except Exception as e:
        traceback.print_exc()
        return 200, {'error': f'{type(e).__name__}: {e}'}
    return 404, {'error': 'not found'}
