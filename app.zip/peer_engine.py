"""Callahan Peer-style credit union benchmarking engine built on public NCUA 5300 data.

Conventions follow Callahan's Peer Suite Functions Manual (Feb 2023):
  - Growth          = year over year: (x - x[same quarter last year]) / x[same quarter last year]
  - Income items    = YTD annualized: x * 4 / quarter_number
  - Averages        = (x + x[prior December]) / 2
  - Peer value      = accounts summed across the peer group, then the ratio is taken
                      (dollar-weighted, like Callahan; peer median shown alongside)

Data: NCUA quarterly zips in data/ncua_cache (call-report-data-YYYY-MM.zip); see bootstrap.py.
"""
import re
import glob
import os
import zipfile

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
try:
    from local_paths import NCUA_CACHE as _LOCAL_CACHE      # optional, machine-specific (see local_paths.py)
except ImportError:
    _LOCAL_CACHE = None
NCUA_CACHE = os.environ.get('NCUA_CACHE') or _LOCAL_CACHE or os.path.join(HERE, 'data', 'ncua_cache')
PANEL_PATH = os.path.join(HERE, 'data', 'panel.pkl')

# 5300 account codes the metrics need (verified against AcctDesc.txt, 2026-03).
ACCOUNTS = {
    '010': 'Total assets', '018': 'Total shares & deposits',
    '025A': 'Number of loans', '025B': 'Total loans', '083': 'Members',
    '997': 'Net worth', 'NW0004': 'CECL transition provision',
    '041B': 'Delinquent loans (60+ days)', '550': 'YTD charge-offs', '551': 'YTD recoveries',
    '719': 'Allowance for loan losses (incurred)', 'AS0048': 'Allowance for credit losses (CECL)',
    '452': 'Number of share draft accounts', '958': 'Number of new vehicle loans',
    '968': 'Number of used vehicle loans', '115': 'YTD interest income',
    '350': 'YTD interest expense', '117': 'YTD non-interest income', '131': 'YTD fee income',
    'IS0020': 'YTD other operating income',
    '671': 'YTD non-interest expense', '661A': 'YTD net income',
    '564A': 'Full-time employees', '564B': 'Part-time employees',
    # Funding mix and cost
    '657': 'Regular shares', '902': 'Share drafts', '908C': 'Share certificates', '860C': 'Total borrowings',
    '459': 'Brokered deposits', '380': 'YTD dividends on shares', '381': 'YTD interest on deposits',
}
FOICU_COLS = ['CU_NUMBER', 'CU_NAME', 'CITY', 'STATE', 'Peer_Group', 'REGION']

# Callahan-style asset tiers (published tiers not confirmed; these are the commonly cited bands).
TIERS = [(0, 100e6, '< $100M'), (100e6, 250e6, '$100M-$250M'), (250e6, 500e6, '$250M-$500M'),
         (500e6, 1e9, '$500M-$1B'), (1e9, 10e9, '$1B-$10B'), (10e9, float('inf'), '> $10B')]
NCUA_PEER_GROUPS = {'1': '< $2M', '2': '$2M-$10M', '3': '$10M-$50M',
                    '4': '$50M-$100M', '5': '$100M-$500M', '6': '> $500M'}


# --------------------------------------------------------------------------- panel

def _read_zip(path):
    period = os.path.basename(path)[len('call-report-data-'):-4]  # YYYY-MM
    want = {'ACCT_' + c for c in ACCOUNTS}
    frames = []
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if not name.upper().startswith('FS220'):
                continue
            header = z.open(name).readline().decode('latin-1').strip().replace('"', '').split(',')
            if not any(c.upper() in want for c in header):
                continue
            df = pd.read_csv(z.open(name), encoding='latin-1', dtype=str,
                             usecols=lambda c: c.strip().lstrip('﻿').upper() in want | {'CU_NUMBER'})
            df.columns = [c.strip().lstrip('﻿').upper() for c in df.columns]
            frames.append(df.set_index('CU_NUMBER'))
        info = pd.read_csv(z.open('FOICU.txt'), encoding='latin-1', dtype=str,
                           usecols=FOICU_COLS).set_index('CU_NUMBER')
    acc = pd.concat(frames, axis=1)
    acc = acc.loc[:, ~acc.columns.duplicated()]
    acc.columns = [c.replace('ACCT_', '') for c in acc.columns]
    acc = acc.apply(pd.to_numeric, errors='coerce')
    for c in ACCOUNTS:
        if c not in acc.columns:
            acc[c] = np.nan
    out = info.join(acc, how='left')
    out['period'] = period
    return out.reset_index()


def build_panel(force=False):
    """Read every cached NCUA zip into one CU x quarter frame (cached as a pickle)."""
    zips = sorted(glob.glob(os.path.join(NCUA_CACHE, 'call-report-data-*.zip')))
    if not force and os.path.exists(PANEL_PATH):
        cached = pd.read_pickle(PANEL_PATH)
        if not zips:                         # packaged build (website): the panel ships without the source zips
            return cached
        if (set(cached['period'].unique()) == {os.path.basename(z)[17:24] for z in zips}
                and set(ACCOUNTS) <= set(cached.columns)):
            return cached
    panel = pd.concat([_read_zip(z) for z in zips], ignore_index=True)
    panel['CU_NAME'] = panel['CU_NAME'].str.strip()
    os.makedirs(os.path.dirname(PANEL_PATH), exist_ok=True)
    panel.to_pickle(PANEL_PATH)
    return panel


# --------------------------------------------------------------------------- metrics

def _lag_period(period, months):
    y, m = map(int, period.split('-'))
    t = y * 12 + (m - 1) - months
    return f'{t // 12:04d}-{t % 12 + 1:02d}'


def prior_year(period):
    return _lag_period(period, 12)


def prior_dec(period):
    return f'{int(period[:4]) - 1:04d}-12'


def _safe(n, d):
    n = np.asarray(n, dtype=float)
    d = np.asarray(d, dtype=float)
    with np.errstate(divide='ignore', invalid='ignore'):
        r = np.where((d != 0) & ~np.isnan(d), n / d, np.nan)
    return r


def _allowance(a):
    # A credit union reports one or the other (CECL adopters AS0048, the rest 719). Adding them is the same
    # per institution, and is the only form that is right for a peer group that mixes both kinds.
    return a['AS0048'].astype(float).fillna(0) + a['719'].astype(float).fillna(0)


# name -> (label, format, higher_is_better, function(cur, py, dec, ann))
# cur/py/dec are DataFrames of 5300 accounts aligned on the same index; ann is 4/q.
METRICS = {
    'assets':        ('Total assets', 'usd', True, lambda c, p, d, k: c['010']),
    'share_growth':  ('Share growth (YoY)', 'pct', True, lambda c, p, d, k: _safe(c['018'] - p['018'], p['018'])),
    'loan_growth':   ('Loan growth (YoY)', 'pct', True, lambda c, p, d, k: _safe(c['025B'] - p['025B'], p['025B'])),
    'asset_growth':  ('Asset growth (YoY)', 'pct', True, lambda c, p, d, k: _safe(c['010'] - p['010'], p['010'])),
    'member_growth': ('Member growth (YoY)', 'pct', True, lambda c, p, d, k: _safe(c['083'] - p['083'], p['083'])),
    'roa':           ('ROA', 'pct', True, lambda c, p, d, k: _safe(c['661A'] * k, (c['010'] + d['010']) / 2)),
    'nim':           ('Net interest margin (avg assets)', 'pct', True,
                      lambda c, p, d, k: _safe((c['115'] - c['350']) * k, (c['010'] + d['010']) / 2)),
    # Operating income = fee income + other operating income (excludes gains/losses in 117).
    # Ties exactly to FedFis's efficiency ratio; matches Callahan's "fee + other operating income".
    'nonint_income': ('Fee & other op. income / avg assets', 'pct', True,
                      lambda c, p, d, k: _safe((c['131'] + c['IS0020']) * k, (c['010'] + d['010']) / 2)),
    'opex_ratio':    ('Operating expense / avg assets', 'pct', False,
                      lambda c, p, d, k: _safe(c['671'] * k, (c['010'] + d['010']) / 2)),
    'efficiency':    ('Efficiency ratio', 'pct', False,
                      lambda c, p, d, k: _safe(c['671'], c['115'] - c['350'] + c['131'] + c['IS0020'])),
    'net_worth':     ('Net worth ratio', 'pct', True,
                      lambda c, p, d, k: _safe(c['997'] - c['NW0004'].fillna(0), c['010'] - c['NW0004'].fillna(0))),
    'loan_to_share': ('Loan-to-share', 'pct', None, lambda c, p, d, k: _safe(c['025B'], c['018'])),
    'delinquency':   ('Delinquency (60+ days)', 'pct', False, lambda c, p, d, k: _safe(c['041B'], c['025B'])),
    'net_chargeoffs': ('Net charge-offs (annualized)', 'pct', False,
                       lambda c, p, d, k: _safe((c['550'] - c['551']) * k, (c['025B'] + d['025B']) / 2)),
    'coverage':      ('Allowance / delinquent loans', 'x', True, lambda c, p, d, k: _safe(_allowance(c), c['041B'])),
    'members':       ('Members', 'int', True, lambda c, p, d, k: c['083']),
    'avg_relationship': ('Avg member relationship', 'usd', True,
                         lambda c, p, d, k: _safe(c['025B'] + c['018'], c['083'])),
    'avg_share':     ('Avg share balance per member', 'usd', True, lambda c, p, d, k: _safe(c['018'], c['083'])),
    'avg_loan':      ('Avg loan balance', 'usd', True, lambda c, p, d, k: _safe(c['025B'], c['025A'])),
    'members_per_fte': ('Members per FTE', 'num', True,
                        lambda c, p, d, k: _safe(c['083'], c['564A'] + c['564B'] / 2)),
    'draft_penetration': ('Share draft penetration', 'pct', True, lambda c, p, d, k: _safe(c['452'], c['083'])),
    'auto_penetration': ('Auto loan penetration*', 'pct', True,
                         lambda c, p, d, k: _safe(c['958'].fillna(0) + c['968'].fillna(0), c['083'])),
}
ACCT_COLS = list(ACCOUNTS)


def _frames(panel, period, index=None):
    """Account frames for the period, its prior-year quarter and prior December, keyed by CU_NUMBER."""
    def get(p):
        f = panel[panel['period'] == p].set_index('CU_NUMBER')[ACCT_COLS]
        return f.reindex(index) if index is not None else f
    cur = get(period)
    idx = cur.index if index is None else index
    return cur, get(prior_year(period)).reindex(idx), get(prior_dec(period)).reindex(idx)


def annual_factor(period):
    return 4 / (int(period[5:7]) // 3)


def cu_metrics(panel, period):
    """One row per CU with every metric for the period."""
    cur, py, dec = _frames(panel, period)
    k = annual_factor(period)
    out = pd.DataFrame(index=cur.index)
    for key, (_, _, _, fn) in METRICS.items():
        out[key] = np.asarray(fn(cur, py, dec, k), dtype=float)
    info = panel[panel['period'] == period].set_index('CU_NUMBER')[['CU_NAME', 'CITY', 'STATE', 'Peer_Group', 'REGION']]
    return info.join(out)


def aggregate_metrics(panel, period, members):
    """Callahan-style peer value: sum each account across the group, then compute the ratio.
    Lagged sums use only members that reported in that lag period."""
    cur, py, dec = _frames(panel, period, index=pd.Index(members, name='CU_NUMBER'))
    k = annual_factor(period)

    def summed(f):
        s = f.sum(min_count=1).to_frame().T
        return s
    c, p, d = summed(cur), summed(py), summed(dec)
    # Growth needs like-for-like sets: recompute lag-dependent sums over CUs present in both periods.
    both_py = py.dropna(subset=['010']).index
    both_dec = dec.dropna(subset=['010']).index
    c_py, c_dec = summed(cur.loc[both_py]), summed(cur.loc[both_dec])
    avg_denominator = ('roa', 'nim', 'nonint_income', 'opex_ratio', 'net_chargeoffs')
    row = {}
    for key, (_, _, _, fn) in METRICS.items():
        if key.endswith('_growth'):
            base = c_py           # CUs present now and a year ago
        elif key in avg_denominator:
            base = c_dec          # CUs present now and last December
        else:
            base = c
        row[key] = float(np.asarray(fn(base, p, d, k))[0])
    if len(members):
        row['assets'] = row['assets'] / len(members)       # average CU size, not the group total
        row['members'] = float(c['083'].iloc[0]) / len(members)
    return row


# --------------------------------------------------------------------------- peer groups

def tier_of(assets):
    for lo, hi, label in TIERS:
        if lo <= assets < hi:
            return label
    return None


def parse_money(s):
    s = s.strip().upper().replace('$', '').replace(',', '')
    mult = {'K': 1e3, 'M': 1e6, 'B': 1e9}.get(s[-1:], 1)
    return float(s[:-1] if s[-1:] in 'KMB' else s) * mult


def select_peers(metrics, subject, states=None, assets=None, tier=False, ncua_group=False,
                 cu_list=None, regions=None):
    """Filter the CU universe for one period. All filters intersect. Subject is excluded."""
    m = metrics.dropna(subset=['assets'])
    if cu_list:
        m = m[m.index.isin([str(x) for x in cu_list])]
    if states:
        m = m[m['STATE'].isin([s.strip().upper() for s in states])]
    if regions:
        m = m[m['REGION'].isin([str(r) for r in regions])]
    if assets:
        lo, hi = assets
        m = m[(m['assets'] >= lo) & (m['assets'] < hi)]
    subj = metrics.loc[subject]
    if tier:
        label = tier_of(subj['assets'])
        lo, hi = next((a, b) for a, b, l in TIERS if l == label)
        m = m[(m['assets'] >= lo) & (m['assets'] < hi)]
    if ncua_group:
        m = m[m['Peer_Group'] == subj['Peer_Group']]
    return m.drop(index=subject, errors='ignore')


def describe_peer(subj_row, states=None, assets=None, tier=False, ncua_group=False, cu_list=None, regions=None):
    parts = []
    if cu_list:
        parts.append('custom list')
    if states:
        parts.append('/'.join(s.strip().upper() for s in states))
    if regions:
        parts.append('NCUA region ' + '/'.join(map(str, regions)))
    if assets:
        lo, hi = assets
        parts.append(f'{_money(lo)}-{_money(hi)} assets' if hi != float('inf') else f'> {_money(lo)} assets')
    if tier:
        parts.append(f'{tier_of(subj_row["assets"])} asset tier')
    if ncua_group:
        parts.append(f'NCUA peer group {subj_row["Peer_Group"]} ({NCUA_PEER_GROUPS.get(subj_row["Peer_Group"], "?")})')
    if not parts:
        parts.append('all U.S. credit unions')
    return ', '.join(parts) + ' credit unions'


def _money(v):
    if v >= 1e9:
        return f'${v / 1e9:g}B'
    if v >= 1e6:
        return f'${v / 1e6:g}M'
    return f'${v:,.0f}'


def find_cu(metrics, query):
    """Resolve a CU by charter number or name substring (case-insensitive)."""
    q = str(query).strip()
    if q in metrics.index:
        return q
    hits = metrics[metrics['CU_NAME'].str.contains(q, case=False, na=False, regex=False)]
    if len(hits) == 1:
        return hits.index[0]
    exact = hits[hits['CU_NAME'].str.upper() == q.upper()]
    if len(exact) == 1:
        return exact.index[0]
    if hits.empty:
        raise SystemExit(f'No credit union matches "{q}".')
    listing = '\n'.join(f'  {i}  {r.CU_NAME} ({r.CITY}, {r.STATE})' for i, r in hits.head(20).iterrows())
    raise SystemExit(f'"{q}" matches {len(hits)} credit unions; pass the charter number:\n{listing}')


# --------------------------------------------------------------------------- benchmark

def benchmark(panel, period, subject, peer_kwargs):
    """Subject vs peers for one period: value, peer aggregate, peer median, rank, percentile."""
    metrics = cu_metrics(panel, period)
    peers = select_peers(metrics, subject, **peer_kwargs)
    agg = aggregate_metrics(panel, period, list(peers.index))
    group = pd.concat([peers, metrics.loc[[subject]]])
    rows = []
    for key, (label, fmt, hib, _) in METRICS.items():
        v = metrics.at[subject, key]
        col = group[key].dropna()
        rank = pct = None
        if hib is not None and not np.isnan(v) and len(col):
            better = (col > v).sum() if hib else (col < v).sum()
            rank = int(better) + 1
            worse = (col < v).sum() if hib else (col > v).sum()
            pct = 100.0 * worse / max(len(col) - 1, 1)
        rows.append({'metric': key, 'label': label, 'fmt': fmt, 'higher_is_better': hib,
                     'value': v, 'peer_value': agg.get(key), 'peer_median': peers[key].median(),
                     'rank': rank, 'of': len(col), 'percentile': pct})
    return pd.DataFrame(rows), peers, metrics.loc[subject]


def trend(panel, subject, peer_ids, periods, keys):
    """Subject and fixed-membership peer aggregate across periods."""
    out = []
    for p in periods:
        m = cu_metrics(panel, p)
        if subject not in m.index:
            continue
        agg = aggregate_metrics(panel, p, [i for i in peer_ids if i in m.index])
        for k in keys:
            out.append({'period': p, 'metric': k, 'value': m.at[subject, k], 'peer_value': agg[k]})
    return pd.DataFrame(out)


# --------------------------------------------------------------------------- report profile

KIND = 'cu'
INST_WORD = 'Credit union'
ID_LABEL = 'Charter'
PEER_COL = 'Peers'
SOURCE_NOTE = 'NCUA 5300 call report data'
METHOD_NOTE = 'Peer method follows Callahan & Associates conventions.'
SECTIONS = [
    ('Growth', ['share_growth', 'loan_growth', 'asset_growth', 'member_growth']),
    ('Earnings', ['roa', 'nim', 'nonint_income', 'opex_ratio', 'efficiency']),
    ('Capital & credit', ['net_worth', 'loan_to_share', 'delinquency', 'net_chargeoffs', 'coverage']),
    ('Members & productivity', ['members', 'avg_relationship', 'avg_share', 'avg_loan',
                                'members_per_fte', 'draft_penetration', 'auto_penetration']),
]
TREND_KEYS = ['roa', 'efficiency', 'share_growth', 'loan_growth', 'net_worth', 'delinquency']
ROSTER_COLS = [('ROA', 'roa'), ('Efficiency', 'efficiency'), ('Share growth', 'share_growth'), ('Net worth', 'net_worth')]
FOOTNOTE = ('Peers column = Callahan-style aggregate (accounts summed, then the ratio). '
            '* Auto loan penetration is a best estimate; Callahan has not published its formula.')
METHOD_LINES = [
    'Source: NCUA Form 5300 call report quarterly data (ncua.gov). Account codes in brackets.',
    'Conventions follow Callahan & Associates Peer Suite Functions Manual (Feb 2023):',
    '  Growth: year over year vs the same quarter last year (not NCUA FPR year-to-date annualized).',
    '  Income items: year-to-date x 4 / quarter number. Averages: (current + prior December) / 2.',
    '  Peer value: accounts summed across the peer group, then the ratio taken (dollar-weighted). Peer median shown alongside.',
    '  Peer aggregates for growth/average ratios use only peers that reported in the comparison period.',
    'Definitions:',
    '  ROA = annualized net income [661A] / avg assets [010]',
    '  Net interest margin = annualized (interest income [115] - interest expense [350]) / avg assets',
    '  Fee & other operating income / avg assets = annualized (fee income [131] + other operating income [IS0020]) / avg assets',
    '  Operating expense ratio = annualized non-interest expense [671] / avg assets',
    '  Efficiency = [671] / ([115] - [350] + [131] + [IS0020])  (excludes gains/losses; ties to FedFis)',
    '  Net worth ratio = ([997] - [NW0004]) / ([010] - [NW0004])  (CECL transition adjustment from 2023)',
    '  Loan-to-share = loans [025B] / shares [018]; Delinquency = 60+ day delinquent loans [041B] / loans [025B]',
    '  Net charge-offs = annualized (charge-offs [550] - recoveries [551]) / avg loans',
    '  Coverage = allowance (CECL [AS0048], else [719]) / delinquent loans [041B]',
    '  Avg member relationship = (loans + shares) / members [083]; Members per FTE = [083] / ([564A] + [564B]/2)',
    '  Share draft penetration = share draft accounts [452] / members',
    '  * Auto loan penetration = (new [958] + used [968] vehicle loan count) / members (Callahan formula not published; best estimate)',
    'Validation: balances, members, net income, ROA and efficiency tie to FedFis CU Reports for 22 credit unions (2025-06 to 2026-06).',
]


def display_name(subj):
    # Title-case without capitalising after an apostrophe (POLICEMEN'S), keep acronyms (TLCU, DFCU, vowel-less words)
    name = re.sub(r"[A-Za-z]+(?:'[A-Za-z]+)?", lambda m: m.group(0).capitalize(), str(subj['CU_NAME']))
    name = re.sub(r'\b(?!(?:St|Mt|Ft|Dr|Jr|Sr|Mtn)\b)([A-Z][a-z]{0,5}cu|[B-DF-HJ-NP-TV-XZ][b-df-hj-np-tv-xz]{1,4})\b', lambda m: m.group(0).upper(), name)
    name = re.sub(r'\b(Esl|Ent|Usaa|Gte|Ornl|Tva)\b', lambda m: m.group(0).upper(), name)
    # Some NCUA names already say it ("NAVY FEDERAL CREDIT UNION", "PALCO FCU", "METRO CU"): do not add it twice
    if re.search(r'credit union|\b[a-z]{0,6}cu\b', name, re.I):
        return re.sub(r'\b(Fcu|Cu)\b', lambda m: m.group(1).upper(), name)
    return f'{name} Credit Union'
