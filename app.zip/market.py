"""Branch and deposit market share (the BranchAnalyzer / Peer+ deposit displays).

Banks: FDIC Summary of Deposits (branch-level deposits as of each June 30), fetched per state and cached.
Credit unions: NCUA branch list from the quarterly call report zip. Credit unions do not report deposits
by branch, so each credit union's total shares are spread evenly across its branches - the same
convention Callahan uses. Those figures are flagged as estimates.
"""
import json
import os
import re
import time
import urllib.parse
import urllib.request
from datetime import date

import numpy as np
import pandas as pd

import wide_store

HERE = os.path.dirname(os.path.abspath(__file__))
SOD_DIR = os.path.join(HERE, 'data', 'sod')
SOD_API = 'https://api.fdic.gov/banks/sod'
SOD_FIELDS = ['CERT', 'NAMEFULL', 'BRNUM', 'NAMEBR', 'ADDRESBR', 'CITYBR', 'CNTYNAMB', 'STCNTYBR', 'ZIPBR', 'MSANAMB',
              'DEPSUMBR', 'BRSERTYP', 'YEAR', 'STALPBR']
_mem = {}


def _norm_county(s):
    s = re.sub(r'\b(county|parish|borough|census area|municipality|city and borough)\b', '', str(s).lower())
    return re.sub(r'[^a-z]', '', s)


def _get(url):
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=120) as r:
                return json.load(r)
        except Exception:
            if attempt == 2:
                raise
            time.sleep(2 * (attempt + 1))


def latest_sod_year():
    """Newest SOD year the FDIC has published (data is as of June 30, released each September)."""
    if 'year' in _mem and time.time() - _mem['year'][1] < 86400:
        return _mem['year'][0]
    cached = sorted({int(f.split('_')[1][:4]) for f in os.listdir(SOD_DIR)} if os.path.isdir(SOD_DIR) else [])
    y = date.today().year
    found = None
    for cand in (y, y - 1, y - 2):
        try:
            d = _get(f'{SOD_API}?filters=' + urllib.parse.quote(f'YEAR:{cand}') + '&fields=CERT&limit=1&format=json')
            if d.get('meta', {}).get('total', 0) > 1000:
                found = cand
                break
        except Exception:
            break
    found = found or (cached[-1] if cached else y - 1)
    _mem['year'] = (found, time.time())
    return found


def sod(state, year):
    """Branch-level bank deposits for one state and year (cached on disk)."""
    key = (state, year)
    if key in _mem:
        return _mem[key]
    path = os.path.join(SOD_DIR, f'{state}_{year}.pkl')
    if os.path.exists(path):
        df = pd.read_pickle(path)
    else:
        rows, offset = [], 0
        while True:
            url = (f'{SOD_API}?filters=' + urllib.parse.quote(f'STALPBR:"{state}" AND YEAR:{year}')
                   + f'&fields={",".join(SOD_FIELDS)}&limit=10000&offset={offset}&format=json')
            d = _get(url)
            chunk = [r['data'] for r in d.get('data', [])]
            rows += chunk
            offset += len(chunk)
            if not chunk or offset >= d.get('meta', {}).get('total', 0):
                break
        df = pd.DataFrame(rows)
        if len(df):
            df = pd.DataFrame({
                'kind': 'bank', 'id': df['CERT'].astype(int).astype(str), 'name': df['NAMEFULL'].astype(str),
                'site': df['NAMEBR'].astype(str), 'address': df['ADDRESBR'].astype(str), 'city': df['CITYBR'].astype(str),
                'county': df['CNTYNAMB'].astype(str), 'state': state, 'zip': df['ZIPBR'].astype(str).str[:5],
                'msa': df['MSANAMB'].fillna('').astype(str),
                'deposits': pd.to_numeric(df['DEPSUMBR'], errors='coerce').fillna(0) * 1000.0, 'est': False})
            os.makedirs(SOD_DIR, exist_ok=True)
            df.to_pickle(path)
    _mem[key] = df
    return df


def cu_branches(year):
    """Every credit union branch with an estimated deposit figure for June of `year`
    (total shares / number of branches)."""
    key = ('cu', year)
    if key in _mem:
        return _mem[key]
    store = wide_store.STORES['cu']
    br = store.branches()
    if br.empty:
        return br
    br = br[br['member_services'].isin(['1', 'True', 'true', 'Yes']) | (br['main'].str.lower() == 'yes')].copy() \
        if 'member_services' in br.columns else br.copy()
    period = f'{year}-06' if store.exists(f'{year}-06') else store.latest()
    shares = pd.Series(store.col(period, '018'), index=store.ids(period))
    n = br.groupby('id')['id'].transform('size')
    br['deposits'] = br['id'].map(shares).fillna(0) / n
    br['kind'], br['est'], br['msa'] = 'cu', True, ''
    names = store.info(period)['CU_NAME']
    nm = br['id'].map(names).fillna(br['name']).str.title()
    br['name'] = nm.where(nm.str.contains('Credit Union'), nm + ' Credit Union')
    br['zip'] = br['zip'].str[:5]
    out = br[['kind', 'id', 'name', 'site', 'address', 'city', 'county', 'state', 'zip', 'msa', 'deposits', 'est']]
    _mem[key] = out
    return out


def counties(state):
    year = latest_sod_year()
    b = sod(state, year)
    c = cu_branches(year)
    c = c[c['state'] == state] if len(c) else c
    allb = pd.concat([b, c]) if len(b) else c
    if allb.empty:
        return []
    allb = allb.assign(k=allb['county'].map(_norm_county))
    g = allb.groupby('k').agg(name=('county', 'first'), branches=('id', 'size'), deposits=('deposits', 'sum'))
    g = g[g.index != '']
    return [dict(name=r['name'].title(), branches=int(r['branches']), deposits=float(r['deposits']))
            for _, r in g.sort_values('name').iterrows()]


def _slice(df, state, county_keys, city, zips):
    if df.empty:
        return df
    m = df['state'] == state
    if county_keys:
        m &= df['county'].map(_norm_county).isin(county_keys)
    if city:
        m &= df['city'].str.lower().str.strip() == city.lower().strip()
    if zips:
        m &= df['zip'].isin(zips)
    return df[m]


def _market(req, year):
    frames = []
    for area in req.get('areas') or []:
        state = area.get('state')
        if not state:
            continue
        ck = {_norm_county(c) for c in area.get('counties') or []}
        zips = {z.strip()[:5] for z in area.get('zips') or [] if z.strip()}
        frames.append(_slice(sod(state, year), state, ck, area.get('city'), zips))
        if req.get('include_cu', True):
            frames.append(_slice(cu_branches(year), state, ck, area.get('city'), zips))
    frames = [f for f in frames if len(f)]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(
        columns=['kind', 'id', 'name', 'site', 'address', 'city', 'county', 'state', 'zip', 'msa', 'deposits', 'est'])


def analyze(req):
    """req: {areas: [{state, counties?, city?, zips?}], include_cu, subject: {type, id}, years}"""
    year = int(req.get('year') or latest_sod_year())
    cur = _market(req, year)
    if cur.empty:
        return dict(year=year, empty=True, institutions=[], branches=[], trend=[], summary={})
    total = float(cur['deposits'].sum())
    subj = req.get('subject') or {}
    skey = (subj.get('type') or 'cu', str(subj.get('id') or ''))

    def by_inst(df):
        g = df.groupby(['kind', 'id']).agg(name=('name', 'first'), branches=('id', 'size'), deposits=('deposits', 'sum')).reset_index()
        return g.sort_values('deposits', ascending=False)

    g = by_inst(cur)
    prev = _market(req, year - 1)
    pg = by_inst(prev).set_index(['kind', 'id'])['deposits'] if len(prev) else pd.Series(dtype=float)
    ptotal = float(prev['deposits'].sum()) if len(prev) else 0
    inst = []
    for rank, (_, r) in enumerate(g.iterrows(), 1):
        p = pg.get((r['kind'], r['id']), np.nan) if len(pg) else np.nan
        inst.append(dict(rank=rank, kind=r['kind'], id=r['id'], name=r['name'], branches=int(r['branches']),
                         deposits=float(r['deposits']), share=float(r['deposits'] / total) if total else None,
                         per_branch=float(r['deposits'] / r['branches']),
                         share_chg=(float(r['deposits'] / total - p / ptotal) if total and ptotal and not np.isnan(p) else None),
                         growth=(float(r['deposits'] / p - 1) if p and not np.isnan(p) and p > 0 else None),
                         est=r['kind'] == 'cu', subject=(r['kind'], r['id']) == skey))
    shares = (g['deposits'] / total).to_numpy() if total else np.zeros(0)
    trend = []
    for y in range(year - int(req.get('years') or 5) + 1, year + 1):
        try:
            d = cur if y == year else _market(req, y)
        except Exception:
            continue
        if d.empty:
            continue
        t = float(d['deposits'].sum())
        me = d[(d['kind'] == skey[0]) & (d['id'] == skey[1])]
        trend.append(dict(year=y, total=t, banks=float(d.loc[d['kind'] == 'bank', 'deposits'].sum()),
                          cus=float(d.loc[d['kind'] == 'cu', 'deposits'].sum()), branches=int(len(d)),
                          subject=float(me['deposits'].sum()) if len(me) else None,
                          subject_share=float(me['deposits'].sum() / t) if len(me) and t else None,
                          subject_branches=int(len(me)) if len(me) else None))
    br = cur.sort_values('deposits', ascending=False)
    branches = [dict(kind=r.kind, id=r.id, name=r.name, site=r.site, address=r.address, city=r.city.title(),
                     county=r.county.title(), state=r.state, zip=r.zip, deposits=float(r.deposits), est=bool(r.est),
                     subject=(r.kind, r.id) == skey) for r in br.head(int(req.get('branch_limit') or 600)).itertuples()]
    cu_dep = float(cur.loc[cur['kind'] == 'cu', 'deposits'].sum())
    return dict(
        year=year, empty=False, institutions=inst[:int(req.get('limit') or 250)], branches=branches, trend=trend,
        summary=dict(total=total, institutions=int(len(g)), branches=int(len(cur)),
                     banks=int((g['kind'] == 'bank').sum()), cus=int((g['kind'] == 'cu').sum()),
                     bank_branches=int((cur['kind'] == 'bank').sum()), cu_branches=int((cur['kind'] == 'cu').sum()),
                     cu_share=cu_dep / total if total else None, hhi=float((shares ** 2).sum() * 10000) if len(shares) else None,
                     top5=float(shares[:5].sum()) if len(shares) else None,
                     growth=(total / ptotal - 1) if ptotal else None))


def footprint(kind, inst_id):
    """Where an institution has branches: [{state, county, branches, deposits}] - used to build 'my market'."""
    year = latest_sod_year()
    if kind == 'cu':
        b = cu_branches(year)
        b = b[b['id'] == str(inst_id)]
    elif len([f for f in os.listdir(SOD_DIR) if f.endswith(f'_{year}.pkl')]) >= 50 if os.path.isdir(SOD_DIR) else False:
        # every state is on disk (always true on the website): read the branches there, no FDIC call
        b = pd.concat([sod(f.split('_')[0], year) for f in sorted(os.listdir(SOD_DIR)) if f.endswith(f'_{year}.pkl')])
        b = b[(b['kind'] == 'bank') & (b['id'].astype(str) == str(inst_id))][['state', 'county', 'deposits']]
    else:
        d = _get(f'{SOD_API}?filters=' + urllib.parse.quote(f'CERT:{inst_id} AND YEAR:{year}')
                 + '&fields=STALPBR,CNTYNAMB,DEPSUMBR&limit=10000&format=json')
        rows = [r['data'] for r in d.get('data', [])]
        b = pd.DataFrame({'state': [r['STALPBR'] for r in rows], 'county': [r['CNTYNAMB'] for r in rows],
                          'deposits': [float(r.get('DEPSUMBR') or 0) * 1000 for r in rows]})
    if b.empty:
        return []
    g = b.assign(k=b['county'].map(_norm_county)).groupby(['state', 'k']).agg(
        county=('county', 'first'), branches=('state', 'size'), deposits=('deposits', 'sum')).reset_index()
    return [dict(state=r.state, county=r.county.title(), branches=int(r.branches), deposits=float(r.deposits))
            for r in g.sort_values('deposits', ascending=False).itertuples()]
