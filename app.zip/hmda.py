"""Mortgage market share from public HMDA data (CFPB / FFIEC Home Mortgage Disclosure Act).

Build step (desktop, needs the internet once a year):  .venv/bin/python hmda.py [year]
  1. The snapshot national loan file (about 740 MB zipped) is read once and reduced to one row per
     county x lender: applications, originations (count and dollars), denials, purchase and refinance loans.
     Only 1-4 family homes count (multifamily buildings would swamp home-lending shares). Loans an institution
     bought (action 6) and preapprovals (7, 8) are not counted.
  2. Each lender's LEI is linked to the app's banks and credit unions through the HMDA institution record
     (Federal Reserve RSSD ID), checked against the name; a name + state match is the fallback.
  The result is data/hmda/hmda_<year>.pkl (counties) and lenders_<year>.pkl. The app only reads those.
"""
import io
import json
import os
import re
import sys
import time
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
DIR = os.path.join(HERE, 'data', 'hmda')
SNAP = 'https://files.ffiec.cfpb.gov/static-data/snapshot/{y}/{y}_public_{k}_csv.zip'
INST = 'https://ffiec.cfpb.gov/v2/public/institutions/{lei}/year/{y}'
CENSUS = 'https://www2.census.gov/geo/docs/reference/codes2020/national_county2020.txt'
HEAD = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) '
                      'Chrome/130.0.0.0 Safari/537.36', 'Accept': '*/*', 'Accept-Language': 'en-US,en;q=0.9'}
AGENCY = {1: 'OCC', 2: 'Federal Reserve', 3: 'FDIC', 5: 'NCUA', 7: 'HUD (non-bank lender)', 9: 'CFPB'}
# Connecticut's planning regions replaced its counties in federal data from 2022
CT_REGIONS = {'09110': 'Capitol', '09120': 'Greater Bridgeport', '09130': 'Lower Connecticut River Valley',
              '09140': 'Naugatuck Valley', '09150': 'Northeastern Connecticut', '09160': 'Northwest Hills',
              '09170': 'South Central Connecticut', '09180': 'Southeastern Connecticut', '09190': 'Western Connecticut'}
_mem = {}


def _get(url, timeout=120):
    for attempt in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=HEAD), timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise
            if attempt == 3:
                raise
        except Exception:
            if attempt == 3:
                raise
        time.sleep(2 * (attempt + 1))


def _download(url, dest, log=print):
    if os.path.exists(dest):
        return dest
    log(f'Downloading {url.split("/")[-1]}…')
    with urllib.request.urlopen(urllib.request.Request(url, headers=HEAD), timeout=900) as r, open(dest + '.part', 'wb') as f:
        while True:
            b = r.read(1 << 22)
            if not b:
                break
            f.write(b)
    os.replace(dest + '.part', dest)
    return dest


# --------------------------------------------------------------------------- counties
def _norm_county(s):
    s = re.sub(r'\b(county|parish|borough|census area|municipality|city and borough|planning region)\b', '', str(s).lower())
    return re.sub(r'[^a-z]', '', s)


def county_codes():
    """{(state, normalized county name): 5-digit FIPS} for matching the app's county names to HMDA."""
    if 'cty' in _mem:
        return _mem['cty']
    path = os.path.join(DIR, 'national_county2020.txt')
    if not os.path.exists(path):
        os.makedirs(DIR, exist_ok=True)
        with open(path, 'wb') as f:
            f.write(_get(CENSUS))
    df = pd.read_csv(path, sep='|', dtype=str)
    out = {(r.STATE, _norm_county(r.COUNTYNAME)): r.STATEFP + r.COUNTYFP for r in df.itertuples()}
    for code, nm in CT_REGIONS.items():
        out[('CT', _norm_county(nm))] = code
    names = {r.STATEFP + r.COUNTYFP: (r.STATE, r.COUNTYNAME) for r in df.itertuples()}
    names.update({c: ('CT', n + ' Planning Region') for c, n in CT_REGIONS.items()})
    _mem['cty'] = (out, names)
    return out, names


# --------------------------------------------------------------------------- loan file -> county x lender
def reduce_lar(year, log=print):
    out = os.path.join(DIR, f'hmda_{year}.pkl')
    if os.path.exists(out):
        return pd.read_pickle(out)
    zpath = _download(SNAP.format(y=year, k='lar'), os.path.join(DIR, f'{year}_public_lar_csv.zip'), log)
    cols = ['lei', 'county_code', 'action_taken', 'loan_purpose', 'loan_amount', 'total_units']
    parts = []
    with zipfile.ZipFile(zpath) as z:
        name = next(n for n in z.namelist() if n.endswith('.csv') and not n.startswith('__'))
        n = 0
        for ch in pd.read_csv(z.open(name), usecols=cols, dtype={'lei': str, 'county_code': str, 'action_taken': 'int8',
                                                                  'loan_purpose': 'int16', 'total_units': str},
                              chunksize=1_000_000, na_values=['NA', 'Exempt']):
            n += len(ch)
            ch = ch[ch['action_taken'].between(1, 5) & ch['county_code'].notna() & ch['total_units'].isin(['1', '2', '3', '4'])]
            amt = pd.to_numeric(ch['loan_amount'], errors='coerce').fillna(0.0)
            orig = ch['action_taken'] == 1
            purch = ch['loan_purpose'] == 1
            refi = ch['loan_purpose'].isin([31, 32])
            f = pd.DataFrame({'county': ch['county_code'].str.zfill(5), 'lei': ch['lei'],
                              'apps': 1, 'orig': orig.astype('int32'), 'orig_amt': amt.where(orig, 0.0),
                              'denied': (ch['action_taken'] == 3).astype('int32'),
                              'purch': (orig & purch).astype('int32'), 'purch_amt': amt.where(orig & purch, 0.0),
                              'refi': (orig & refi).astype('int32'), 'refi_amt': amt.where(orig & refi, 0.0)})
            parts.append(f.groupby(['county', 'lei'], sort=False).sum())
            log(f'  {n:,} loan records read')
    df = pd.concat(parts).groupby(level=[0, 1]).sum().reset_index()
    for c in ('apps', 'orig', 'denied', 'purch', 'refi'):
        df[c] = df[c].astype('int32')
    df.to_pickle(out)
    log(f'HMDA {year}: {len(df):,} county x lender rows')
    return df


# --------------------------------------------------------------------------- lenders -> app institutions
def _toks(s):
    s = re.sub(r'&', ' and ', str(s).lower())
    s = re.sub(r'[^a-z0-9 ]', ' ', s)
    stop = {'the', 'of', 'and', 'credit', 'union', 'federal', 'fcu', 'cu', 'bank', 'na', 'n', 'a', 'national', 'association',
            'inc', 'co', 'company', 'trust', 'savings', 'state', 'ssb', 'fsb', 'community', 'financial', 'corporation',
            'corp', 'llc', 'banking', 'mortgage'}
    return {t for t in s.split() if t not in stop}


def _similar(a, b):
    ta, tb = _toks(a), _toks(b)
    if not ta or not tb:
        return re.sub(r'[^a-z]', '', str(a).lower()) == re.sub(r'[^a-z]', '', str(b).lower())
    return len(ta & tb) / len(ta | tb) >= 0.34


def lenders(year, log=print):
    out = os.path.join(DIR, f'lenders_{year}.pkl')
    if os.path.exists(out):
        return pd.read_pickle(out)
    import wide_store
    ts_zip = _download(SNAP.format(y=year, k='ts'), os.path.join(DIR, f'{year}_public_ts_csv.zip'), log)
    with zipfile.ZipFile(ts_zip) as z:
        ts = pd.read_csv(z.open(next(n for n in z.namelist() if n.endswith('.csv') and not n.startswith('__'))), dtype=str)
    ts['agency_code'] = ts['agency_code'].astype(int)
    cache_path = os.path.join(DIR, f'institutions_{year}.json')
    cache = json.load(open(cache_path)) if os.path.exists(cache_path) else {}
    todo = [l for l, a in zip(ts['lei'], ts['agency_code']) if a in (1, 2, 3, 5, 9) and l not in cache]
    log(f'Looking up {len(todo):,} HMDA lenders…')

    def one(lei):
        try:
            return lei, json.loads(_get(INST.format(lei=lei, y=year), timeout=60))
        except Exception as e:
            return lei, {'error': str(e)[:80]}
    with ThreadPoolExecutor(6) as ex:
        for i, (lei, rec) in enumerate(ex.map(one, todo), 1):
            cache[lei] = rec
            if i % 250 == 0:
                log(f'  {i:,} of {len(todo):,}')
                json.dump(cache, open(cache_path, 'w'))
    json.dump(cache, open(cache_path, 'w'))

    maps = {}
    for kind in ('cu', 'bank'):
        s = wide_store.STORES[kind]
        u = s.info(s.latest())
        rssd = u['RSSD'].astype(str).str.replace(r'\.0$', '', regex=True)
        maps[kind] = dict(u=u, rssd={r: i for i, r in zip(u.index, rssd) if r not in ('', '0', 'nan', 'None')},
                          ids=set(u.index.astype(str)),
                          names={(re.sub(r'[^a-z]', '', str(n).lower()), st): i for i, n, st in zip(u.index, u['CU_NAME'], u['STATE'])})
    nat = {}
    for k in ('cu', 'bank'):
        nat[k] = {}
        for i, nm in maps[k]['u']['CU_NAME'].items():
            key = re.sub(r'[^a-z0-9]', '', re.sub(r'\b(the|national association|n a)\b', '', str(nm).lower()))
            nat[k].setdefault(key, []).append(i)
    rows = []
    for r in ts.itertuples():
        rec = cache.get(r.lei) or {}
        kind = 'cu' if r.agency_code == 5 else 'bank' if r.agency_code in (1, 2, 3) else None
        hit, how = None, None
        cands = []
        rssd = str(rec.get('rssd') or '')
        id17 = str(rec.get('institutionId2017') or '').lstrip('0')
        for k in ([kind] if kind else ['cu', 'bank']) if r.agency_code != 7 else []:
            m = maps[k]
            if rssd not in ('', '-1') and rssd in m['rssd']:
                cands.append((k, m['rssd'][rssd], 'rssd', True))
            if id17 and id17 in m['rssd']:
                cands.append((k, m['rssd'][id17], 'rssd (2017 id)', False))
            if id17 and id17 in m['ids']:
                cands.append((k, id17, 'charter/cert (2017 id)', False))
        for k, i, h, sure in cands:
            nm = maps[k]['u'].at[i, 'CU_NAME']
            if sure or _similar(nm, r.respondent_name):
                hit, how, kind = i, h, k
                break
        affiliate = re.search(r'\b(mortgage|llc|inc|corporation|corp|development|services|holdings?|lending|home loans)\b',
                              str(r.respondent_name).lower())
        if hit is None and r.agency_code != 7 and not affiliate:  # fallback: best name match in the same state
            mine = _toks(r.respondent_name)
            best = []
            for k in ('cu', 'bank'):
                u = maps[k]['u']
                for i, nm in u.loc[u['STATE'] == r.respondent_state, 'CU_NAME'].items():
                    t = _toks(nm)
                    if mine and t:
                        sc = len(mine & t) / len(mine | t)
                        if r.respondent_city and str(u.at[i, 'CITY']).lower() == str(r.respondent_city).lower():
                            sc += 0.15
                        best.append((sc, k, i))
            best.sort(reverse=True)
            if best and best[0][0] >= 0.6 and (len(best) == 1 or best[1][0] < best[0][0]):
                hit, kind, how = best[0][2], best[0][1], 'name + state'
        if hit is None and r.agency_code != 7 and not affiliate:  # same full name anywhere, if only one has it
            full = re.sub(r'[^a-z0-9]', '', re.sub(r'\b(the|national association|n a)\b', '', str(r.respondent_name).lower()))
            same = [(k, i) for k in ('cu', 'bank') for i in nat[k].get(full, [])]
            if len(same) == 1:
                kind, hit = same[0]
                how = 'name (nationwide)'
        rows.append(dict(lei=r.lei, name=r.respondent_name, state=r.respondent_state, city=r.respondent_city,
                         agency=AGENCY.get(r.agency_code, str(r.agency_code)), kind=kind if hit is not None else
                         ('cu' if r.agency_code == 5 or re.search(r'credit union|\bfcu\b', r.respondent_name.lower()) else
                          'bank' if r.agency_code in (1, 2, 3) or re.search(r'\bbank\b', r.respondent_name.lower()) else 'other'),
                         inst_id=str(hit) if hit is not None else '', match=how or ''))
    df = pd.DataFrame(rows)
    df.to_pickle(out)
    m = df[df['inst_id'] != '']
    log(f'Linked {len(m):,} of {int((df["kind"] != "other").sum()):,} bank and credit union lenders '
        f'({(m["kind"] == "cu").sum():,} credit unions, {(m["kind"] == "bank").sum():,} banks).')
    return df


# --------------------------------------------------------------------------- app side
def available_year():
    if not os.path.isdir(DIR):
        return None
    ys = sorted(int(m.group(1)) for f in os.listdir(DIR) for m in [re.match(r'lenders_(\d{4})\.pkl$', f)] if m)
    ys = [y for y in ys if os.path.isdir(os.path.join(DIR, f'hmda_{y}')) or os.path.exists(os.path.join(DIR, f'hmda_{y}.pkl'))]
    return ys[-1] if ys else None


def split_states(year):
    """One small file per state (by the property's county), so a market loads only its states."""
    d = pd.read_pickle(os.path.join(DIR, f'hmda_{year}.pkl'))
    out = os.path.join(DIR, f'hmda_{year}')
    os.makedirs(out, exist_ok=True)
    for st, g in d.groupby(d['county'].str[:2]):
        g.reset_index(drop=True).to_pickle(os.path.join(out, f'{st}.pkl'))
    return out


def _state_rows(year, st_fips):
    key = ('s', year, st_fips)
    if key not in _mem:
        path = os.path.join(DIR, f'hmda_{year}', f'{st_fips}.pkl')
        if os.path.exists(path):
            _mem[key] = pd.read_pickle(path)
        else:
            if ('full', year) not in _mem:
                _mem[('full', year)] = pd.read_pickle(os.path.join(DIR, f'hmda_{year}.pkl'))
            full = _mem[('full', year)]
            _mem[key] = full[full['county'].str[:2] == st_fips]
    return _mem[key]


def _lenders(year):
    if ('l', year) not in _mem:
        _mem[('l', year)] = pd.read_pickle(os.path.join(DIR, f'lenders_{year}.pkl')).set_index('lei')
    return _mem[('l', year)]


def analyze(req):
    """req: {areas: [{state, counties?}], subject: {type, id}, purpose: 'all'|'purchase'|'refi'}"""
    year = available_year()
    if year is None:
        return dict(empty=True, missing=True)
    codes, names = county_codes()
    from wide_store import STORES  # noqa: F401  (keeps import order the same as the rest of the app)
    fips_state = {v[:2]: k[0] for k, v in codes.items()}
    want, unknown = set(), []
    for a in req.get('areas') or []:
        st = a.get('state')
        if not st:
            continue
        cs = a.get('counties') or []
        if cs:
            for c in cs:
                f = codes.get((st, _norm_county(c)))
                (want.add(f) if f else unknown.append(f'{c}, {st}'))
        else:
            want |= {v for (s, _), v in codes.items() if s == st}
    lend = _lenders(year)
    parts = [_state_rows(year, sf) for sf in sorted({f[:2] for f in want})]
    cur = pd.concat(parts) if parts else pd.DataFrame(columns=['county', 'lei'])
    cur = cur[cur['county'].isin(want)]
    if cur.empty:
        return dict(empty=True, year=year, unknown=unknown)
    purpose = req.get('purpose') or 'all'
    n_col, a_col = {'all': ('orig', 'orig_amt'), 'purchase': ('purch', 'purch_amt'), 'refi': ('refi', 'refi_amt')}[purpose]
    g = cur.groupby('lei')[['apps', 'orig', 'orig_amt', 'denied', 'purch', 'purch_amt', 'refi', 'refi_amt']].sum()
    g = g.join(lend[['name', 'kind', 'inst_id', 'agency']], how='left')
    g['name'] = g['name'].fillna('Unknown lender')
    g['kind'] = g['kind'].fillna('other')
    tot_n, tot_amt = float(g[n_col].sum()), float(g[a_col].sum())
    g = g.sort_values([a_col, n_col], ascending=False)
    g = g[g[n_col] > 0]
    subj = req.get('subject') or {}
    skind, sid = subj.get('type') or 'cu', str(subj.get('id') or '')
    inst = []
    for rank, (lei, r) in enumerate(g.iterrows(), 1):
        me = bool(sid) and r['kind'] == skind and str(r['inst_id']) == sid
        inst.append(dict(rank=rank, lei=lei, name=r['name'], kind=r['kind'], inst_id=r['inst_id'] or None, agency=r['agency'],
                         loans=int(r[n_col]), amount=float(r[a_col]), share=float(r[a_col] / tot_amt) if tot_amt else None,
                         share_n=float(r[n_col] / tot_n) if tot_n else None,
                         avg=float(r[a_col] / r[n_col]) if r[n_col] else None, apps=int(r['apps']),
                         deny=float(r['denied'] / r['apps']) if r['apps'] else None, subject=me))
    by_kind = g.groupby('kind')[a_col].sum()
    shares = (g[a_col] / tot_amt).to_numpy() if tot_amt else np.zeros(0)
    me = next((x for x in inst if x['subject']), None)
    counties = []
    mine = lend.index[(lend['kind'] == skind) & (lend['inst_id'] == sid)] if sid else []
    if sid:
        if len(mine):
            mc = cur[cur['lei'].isin(mine)].groupby('county')[[n_col, a_col]].sum()
            ct = cur.groupby('county')[[n_col, a_col]].sum()
            for c, r in mc.sort_values(a_col, ascending=False).iterrows():
                t = ct.loc[c]
                counties.append(dict(county=names.get(c, ('', c))[1], state=names.get(c, (fips_state.get(c[:2], ''), ''))[0],
                                     loans=int(r[n_col]), amount=float(r[a_col]),
                                     share=float(r[a_col] / t[a_col]) if t[a_col] else None))
    return dict(empty=False, year=year, purpose=purpose, unknown=unknown, institutions=inst[:int(req.get('limit') or 250)],
                reporter=bool(len(mine)),
                counties=counties,
                summary=dict(loans=int(tot_n), amount=tot_amt, lenders=int(len(g)), apps=int(g['apps'].sum()),
                             deny=float(g['denied'].sum() / g['apps'].sum()) if g['apps'].sum() else None,
                             cu_share=float(by_kind.get('cu', 0) / tot_amt) if tot_amt else None,
                             bank_share=float(by_kind.get('bank', 0) / tot_amt) if tot_amt else None,
                             other_share=float(by_kind.get('other', 0) / tot_amt) if tot_amt else None,
                             top5=float(shares[:5].sum()) if len(shares) else None,
                             hhi=float((shares ** 2).sum() * 10000) if len(shares) else None),
                me=me)


if __name__ == '__main__':
    y = int(sys.argv[1]) if len(sys.argv) > 1 else 2025
    os.makedirs(DIR, exist_ok=True)
    county_codes()
    lenders(y)
    reduce_lar(y)
    split_states(y)
