"""Minimal PowerPoint writer (no third-party package): 16:9 slides with a title, subtitle,
one picture and/or one native table, and a footer. Enough for exporting analyzer charts and scorecards."""
import base64
import struct
import zipfile
from xml.sax.saxutils import escape

W, H = 12192000, 6858000          # 13.333in x 7.5in in EMU
RED, GRAY, INK, GOLD = '14233A', '535B67', '121821', 'B08D57'
LOGO = __import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)), 'assets', 'lockup-navy.png')
LOCK_H = 230000                       # brand lockup height on each slide (EMU)
NS = ('xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"')
XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'


def _rels(items):
    body = ''.join(f'<Relationship Id="{i}" Type="{REL}/{t}" Target="{tg}"/>' for i, t, tg in items)
    return XML + f'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{body}</Relationships>'


def _png_size(data):
    if data[:8] == b'\x89PNG\r\n\x1a\n':
        return struct.unpack('>II', data[16:24])
    return 1600, 900


def _text(sid, name, x, y, w, h, text, size, bold=False, color=INK, align='l', face='Arial'):
    paras = ''.join(
        f'<a:p><a:pPr algn="{align}"/><a:r><a:rPr lang="en-US" sz="{size}" b="{int(bold)}" dirty="0">'
        f'<a:solidFill><a:srgbClr val="{color}"/></a:solidFill><a:latin typeface="{face}"/></a:rPr>'
        f'<a:t>{escape(line)}</a:t></a:r></a:p>' for line in str(text).split('\n'))
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="{name}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm>'
            f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
            f'<p:txBody><a:bodyPr wrap="square" lIns="0" tIns="0" rIns="0" bIns="0" anchor="t"><a:normAutofit/></a:bodyPr>'
            f'<a:lstStyle/>{paras}</p:txBody></p:sp>')


def _rect(sid, x, y, w, h, color):
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="Bar"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm>'
            f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
            f'<a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp>')


def _pic(sid, rid, x, y, w, h):
    return (f'<p:pic><p:nvPicPr><p:cNvPr id="{sid}" name="Chart"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>'
            f'<p:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>'
            f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm>'
            f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>')


def _cell(text, bold=False, color=INK, fill=None, align='l', size=1000):
    f = f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>' if fill else '<a:noFill/>'
    line = '<a:lnB w="6350"><a:solidFill><a:srgbClr val="DDD8CE"/></a:solidFill></a:lnB>'
    return (f'<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:pPr algn="{align}"/><a:r>'
            f'<a:rPr lang="en-US" sz="{size}" b="{int(bold)}" dirty="0"><a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
            f'<a:latin typeface="Arial"/></a:rPr><a:t>{escape(str(text))}</a:t></a:r></a:p></a:txBody>'
            f'<a:tcPr marL="45720" marR="45720" marT="18288" marB="18288" anchor="ctr">{line}{f}</a:tcPr></a:tc>')


def _table(sid, x, y, w, columns, rows, max_h, align=None, fractions=None):
    n = len(columns)
    first = int(w * (0.36 if n > 2 else 0.5)) if n > 1 else w
    widths = [int(w * f) for f in fractions] if fractions else [first] + [int((w - first) / max(n - 1, 1))] * (n - 1)
    al = list(align) if align else ['l'] + ['r'] * (n - 1)
    rh = int(min(260000, max_h / (len(rows) + 1)))
    size = 1000 if rh >= 230000 else 900 if rh >= 200000 else 800
    grid = ''.join(f'<a:gridCol w="{cw}"/>' for cw in widths)
    head = f'<a:tr h="{rh}">' + ''.join(_cell(c, True, 'FFFFFF', RED, al[i], size) for i, c in enumerate(columns)) + '</a:tr>'
    body = ''.join(f'<a:tr h="{rh}">' + ''.join(_cell('' if v is None else v, False, INK, None, al[i], size)
                                                for i, v in enumerate(list(r) + [''] * (n - len(r)))) + '</a:tr>' for r in rows)
    return (f'<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="{sid}" name="Table"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr>'
            f'<p:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{rh * (len(rows) + 1)}"/></p:xfrm>'
            f'<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr firstRow="1"/>'
            f'<a:tblGrid>{grid}</a:tblGrid>{head}{body}</a:tbl></a:graphicData></a:graphic></p:graphicFrame>')


_THEME = XML + ('<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="AV Peer Benchmark"><a:themeElements>'
    '<a:clrScheme name="AV Peer Benchmark"><a:dk1><a:srgbClr val="121821"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1>'
    '<a:dk2><a:srgbClr val="535B67"/></a:dk2><a:lt2><a:srgbClr val="F7F5F0"/></a:lt2><a:accent1><a:srgbClr val="B08D57"/></a:accent1>'
    '<a:accent2><a:srgbClr val="14233A"/></a:accent2><a:accent3><a:srgbClr val="7A8796"/></a:accent3><a:accent4><a:srgbClr val="6D4C63"/></a:accent4>'
    '<a:accent5><a:srgbClr val="3F6E5A"/></a:accent5><a:accent6><a:srgbClr val="8A909A"/></a:accent6><a:hlink><a:srgbClr val="2F5D8A"/></a:hlink>'
    '<a:folHlink><a:srgbClr val="6D4C63"/></a:folHlink></a:clrScheme>'
    '<a:fontScheme name="AV Peer Benchmark"><a:majorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont>'
    '<a:minorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>'
    '<a:fmtScheme name="Office"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst>'
    '<a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="12700"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
    '<a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst>'
    '<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>'
    '<a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>')
_TREE0 = ('<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/>'
          '<a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>')
_CLRMAP = '<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>'
_MASTER = XML + (f'<p:sldMaster {NS}><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree>{_TREE0}</p:spTree></p:cSld>'
                 f'{_CLRMAP}<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst></p:sldMaster>')
_LAYOUT = XML + (f'<p:sldLayout {NS} type="blank" preserve="1"><p:cSld name="Blank"><p:spTree>{_TREE0}</p:spTree></p:cSld>'
                 '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>')


def _lock_w():
    with open(LOGO, 'rb') as f:
        w, h = _png_size(f.read())
    return LOCK_H * w // h


def build(path, slides, footer='Prepared with AV’s Peer Benchmark from public NCUA and FDIC call report data'):
    """slides: [{title, subtitle, image (data URL or bytes), table: {columns, rows}, note}]"""
    slides = slides or [{'title': 'AV’s Peer Benchmark'}]
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        types = ['<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
                 '<Default Extension="xml" ContentType="application/xml"/>', '<Default Extension="png" ContentType="image/png"/>',
                 '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>',
                 '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>',
                 '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>',
                 '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>']
        pres_rels = [('rId1', 'slideMaster', 'slideMasters/slideMaster1.xml'), ('rId2', 'theme', 'theme/theme1.xml')]
        sld_ids = ''
        for n, s in enumerate(slides, 1):
            mx, top = 457200, 320040
            cw = W - 2 * mx
            shapes = [_rect(2, 0, 0, W, 91440, RED), _rect(10, 0, 91440, W, 27432, GOLD),
                      _pic(12, 'rId3', W - mx - _lock_w(), 150000, _lock_w(), LOCK_H),
                      _text(3, 'Title', mx, top, cw, 420000, s.get('title') or '', 2400, True, RED)]
            y = top + 440000
            if s.get('subtitle'):
                shapes.append(_text(4, 'Subtitle', mx, y, cw, 300000, s['subtitle'], 1200, False, GRAY))
                y += 330000
            rels = [('rId1', 'slideLayout', '../slideLayouts/slideLayout1.xml'), ('rId3', 'image', '../media/logo.png')]
            avail = H - y - 520000
            note_h = 0
            if s.get('note'):
                note_h = 180000 * (1 + str(s['note']).count('\n')) + 60000
                avail -= note_h
            img = s.get('image')
            tbl = s.get('table')
            if img:
                data = base64.b64decode(img.split(',', 1)[1]) if isinstance(img, str) else img
                z.writestr(f'ppt/media/image{n}.png', data)
                rels.append(('rId2', 'image', f'../media/image{n}.png'))
                pw, ph = _png_size(data)
                box_h = avail if not tbl else int(avail * 0.55)
                scale = min(cw / pw, box_h / ph)
                iw, ih = int(pw * scale), int(ph * scale)
                shapes.append(_pic(5, 'rId2', mx + (cw - iw) // 2, y, iw, ih))
                y += ih + 90000
                avail -= ih + 90000
            if tbl and tbl.get('columns'):
                shapes.append(_table(6, mx, y, cw, tbl['columns'], tbl.get('rows') or [], avail, tbl.get('align'), tbl.get('widths')))
            if s.get('note'):
                shapes.append(_text(7, 'Note', mx, H - 480000 - note_h, cw, note_h, s['note'], 1000, False, INK))
            shapes.append(_text(8, 'Footer', mx, H - 360000, cw - 900000, 200000, footer, 800, False, '8A909A'))
            shapes.append(_text(9, 'Page', W - mx - 800000, H - 360000, 800000, 200000, str(n), 800, False, '8A909A', 'r'))
            z.writestr(f'ppt/slides/slide{n}.xml', XML + f'<p:sld {NS}><p:cSld><p:spTree>{_TREE0}{"".join(shapes)}</p:spTree></p:cSld>'
                                                         '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>')
            z.writestr(f'ppt/slides/_rels/slide{n}.xml.rels', _rels(rels))
            types.append(f'<Override PartName="/ppt/slides/slide{n}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>')
            pres_rels.append((f'rId{n + 2}', 'slide', f'slides/slide{n}.xml'))
            sld_ids += f'<p:sldId id="{255 + n}" r:id="rId{n + 2}"/>'
        with open(LOGO, 'rb') as f:
            z.writestr('ppt/media/logo.png', f.read())
        z.writestr('[Content_Types].xml', XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' + ''.join(types) + '</Types>')
        z.writestr('_rels/.rels', _rels([('rId1', 'officeDocument', 'ppt/presentation.xml')]))
        z.writestr('ppt/presentation.xml', XML + f'<p:presentation {NS}><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
                                                 f'<p:sldIdLst>{sld_ids}</p:sldIdLst><p:sldSz cx="{W}" cy="{H}"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>')
        z.writestr('ppt/_rels/presentation.xml.rels', _rels(pres_rels))
        z.writestr('ppt/slideMasters/slideMaster1.xml', _MASTER)
        z.writestr('ppt/slideMasters/_rels/slideMaster1.xml.rels', _rels([('rId1', 'slideLayout', '../slideLayouts/slideLayout1.xml'), ('rId2', 'theme', '../theme/theme1.xml')]))
        z.writestr('ppt/slideLayouts/slideLayout1.xml', _LAYOUT)
        z.writestr('ppt/slideLayouts/_rels/slideLayout1.xml.rels', _rels([('rId1', 'slideMaster', '../slideMasters/slideMaster1.xml')]))
        z.writestr('ppt/theme/theme1.xml', _THEME)
    return path
