"""One-click board packet: a branded PDF and PowerPoint with the executive summary, early-warning flags, key
scorecard, five-year trends, the what-if plan and the peer group."""
import io
import os
import re
import tempfile
from xml.sax.saxutils import escape

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.pagesizes import letter  # noqa: E402
from reportlab.lib.styles import ParagraphStyle  # noqa: E402
from reportlab.lib.units import inch  # noqa: E402
from reportlab.platypus import CondPageBreak, Image, KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle  # noqa: E402
from reportlab.platypus.flowables import Flowable  # noqa: E402

import analyzer  # noqa: E402
import brand  # noqa: E402
import foresight  # noqa: E402
import pptx_lite  # noqa: E402
from peer_report import BRAND, DARK_RED, GOLD, GRAY, GREEN, MID_GRAY, RED, TEAL, WARM_GRAY, ENGINES, PctBar, polish  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'output')
AMBER = '#C9A227'
FLAG_COLOR = {'red': DARK_RED, 'yellow': AMBER, 'green': GREEN}
FLAG_WORD = {'red': 'Red', 'yellow': 'Watch', 'green': 'OK'}
TREND = {'cu': ['roa', 'nim', 'efficiency', 'net_worth', 'delinquency', 'loan_growth'],
         'bank': ['roaa', 'nim', 'efficiency', 'leverage', 'noncurrent', 'loan_growth']}


def qlabel(p):
    return f'Q{int(p[5:7]) // 3} {p[:4]}'


def f(v, kind):
    if v is None or (isinstance(v, float) and not np.isfinite(v)):
        return 'n/a'
    if kind in ('pct', 'rate'):
        return f'{v * 100:.2f}%'
    if kind == 'usd':
        a = abs(v)
        s = f'${a / 1e9:,.2f}B' if a >= 1e9 else f'${a / 1e6:,.1f}M' if a >= 1e6 else f'${a / 1e3:,.0f}K' if a >= 1e4 else f'${a:,.0f}'
        return ('-' if v < 0 else '') + s
    if kind == 'x':
        return f'{v:.2f}x'
    if kind == 'int':
        return f'{v:,.0f}'
    return f'{v:,.2f}'


def delta(a, b, kind):
    if a is None or b is None:
        return ''
    if kind in ('pct', 'rate'):
        d = (a - b) * 100
        return ('+' if d > 0.005 else '') + f'{d:.2f} pts'.replace('-0.00', '0.00')
    if b:
        return f'{(a / b - 1) * 100:+.1f}%'
    return ''


class Dot(Flowable):
    def __init__(self, status, size=7):
        super().__init__()
        self.status, self.width, self.height = status, size, size

    def draw(self):
        self.canv.setFillColor(colors.HexColor(FLAG_COLOR.get(self.status, MID_GRAY)))
        self.canv.circle(self.width / 2, self.height / 2, self.width / 2, stroke=0, fill=1)


def _ord(n):
    return analyzer._ord(n)


# --------------------------------------------------------------------------- data
def gather(req):
    kind = 'bank' if req.get('type') == 'bank' else 'cu'
    an = analyzer.get(kind)
    period = an.req_period(req)
    keys = [k for k in (req.get('metrics') or []) if k] or list(__import__('library').SCORECARD[kind])
    requested = list(keys)
    for k in TREND[kind]:
        if k not in keys:
            keys.append(k)
    base = dict(type=kind, subject=req.get('subject'), groups=req.get('groups'), period=period, mode=req.get('mode'))
    res = analyzer.analyze(dict(base, metrics=keys, years=5, freq='q'))
    if not res.get('subject'):
        raise ValueError('Pick an institution for the board packet.')
    res['insights'] = analyzer.narrative(res)
    res['_requested'] = requested
    for g in res['groups']:                       # readable names for the roster (the app's own casing rules)
        for r in g.get('roster') or []:
            r['display'] = an.display_name(r['id'], period)
    fl = foresight.flags(base)
    pl = foresight.plan(dict(base, drivers=req.get('drivers') or {}))
    return kind, an, period, res, fl, pl, bool(req.get('drivers'))


def trend_png(kind, res):
    by = {m['key']: m for m in res['metrics'] if not m.get('error')}
    fig, axes = plt.subplots(2, 3, figsize=(10, 5.2))
    ps = res['periods']
    x = list(range(len(ps)))
    for ax, key in zip(axes.flat, TREND[kind]):
        m = by.get(key)
        if not m:
            ax.axis('off')
            continue
        s = [np.nan if v is None else v * 100 for v in (m['subject'] or [])]
        g = [np.nan if v is None else v * 100 for v in m['groups'][0]]
        ax.plot(x, s, color=RED, lw=2.2, marker='o', ms=2.6, label=res['subject']['name'][:28])
        ax.plot(x, g, color=GOLD, lw=1.6, ls='--', label='Peers')
        ax.set_title(m['label'], fontsize=9.5, color='#222', loc='left', fontweight='bold')
        ticks = [i for i, p in enumerate(ps) if p.endswith('-12')] or x[::4]
        ax.set_xticks(ticks)
        ax.set_xticklabels([ps[i][:4] for i in ticks], fontsize=7.5)
        ax.tick_params(axis='y', labelsize=7.5, colors=GRAY)
        ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f'{v:.1f}%'))
        for sp in ('top', 'right'):
            ax.spines[sp].set_visible(False)
        for sp in ('left', 'bottom'):
            ax.spines[sp].set_color(WARM_GRAY)
        ax.grid(axis='y', color=WARM_GRAY, lw=0.6)
    axes.flat[0].legend(fontsize=7.5, frameon=False, loc='best')
    fig.tight_layout()
    b = io.BytesIO()
    fig.savefig(b, format='png', dpi=200)
    plt.close(fig)
    return b.getvalue()


# --------------------------------------------------------------------------- PDF
def write_pdf(path, kind, period, res, fl, pl, custom_plan, png):
    eng = ENGINES[kind]
    subj, g0 = res['subject'], res['groups'][0]
    name = subj['name']
    st = {
        'title': ParagraphStyle('t', fontName='Helvetica-Bold', fontSize=22, textColor=colors.HexColor(RED), leading=26),
        'sub': ParagraphStyle('s', fontName='Helvetica', fontSize=10.5, textColor=colors.HexColor(GRAY), leading=14),
        'h': ParagraphStyle('h', fontName='Helvetica-Bold', fontSize=12.5, textColor=colors.HexColor(RED), spaceBefore=10,
                            spaceAfter=5),
        'body': ParagraphStyle('b', fontName='Helvetica', fontSize=9, textColor=colors.HexColor('#222222'), leading=12),
        'cell': ParagraphStyle('c', fontName='Helvetica', fontSize=7.6, leading=9.2),
        'why': ParagraphStyle('w', fontName='Helvetica', fontSize=7.3, leading=8.8, textColor=colors.HexColor(GRAY)),
        'th': ParagraphStyle('th', fontName='Helvetica-Bold', fontSize=7.8, textColor=colors.white, leading=9.2),
        'small': ParagraphStyle('sm', fontName='Helvetica', fontSize=7, textColor=colors.HexColor(GRAY), leading=9),
        'goal': ParagraphStyle('g', fontName='Helvetica', fontSize=9, leading=12, textColor=colors.HexColor('#222222'),
                               backColor=colors.HexColor('#FBF8F1'), borderPadding=6, borderColor=colors.HexColor(GOLD),
                               borderWidth=0, leftIndent=6, spaceBefore=6, spaceAfter=6),
    }
    doc = SimpleDocTemplate(path, pagesize=letter, leftMargin=0.6 * inch, rightMargin=0.6 * inch, topMargin=0.85 * inch,
                            bottomMargin=0.6 * inch, title=f'{name}: board packet {qlabel(period)}', author=BRAND)

    def chrome(c, d):
        c.saveState()
        c.setFillColor(colors.HexColor(RED))
        c.rect(0, letter[1] - 0.22 * inch, letter[0], 0.22 * inch, stroke=0, fill=1)
        c.setFillColor(colors.HexColor(GOLD))
        c.rect(0, letter[1] - 0.25 * inch, letter[0], 0.03 * inch, stroke=0, fill=1)
        av = 'AV’s '
        x = letter[0] - 0.6 * inch - c.stringWidth(av, 'Times-Italic', 11) - c.stringWidth('Peer Benchmark', 'Times-Roman', 11)
        c.setFont('Times-Italic', 11)
        c.drawString(x, letter[1] - 0.48 * inch, av)
        c.setFillColor(colors.HexColor(RED))
        c.setFont('Times-Roman', 11)
        c.drawString(x + c.stringWidth(av, 'Times-Italic', 11), letter[1] - 0.48 * inch, 'Peer Benchmark')
        if os.path.exists(brand.LOGO_NAVY):
            c.drawImage(brand.LOGO_NAVY, x - 0.36 * inch, letter[1] - 0.53 * inch, width=0.3 * inch, height=0.26 * inch,
                        mask='auto', preserveAspectRatio=True)
        c.setFont('Helvetica', 7)
        c.setFillColor(colors.HexColor(MID_GRAY))
        if d.page > 1:
            c.drawString(0.6 * inch, letter[1] - 0.48 * inch, f'{name} · board packet · {qlabel(period)}')
        c.drawString(0.6 * inch, 0.35 * inch, f'Source: {eng.SOURCE_NOTE}, {qlabel(period)}. Prepared with {BRAND}.')
        c.drawRightString(letter[0] - 0.6 * inch, 0.35 * inch, f'Page {d.page}')
        c.restoreState()

    thl = ParagraphStyle('thl', parent=st['th'], alignment=0)
    thr = ParagraphStyle('thr2', parent=st['th'], alignment=2)

    def table(rows, widths, extra=(), header=RED, zebra=True, left=(0,)):
        rows = [[Paragraph(escape(c), thl if j in left else thr) if isinstance(c, str) else c for j, c in enumerate(rows[0])]] + rows[1:]
        t = Table(rows, colWidths=[w * inch for w in widths], repeatRows=1)
        style = [('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(header)), ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                 ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'), ('FONTSIZE', (0, 0), (-1, -1), 7.8),
                 ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
                 ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]
        style += [('ALIGN', (j, 0), (j, -1), 'LEFT') for j in left]
        if zebra:
            style.append(('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F6F3EC')]))
        t.setStyle(TableStyle(style + list(extra)))
        return t

    def head(text, room=1.6):
        return [CondPageBreak(room * inch), Paragraph(text, st['h'])]

    story = [Paragraph(escape(name), st['title']),
             Paragraph(f'Board packet · {qlabel(period)} · {escape(str(subj.get("city") or "").title())}'
                       f'{", " if subj.get("city") else ""}{subj["state"]} · {f(subj["assets"], "usd")} in assets', st['sub']),
             Paragraph(f'Compared with <b>{g0["n"]}</b> peers: {escape(g0["name"])}. Peer value: {escape(res["mode_label"].lower())}.',
                       st['sub'])]
    if g0.get('note'):
        story.append(Paragraph(escape(g0['note']), ParagraphStyle('n', parent=st['small'], textColor=colors.HexColor(DARK_RED))))

    # executive summary
    story += head('Executive summary')
    mark = {'strength': ('▲', GREEN), 'weakness': ('▼', DARK_RED), 'gain': ('↗', GREEN), 'slip': ('↘', DARK_RED)}
    lines = [fl['headline']] + [i['text'] for i in res['insights'] if i['kind'] == 'summary']
    for t in lines:
        story.append(Paragraph(escape(t), ParagraphStyle('x', parent=st['body'], fontName='Helvetica-Bold', spaceAfter=3)))
    for i in res['insights']:
        if i['kind'] in mark:
            sym, col = mark[i['kind']]
            sym = {'▲': '+', '▼': '-', '↗': '+', '↘': '-'}[sym]          # Helvetica has no arrows
            story.append(Paragraph(f'<font color="{col}"><b>{sym}</b></font>&nbsp; {escape(i["text"])}',
                                   ParagraphStyle('y', parent=st['body'], leftIndent=10, firstLineIndent=-10, spaceAfter=2)))
    story.append(Spacer(1, 6))
    tiles = [[Paragraph(f'<b>{escape(a["name"])}</b>', st['cell']) for a in fl['areas']],
             [Table([[Dot(a['status']), Paragraph(FLAG_WORD[a['status']], st['cell'])]], colWidths=[0.14 * inch, 0.8 * inch],
                    style=[('LEFTPADDING', (0, 0), (-1, -1), 0), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')]) for a in fl['areas']]]
    w = 7.3 / max(len(fl['areas']), 1)
    t = Table(tiles, colWidths=[w * inch] * len(fl['areas']))
    t.setStyle(TableStyle([('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor(WARM_GRAY)),
                           ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor(WARM_GRAY)),
                           ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#FCFBF8')), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')]))
    story += [t, Spacer(1, 4)]

    # early-warning flags
    story += head('Early-warning flags')
    rows = [['', 'Indicator', 'Value', 'Peer median', 'Percentile', 'Why']]
    extra = []
    items = [(a['name'], i) for a in fl['areas'] for i in a['items']]
    items.sort(key=lambda t: -{'red': 2, 'yellow': 1, 'green': 0}[t[1]['status']])
    for area, i in items:
        rows.append([Dot(i['status']), Paragraph(f'{escape(i["label"])}<br/><font color="{MID_GRAY}" size="6.3">{escape(area)}</font>', st['cell']),
                     f(i['value'], i['fmt']), f(i['median'], i['fmt']),
                     '' if i['hib'] is None or i['peer_pct'] is None else f'{i["peer_pct"]:.0f}',
                     Paragraph(escape(' '.join(i['why']) or 'Within normal range.'), st['why'])])
    story.append(table(rows, [0.22, 2.1, 0.75, 0.8, 0.78, 2.65], extra, left=(0, 1, 5)))
    story.append(Paragraph('Red: a regulatory line is crossed, the institution is losing money, or it is in the worst 10% of '
                           'peers on a core ratio and worse for 3 quarters in a row. Watch: bottom quarter of peers, near a regulatory line, an '
                           'outlier on a mix ratio, or worse for 3 quarters in a row. Percentile: 100 = best. These flags use '
                           'public call report data only and are not a CAMELS rating.', st['small']))

    # scorecard
    story += head('Key scorecard', 2.5)
    rows = [['Ratio', name[:30], 'Peers', 'Median',
             'Rank', 'Percentile', '1-yr change']]
    req_keys = [m for m in res['metrics'] if not m.get('error') and m.get('latest')]
    shown = [m for m in req_keys if m['key'] in res['_requested']]
    for m in shown:
        L = m['latest']
        rows.append([Paragraph(escape(m['label']), st['cell']), f(L['value'], m['fmt']), f(L['peer'], m['fmt']),
                     f(L['median'], m['fmt']), '' if L.get('neutral') or not L['rank'] else f'{L["rank"]} / {L["of"]}',
                     '' if L.get('neutral') else PctBar(L['pct'], width=0.95 * inch), delta(L['value'], L.get('value_py'), m['fmt'])])
    story.append(table(rows, [2.5, 1.0, 0.9, 0.9, 0.7, 1.05, 0.85], [('FONTNAME', (1, 1), (1, -1), 'Helvetica-Bold')], left=(0, 5)))

    # trends
    story += head('Five-year trend vs peers', 4.4)
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, 'trend.png')
        with open(p, 'wb') as fh:
            fh.write(png)
        story.append(Image(p, width=7.3 * inch, height=7.3 * inch * 5.2 / 10))
        story.append(Paragraph('Peers: the same group, held fixed, using today\'s members for every quarter.', st['small']))

        # plan
        story += head('What-if plan: next 12 months' + ('' if custom_plan else ' at last year\'s pace'), 6.2)
        for t in pl['summary']:
            sym = {'gain': f'<font color="{GREEN}"><b>+</b></font>&nbsp; ', 'slip': f'<font color="{DARK_RED}"><b>-</b></font>&nbsp; '}.get(t['kind'], '')
            story.append(Paragraph(sym + escape(t['text']), ParagraphStyle('ps', parent=st['body'], spaceAfter=2,
                                                                           fontName='Helvetica-Bold' if t['kind'] == 'summary' else 'Helvetica')))
        if pl['goal']:
            story.append(Paragraph(f'<b>{"Goal met" if pl["goal"]["met"] else "What it takes"}:</b> {escape(pl["goal"]["text"])}', st['goal']))
        drv = [['Assumption', 'Plan', 'Last 12 mo.']] + [
            [d['label'], f'{d["value"]:g} bp' if d['unit'] == 'bp' else f'{d["value"]:.2f}%',
             '0 bp' if d['unit'] == 'bp' else f'{d["base"]:.2f}%'] for d in pl['drivers']]
        rat = [['Ratio', 'Today', 'Plan', 'Pctl today', 'Pctl plan']] + [
            [Paragraph(escape(r['label']), st['cell']), f(r['now'], r['fmt']), f(r['plan'], r['fmt']),
             '' if r['neutral'] or r['now_pct'] is None else f'{r["now_pct"]:.0f}',
             '' if r['neutral'] or r['plan_pct'] is None else f'{r["plan_pct"]:.0f}'] for r in pl['rows']]
        two = Table([[table(drv, [1.65, 0.6, 0.7]), table(rat, [1.6, 0.62, 0.62, 0.55, 0.55])]],
                    colWidths=[3.1 * inch, 4.2 * inch])
        two.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 0)]))
        story.append(two)
        money = [['Pro forma', 'Today', 'Plan', 'Change']] + [
            [m['label'], f(m['now'], 'usd'), f(m['plan'], 'usd'), '' if m['chg'] is None else f'{m["chg"] * 100:+.1f}%']
            for m in pl['money'] if m.get('style') != 'h']
        story += [Spacer(1, 6), KeepTogether([table(money, [2.6, 1.2, 1.2, 0.9]),
                  Paragraph('Balances at quarter end; income and expense year-to-date annualized. Borrowings fill any funding gap; '
                            'net income adds to capital. Each ratio is today\'s value plus the change the model shows. The plan is '
                            'ranked against the peers\' values today. Percentile: 100 = best.', st['small'])])]

        # peers
        story += head('Peer group', 3)
        roster = g0.get('roster') or []
        if len(roster) > 30:
            story.append(Paragraph(f'Largest 30 of {len(roster)} peers shown.', st['small']))
        rows = [[eng.INST_WORD, 'City, state', 'Assets']] + [
            [Paragraph(escape(polish(r['display'])), st['cell']),
             f'{str(r["city"]).title()[:18]}, {r["state"]}', f(r['assets'], 'usd')] for r in roster[:30]]
        story.append(table(rows, [3.9, 2.0, 1.2], left=(0, 1)))
        story.append(Spacer(1, 6))
        story.append(Paragraph('Method: ratios follow the definitions in AV’s Peer Benchmark\'s library (Callahan conventions for '
                               'credit unions; FDIC/S&P-style definitions for banks). Income ratios are year-to-date annualized; '
                               'averages use the current and prior year-end balances. Peer values are computed across the group '
                               'as stated above.', st['small']))
        doc.build(story, onFirstPage=chrome, onLaterPages=chrome)


# --------------------------------------------------------------------------- PowerPoint
def write_pptx(path, kind, period, res, fl, pl, custom_plan, png):
    subj, g0 = res['subject'], res['groups'][0]
    name = subj['name']
    sub = f'{qlabel(period)} · vs {g0["n"]} peers: {g0["name"]}'
    mark = {'strength': '▲ ', 'weakness': '▼ ', 'gain': '↗ ', 'slip': '↘ '}
    lines = [fl['headline']] + [mark.get(i['kind'], '') + i['text'] for i in res['insights']][:10]
    slides = [{'title': f'{name}: board packet', 'subtitle': sub,
               'table': {'columns': ['Executive summary'], 'rows': [[t] for t in lines], 'align': ['l'], 'widths': [1.0]}}]
    rows = []
    for a in fl['areas']:
        bad = [i for i in a['items'] if i['status'] != 'green']
        rows.append([a['name'], FLAG_WORD[a['status']], '; '.join(f'{i["label"]} ({FLAG_WORD[i["status"]].lower()})' for i in bad)[:220] or 'No flags'])
    slides.append({'title': 'Early-warning flags', 'subtitle': fl['headline'], 'table': {'columns': ['Area', 'Status', 'Flagged indicators'], 'rows': rows,
                                                                                          'align': ['l', 'l', 'l'], 'widths': [0.2, 0.1, 0.7]}})
    sc = [m for m in res['metrics'] if not m.get('error') and m.get('latest') and m['key'] in res['_requested']]
    srows = [[m['label'], f(m['latest']['value'], m['fmt']), f(m['latest']['peer'], m['fmt']),
              '' if m['latest'].get('neutral') or not m['latest']['rank'] else f'{m["latest"]["rank"]} / {m["latest"]["of"]}',
              '' if m['latest'].get('neutral') or m['latest']['pct'] is None else f'{m["latest"]["pct"]:.0f}'] for m in sc]
    for i in range(0, len(srows), 16):
        slides.append({'title': 'Key scorecard' + (f' ({i // 16 + 1})' if len(srows) > 16 else ''), 'subtitle': sub,
                       'table': {'columns': ['Ratio', name[:24], 'Peers', 'Rank', 'Percentile'], 'rows': srows[i:i + 16]}})
    slides.append({'title': 'Five-year trend vs peers', 'subtitle': sub, 'image': png})
    slides.append({'title': 'What-if plan: next 12 months' + ('' if custom_plan else " at last year's pace"),
                   'subtitle': 'Peers held at today\'s values. Percentile: 100 = best.',
                   'table': {'columns': ['Ratio', 'Today', 'Plan', 'Pctl today', 'Pctl plan'],
                             'rows': [[r['label'], f(r['now'], r['fmt']), f(r['plan'], r['fmt']),
                                       '' if r['neutral'] or r['now_pct'] is None else f'{r["now_pct"]:.0f}',
                                       '' if r['neutral'] or r['plan_pct'] is None else f'{r["plan_pct"]:.0f}'] for r in pl['rows']]},
                   'note': (pl['goal'] or {}).get('text', '')})
    slides.append({'title': 'Plan assumptions and pro forma', 'table': {'columns': ['Item', 'Today', 'Plan'], 'rows':
                   [[d['label'], '0 bp' if d['unit'] == 'bp' else f'{d["base"]:.2f}%', f'{d["value"]:g} bp' if d['unit'] == 'bp' else f'{d["value"]:.2f}%']
                    for d in pl['drivers']] + [[m['label'], f(m['now'], 'usd'), f(m['plan'], 'usd')] for m in pl['money'] if m.get('style') != 'h']}})
    roster = g0.get('roster') or []
    slides.append({'title': 'Peer group', 'subtitle': f'{g0["name"]} ({g0["n"]})' + (' · largest 16 shown' if len(roster) > 16 else ''),
                   'table': {'columns': ['Institution', 'City, state', 'Assets'],
                             'rows': [[polish(r['display']),
                                       f'{str(r["city"]).title()}, {r["state"]}', f(r['assets'], 'usd')] for r in roster[:16]]}})
    pptx_lite.build(path, slides)


def build(req):
    kind, an, period, res, fl, pl, custom_plan = gather(req)
    png = trend_png(kind, res)
    name = re.sub(r'[^\w\-. ()&,]+', ' ', f'{res["subject"]["name"]} board packet {qlabel(period)}').strip()[:120]
    os.makedirs(OUT, exist_ok=True)
    write_pdf(os.path.join(OUT, name + '.pdf'), kind, period, res, fl, pl, custom_plan, png)
    write_pptx(os.path.join(OUT, name + '.pptx'), kind, period, res, fl, pl, custom_plan, png)
    from urllib.parse import quote
    return {'name': name, 'pdf': f'/files/{quote(name)}.pdf', 'pptx': f'/files/{quote(name)}.pptx'}
