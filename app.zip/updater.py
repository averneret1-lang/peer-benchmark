"""Scheduled data updates: fetch a new quarter only when it could plausibly be published.

Regulators publish call report data on a lag after each quarter end. Checking outside that window is
pointless, so a source is "due" only when the next quarter's publication window has opened, and then
at most once a week until the quarter arrives. Plain Python: no AI model or tokens are involved.
  - banks (FDIC BankFind API): from ~40 days after quarter end (Q2 2026 appeared Aug 19, day 50)
  - credit unions (NCUA bulk zip): from ~50 days after quarter end
"""
import json
import os
import time
import urllib.request
import zipfile
from datetime import date, datetime, timedelta

import bank_engine
import peer_engine

HERE = os.path.dirname(os.path.abspath(__file__))
STATE_PATH = os.path.join(HERE, 'data', 'update_state.json')
LAG_DAYS = {'bank': 40, 'cu': 50}
MIN_INTERVAL = timedelta(days=7)   # at most one check per source per week
LABEL = {'bank': 'banks', 'cu': 'credit unions'}


# --------------------------------------------------------------------------- quarters

def next_quarter(period):
    y, m = int(period[:4]), int(period[5:7]) + 3
    return f'{y + (m > 12):04d}-{(m - 1) % 12 + 1:02d}'


def quarter_end(period):
    y, m = int(period[:4]), int(period[5:7])
    return date(y, m, 31 if m in (3, 12) else 30)


def latest_cached(kind):
    if kind == 'bank':
        files = [f[:7] for f in os.listdir(bank_engine.CACHE) if f.endswith('.json')] \
            if os.path.isdir(bank_engine.CACHE) else []
    else:
        files = [f[17:24] for f in os.listdir(peer_engine.NCUA_CACHE) if f.startswith('call-report-data-')
                 and f.endswith('.zip')]
    return max(files) if files else None


def window_opens(kind):
    """Date from which the quarter after the newest cached one could be published."""
    return quarter_end(next_quarter(latest_cached(kind))) + timedelta(days=LAG_DAYS[kind])


# --------------------------------------------------------------------------- state

def _load_state():
    try:
        with open(STATE_PATH) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save_state(state):
    os.makedirs(os.path.dirname(STATE_PATH), exist_ok=True)
    tmp = STATE_PATH + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, STATE_PATH)


def is_due(kind, now=None, state=None):
    now = now or datetime.now()
    state = state if state is not None else _load_state()
    if now.date() < window_opens(kind):
        return False
    last = state.get(kind, {}).get('last_check')
    return not last or now - datetime.fromisoformat(last) >= MIN_INTERVAL


def next_check(kind, state=None):
    """Human-readable date of the next scheduled check for a source."""
    state = state if state is not None else _load_state()
    opens = window_opens(kind)
    last = state.get(kind, {}).get('last_check')
    if last and datetime.now().date() >= opens:
        return max(opens, (datetime.fromisoformat(last) + MIN_INTERVAL).date())
    return opens


# --------------------------------------------------------------------------- fetchers

def _fetch_ncua():
    """Download NCUA quarters after the newest cached zip, while they exist. Returns new periods."""
    new = []
    p = next_quarter(latest_cached('cu'))
    while quarter_end(p) < date.today():
        dest = os.path.join(peer_engine.NCUA_CACHE, f'call-report-data-{p}.zip')
        url = f'https://ncua.gov/files/publications/analysis/call-report-data-{p}.zip'
        try:
            with urllib.request.urlopen(url, timeout=180) as r, open(dest + '.part', 'wb') as f:
                f.write(r.read())
            with zipfile.ZipFile(dest + '.part') as z:
                if z.testzip() is not None or not any(n.upper().startswith('FS220') for n in z.namelist()):
                    raise ValueError('incomplete zip')
            os.replace(dest + '.part', dest)
            new.append(p)
        except Exception:
            if os.path.exists(dest + '.part'):
                os.remove(dest + '.part')
            break
        p = next_quarter(p)
    return new


def _fetch_fdic():
    before = latest_cached('bank')
    bank_engine.refresh_cache(verbose=False)    # also re-pulls the latest two quarters (amendments)
    after = latest_cached('bank')
    out, p = [], before
    while after and p < after:
        p = next_quarter(p)
        out.append(p)
    return out


# --------------------------------------------------------------------------- run

def run(force=False, log=print):
    """Check every due source (or all, if force). Rebuilds panels when new data arrives.
    Returns {'new': {'bank': [...], 'cu': [...]}, 'checked': [kinds], 'errors': {kind: msg}}."""
    state = _load_state()
    result = {'new': {}, 'checked': [], 'errors': {}}
    for kind in ('bank', 'cu'):
        if not force and not is_due(kind, state=state):
            continue
        result['checked'].append(kind)
        try:
            new = _fetch_fdic() if kind == 'bank' else _fetch_ncua()
            result['new'][kind] = new
            state[kind] = {'last_check': datetime.now().isoformat(timespec='seconds'),
                           'last_result': ('new: ' + ', '.join(new)) if new else 'nothing new yet',
                           'latest': latest_cached(kind)}
            log(f'update check {kind}: {state[kind]["last_result"]}')
        except Exception as e:      # network down etc.: retry at the next interval
            result['errors'][kind] = f'{type(e).__name__}: {e}'
            state[kind] = {**state.get(kind, {}), 'last_check': datetime.now().isoformat(timespec='seconds'),
                           'last_result': f'failed: {e}'}
            log(f'update check {kind} failed: {e}')
    _save_state(state)
    if result['new'].get('cu'):
        peer_engine.build_panel(force=True)
    if result['checked'] and 'bank' in result['checked']:
        bank_engine.build_panel(force=True)  # re-pulled quarters may carry amendments
    return result


def coverage():
    """What data is on disk and when each source is next checked (for the app header)."""
    state = _load_state()
    return {k: {'through': latest_cached(k), 'next_check': next_check(k, state).isoformat(),
                'last_result': state.get(k, {}).get('last_result')} for k in ('bank', 'cu')}


if __name__ == '__main__':
    import sys
    print(run(force='--force' in sys.argv))
    print(coverage())
