"""Wide data stores behind the interactive Peer Analyzer.

The PDF reports (peer_engine / bank_engine) read ~30-45 fields. The analyzer needs everything:
  - credit unions: every numeric account on the NCUA 5300 (~3,300 codes per quarter), plus FOICU attributes
  - banks: ~300 FDIC BankFind financial fields per quarter, plus institution attributes

CU quarters are stored column-sparse (most accounts are zero for most credit unions), one folder per
quarter, memory-mapped so a single account is read without loading the rest. Bank quarters are small
enough to keep as one pickle each.

Both stores expose the same interface:
    periods()                 -> sorted ['2021-03', ...]
    ids(period)               -> np.ndarray[str]   institution ids reporting that quarter
    info(period)              -> DataFrame indexed by id (name, city, state, attributes)
    col(period, code)         -> float64 array aligned to ids(period); all-NaN when the code is not on the form
    has(period, code)         -> bool
    codes()                   -> {code: description}
"""
import glob
import json
import os
import threading
import time
import urllib.request
import zipfile
from datetime import date

import numpy as np
import pandas as pd

import peer_engine

HERE = os.path.dirname(os.path.abspath(__file__))
WIDE = os.path.join(HERE, 'data', 'wide')
HIST_DIR = os.path.join(HERE, 'data', 'ncua_history')     # quarters older than the report engine's cache
NCUA_FILES = 'https://ncua.gov/files/publications/'


def ncua_url(period):
    """NCUA renamed its quarterly zip several times."""
    y, m = period.split('-')
    if period >= '2016-03':
        return f'{NCUA_FILES}analysis/call-report-data-{period}.zip'
    if period in ('2015-06', '2015-09', '2015-12'):
        return f'{NCUA_FILES}analysis/Call-Report-Data-{period}.zip'
    if period == '2013-06':
        return f'{NCUA_FILES}data-apps/5300Data0613Final.zip'
    ext = 'Zip' if period in ('2010-06', '2010-12') else 'zip'
    return f'{NCUA_FILES}data-apps/QCR{y}{m}.{ext}'


def _download_ncua(p, dest_dir, log=print):
    """Fetch one NCUA quarter into dest_dir. Returns True if it is (now) there."""
    dest = os.path.join(dest_dir, f'call-report-data-{p}.zip')
    if os.path.exists(dest):
        return True
    try:
        req = urllib.request.Request(ncua_url(p), headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=300) as r:
            data = r.read()
        with open(dest + '.part', 'wb') as f:
            f.write(data)
        with zipfile.ZipFile(dest + '.part') as z:
            if not any(n.upper().split('/')[-1].startswith('FS220') for n in z.namelist()):
                raise ValueError('not a call report zip')
        os.replace(dest + '.part', dest)
        log(f'Downloaded NCUA {p} ({len(data) / 1e6:.1f} MB)')
        return True
    except Exception as e:
        log(f'NCUA {p} not downloaded: {e}')
        if os.path.exists(dest + '.part'):
            os.remove(dest + '.part')
        return False


def _quarters(first, stop):
    y, m = map(int, first.split('-'))
    while f'{y:04d}-{m:02d}' < stop:
        yield f'{y:04d}-{m:02d}'
        m += 3
        if m > 12:
            y, m = y + 1, 3


_LOCK = threading.RLock()
LIVE_FROM = '2021-03'      # the report engine's cache (peer_engine.NCUA_CACHE) starts here; older quarters go to HIST_DIR


def download_history(first='2006-03', log=print):
    """Fetch every NCUA quarter from `first` up to (not including) LIVE_FROM into data/ncua_history."""
    os.makedirs(HIST_DIR, exist_ok=True)
    return [p for p in _quarters(first, LIVE_FROM) if _download_ncua(p, HIST_DIR, log)]


def download_recent(log=print):
    """Fetch LIVE_FROM onward into peer_engine.NCUA_CACHE, stopping at the first quarter NCUA has not published."""
    os.makedirs(peer_engine.NCUA_CACHE, exist_ok=True)
    got, today = [], date.today()
    for p in _quarters(LIVE_FROM, '9999-12'):
        y, m = int(p[:4]), int(p[5:])
        if date(y, m, 28) >= today:
            break
        if not _download_ncua(p, peer_engine.NCUA_CACHE, log):
            break
        got.append(p)
    return got

def _strip_cols(df):
    df.columns = [str(c).strip().lstrip('﻿').lstrip('ï»¿').strip('"') for c in df.columns]
    return df


class _Base:
    kind = ''

    def __init__(self):
        self._cols = {}
        self._plist = None
        self._info = {}
        self._ids = {}
        self._pos = {}

    def reset(self):
        with _LOCK:
            self._cols.clear(); self._info.clear(); self._ids.clear(); self._pos.clear()
            self._plist = None

    def periods(self):
        if self._plist is None:
            self._plist = self._scan()
            self._pset = set(self._plist)
        return self._plist

    def exists(self, period):
        self.periods()
        return period in self._pset

    def latest(self):
        p = self.periods()
        return p[-1] if p else None

    def aligned(self, period, code, lag_period):
        """Account `code` in `lag_period`, re-indexed onto the institutions of `period` (NaN if absent)."""
        if lag_period == period:
            return self.col(period, code)
        if not self.exists(lag_period):
            return np.full(len(self.ids(period)), np.nan)
        key = (period, lag_period)
        pos = self._pos.get(key)
        if pos is None:
            pos = pd.Index(self.ids(lag_period)).get_indexer(self.ids(period))
            self._pos[key] = pos
        src = self.col(lag_period, code)
        out = np.full(len(pos), np.nan)
        ok = pos >= 0
        out[ok] = src[pos[ok]]
        return out

    def present(self, period, lag_period):
        """True where an institution of `period` also filed in `lag_period`."""
        if lag_period == period:
            return np.ones(len(self.ids(period)), dtype=bool)
        if not self.exists(lag_period):
            return np.zeros(len(self.ids(period)), dtype=bool)
        return pd.Index(self.ids(lag_period)).get_indexer(self.ids(period)) >= 0


# =========================================================================== credit unions

CU_INFO = ['CU_NAME', 'CITY', 'STATE', 'ZIP_CODE', 'STATE_CODE', 'COUNTY_CODE', 'CU_TYPE', 'TOM_CODE',
           'LIMITED_INC', 'IsMDI', 'REGION', 'Peer_Group', 'YEAR_OPENED', 'RSSD', 'SMSA', 'CharterState', 'STREET']
CU_TYPES = {'1': 'Federal charter (FCU)', '2': 'State charter, federally insured (FISCU)',
            '3': 'State charter, privately insured'}
# NCUA field-of-membership (TOM) code families.
TOM_GROUPS = {
    'Community': ['00', '50', '51', '52', '53', '54', '66'],
    'Multiple common bond': ['98', '99'] + [f'{i:02d}' for i in range(20, 50) if i not in (34, 35, 36)],
    'Single common bond: occupational': ['04', '05', '06', '10', '11', '12', '13', '14', '15', '20', '21', '22', '23', '24',
                                         '34', '35', '36', '40', '41', '42', '43', '44', '49'],
    'Single common bond: associational': ['01', '02', '03'],
}


class CUStore(_Base):
    kind = 'cu'
    root = os.path.join(WIDE, 'cu')

    def _scan(self):
        if not os.path.isdir(self.root):
            return []
        return sorted(d for d in os.listdir(self.root)
                      if os.path.exists(os.path.join(self.root, d, 'meta.json')))

    def _meta(self, period):
        m = self._ids.get(period)
        if m is None:
            with open(os.path.join(self.root, period, 'meta.json')) as f:
                meta = json.load(f)
            d = os.path.join(self.root, period)
            m = {'ids': np.array(meta['ids'], dtype=object),
                 'col_of': {c: i for i, c in enumerate(meta['accounts'])},
                 'vals': np.load(os.path.join(d, 'vals.npy'), mmap_mode='r'),
                 'rows': np.load(os.path.join(d, 'rows.npy'), mmap_mode='r'),
                 'indptr': np.load(os.path.join(d, 'indptr.npy'))}
            self._ids[period] = m
        return m

    def ids(self, period):
        return self._meta(period)['ids']

    def has(self, period, code):
        return self.exists(period) and code in self._meta(period)['col_of']

    def col(self, period, code):
        key = (period, code)
        v = self._cols.get(key)
        if v is None:
            m = self._meta(period)
            j = m['col_of'].get(code)
            if j is None:
                v = np.full(len(m['ids']), np.nan)
            else:
                v = np.zeros(len(m['ids']))
                a, b = m['indptr'][j], m['indptr'][j + 1]
                v[np.asarray(m['rows'][a:b])] = np.asarray(m['vals'][a:b])
            v.setflags(write=False)
            if len(self._cols) > 9000:
                self._cols.clear()
            self._cols[key] = v
        return v

    def info(self, period):
        df = self._info.get(period)
        if df is None:
            df = pd.read_pickle(os.path.join(self.root, period, 'info.pkl'))
            self._info[period] = df
        return df

    def codes(self):
        path = os.path.join(self.root, 'accounts.json')
        if os.path.exists(path):
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        return {}

    # ---- build
    def build_period(self, zip_path):
        period = os.path.basename(zip_path)[len('call-report-data-'):-4]
        with zipfile.ZipFile(zip_path) as z:
            member = {n.split('/')[-1].upper(): n for n in z.namelist()}     # older zips use lower-case names
            info = _strip_cols(pd.read_csv(z.open(member['FOICU.TXT']), encoding='latin-1', dtype=str))
            info['CU_NUMBER'] = info['CU_NUMBER'].str.strip()
            info = info.drop_duplicates('CU_NUMBER').set_index('CU_NUMBER')
            for c in CU_INFO:
                if c not in info.columns:
                    info[c] = ''
            info = info[CU_INFO].apply(lambda s: s.fillna('').astype(str).str.strip())
            ids = info.index.to_numpy(dtype=object)
            cols = {}
            for upper, name in sorted(member.items()):
                if not upper.startswith('FS220') or 'CUSO' in upper:
                    continue
                df = _strip_cols(pd.read_csv(z.open(name), encoding='latin-1', low_memory=False))
                df.columns = [c.upper() for c in df.columns]
                df['CU_NUMBER'] = df['CU_NUMBER'].astype(str).str.strip()
                df = df.drop_duplicates('CU_NUMBER').set_index('CU_NUMBER').reindex(ids)
                for c in df.columns:
                    if not c.startswith('ACCT_') or c[5:] in cols:
                        continue
                    cols[c[5:]] = pd.to_numeric(df[c], errors='coerce').to_numpy(dtype=float)
            names = {}
            try:
                desc = _strip_cols(pd.read_csv(z.open(member['ACCTDESC.TXT']), encoding='latin-1', dtype=str))
                for a, n, t in zip(desc['Account'], desc['AcctName'], desc['TableName']):
                    names[str(a).strip().upper().replace('ACCT_', '')] = [str(n).strip(), str(t).strip()]
            except Exception:
                pass
        accounts = sorted(cols)
        vals, rows, indptr = [], [], [0]
        for a in accounts:
            v = cols[a]
            nz = np.flatnonzero(~np.isnan(v) & (v != 0))
            rows.append(nz.astype(np.int32))
            vals.append(v[nz])
            indptr.append(indptr[-1] + len(nz))
        d = os.path.join(self.root, period)
        tmp = d + '.tmp'
        os.makedirs(tmp, exist_ok=True)
        np.save(os.path.join(tmp, 'vals.npy'), np.concatenate(vals) if vals else np.zeros(0))
        np.save(os.path.join(tmp, 'rows.npy'), np.concatenate(rows) if rows else np.zeros(0, dtype=np.int32))
        np.save(os.path.join(tmp, 'indptr.npy'), np.array(indptr, dtype=np.int64))
        info.to_pickle(os.path.join(tmp, 'info.pkl'))
        with open(os.path.join(tmp, 'meta.json'), 'w') as f:
            json.dump({'ids': [str(i) for i in ids], 'accounts': accounts, 'built': time.time(),
                       'zip_size': os.path.getsize(zip_path)}, f)
        if os.path.isdir(d):
            import shutil
            self.reset()
            shutil.rmtree(d)
        os.replace(tmp, d)
        return period, names

    def build(self, log=print, force=False):
        """Build any quarter whose zip is newer than (or missing from) the store. Returns built periods."""
        os.makedirs(self.root, exist_ok=True)
        built, names = [], self.codes()
        zips = {os.path.basename(z): z for d in (HIST_DIR, peer_engine.NCUA_CACHE)       # the live cache wins
                for z in glob.glob(os.path.join(d, 'call-report-data-*.zip'))}
        for zp in [zips[k] for k in sorted(zips)]:
            period = os.path.basename(zp)[len('call-report-data-'):-4]
            mp = os.path.join(self.root, period, 'meta.json')
            if not force and os.path.exists(mp):
                try:
                    with open(mp) as f:
                        if json.load(f).get('zip_size') == os.path.getsize(zp):
                            continue
                except (OSError, ValueError):
                    pass
            log(f'Indexing NCUA 5300 {period} (all accounts)...')
            _, n = self.build_period(zp)
            for code, v in n.items():       # zips are read oldest first, so the newest description wins
                names[code] = v
            built.append(period)
        if built:
            with open(os.path.join(self.root, 'accounts.json'), 'w', encoding='utf-8') as f:
                json.dump(names, f)
            self.reset()
        return built

    def branches(self):
        """Branch / office list from the newest NCUA zip (cached)."""
        path = os.path.join(self.root, 'branches.pkl')
        zips = sorted(glob.glob(os.path.join(peer_engine.NCUA_CACHE, 'call-report-data-*.zip')))
        if not zips:                         # packaged build (website): branches ship as the cached table
            return pd.read_pickle(path) if os.path.exists(path) else pd.DataFrame()
        if os.path.exists(path) and os.path.getmtime(path) >= os.path.getmtime(zips[-1]):
            return pd.read_pickle(path)
        with zipfile.ZipFile(zips[-1]) as z:
            br = _strip_cols(pd.read_csv(z.open('Credit Union Branch Information.txt'), encoding='latin-1', dtype=str))
        keep = {'CU_NUMBER': 'id', 'CU_NAME': 'name', 'SiteName': 'site', 'SiteTypeName': 'site_type',
                'MainOffice': 'main', 'PhysicalAddressLine1': 'address', 'PhysicalAddressCity': 'city',
                'PhysicalAddressStateCode': 'state', 'PhysicalAddressPostalCode': 'zip',
                'PhysicalAddressCountyName2': 'county', 'MemberServices': 'member_services', 'ATM': 'atm',
                'DriveThru': 'drive_thru'}
        br = br[[c for c in keep if c in br.columns]].rename(columns=keep)
        br = br.apply(lambda s: s.fillna('').astype(str).str.strip())
        br.to_pickle(path)
        return br


# =========================================================================== banks

FDIC_API = 'https://api.fdic.gov/banks/financials'
BANK_INFO = ['CERT', 'NAMEFULL', 'CITY', 'STALP', 'ZIP', 'RSSDID', 'SPECGRP', 'BKCLASS', 'REGAGNT', 'CB', 'MUTUAL',
             'SUBCHAPS', 'CBSA', 'CBSANAME', 'STCNTY', 'ESTYMD', 'NAMEHCR', 'RSSDHCR', 'FDICDBS', 'STMULT', 'TRUST']
# Not dollars: ratios the FDIC publishes, counts, flags. Everything else is $ thousands on the API.
BANK_NON_DOLLAR = {
    'RBC1AAJ', 'RBC1RWAJ', 'RBCRWAJ', 'RBCT1CER', 'ROA', 'ROE', 'ROAPTX', 'NIMY', 'EEFFR', 'INTINCY', 'INTEXPY',
    'NONIIAY', 'NONIXAY', 'NOIJY', 'LNLSDEPR', 'NCLNLSR', 'NTLNLSR', 'LNATRESR', 'ELNATRY', 'ERNASTR', 'LNLSNTV',
    'DEPDASTR', 'EQCDIVNTINC', 'ASTEMPM', 'NPERFV', 'LNRESNCR', 'EQV', 'IDT1CER', 'IDT1RWAJR', 'ASSTLTR',
    'IDERNCVR', 'NUMEMP', 'OFFDOM', 'OFFFOR', 'DEPSMB', 'DEPLGB', 'NFAA',
}
BANK_FIELDS = """
ASSET ASSET5 ASSET2 ERNAST ERNAST5 EQ EQ5 EQTOT EQPP EQCS EQSUR EQUPTOT EQCCOMPI INTAN INTANGW LIAB LIABEQ
CHBAL CHBALI CHBALNI SC SC5 SCHA SCAF SCHF SCAA SCMTGBK SCUST SCUSA SCMUNI SCRDEBT SCEQ SCPLEDGE FREPO TRADE BKPREM ORE OA
LNLSNET LNLSGR LNLSGR5 LNATRES LNLSSALE UNINC
LNRE LNRECONS LNRECNFM LNRECNOT LNRENRES LNRENROW LNRENROT LNREMULT LNRERES LNRERSFM LNRERSF2 LNRELOC LNREAG LNCOMRE
LNCI LNCON LNCRCD LNAUTO LNCONOTH LNCONRP LNAG LNMUNI LS LNOTHER LNDEPAC LNFG
LNRE5 LNCI5 LNCON5 LNCRCD5 LNAUTO5 LNAG5 LNRERES5 LNCOMRE5 LNRECON5 LNRENRE5 LNREMUL5 LNRELOC5 LNREAG5
DEP DEP5 DEPDOM DEPFOR DEPI DEPNI DEPIDOM DEPNIDOM TRN NTR DDT TS NTRSMMDA NTRSOTH NTRTIME NTRCDSM NTRTMLG
NTRCDSMJ NTRTMLGJ BRO BROINS DEPLSNB COREDEP VOLIAB DEPINS DEPUNINS DEPLGAMT DEPSMAMT DEPSMB DEPLGB IRAKEOGH
FREPP OTHBRF OTHBOR OBOR5 SUBND ALLOTHL OTHBFHLB OTBFH1L OTBFH1T3 OTBFH3T5 OTBFHOV5
INTINC ILNDOM ILNLS ILNFOR ILS ISC IFREPO ICHBAL ITRADE IOTHII EINTEXP EDEP EDEPDOM EDEPFOR EFREPP ESUBND EOTHINT
EFHLBADV ESAVDP EOTHTIME ECD100 NIM ELNATR ELNLOS NONII IFIDUC ISERCHG IGLSEC IOTHFEE NETGNSLN NETGNAST IINSCOM
IINSUND IINVFEE IVENCAP ISERFEE ISECZ IOTNII NONIX ESAL EPREMAGG EOTHNINT EAMINTAN EINTGW EEFF IEFF PTAXNETINC
ITAX IBEFTAX IBEFXTR NETINC EXTRA EQCDIV EQCDIVC EQCDIVP NOIJ NETIMIN NETINBM
P3ASSET P9ASSET NAASSET NCLNLS NALNLS P3LNLS P9LNLS P3RE P9RE NARE P3CI P9CI NACI P3CON P9CON NACON P3CRCD P9CRCD
NACRCD P3AUTO P9AUTO NAAUTO NARERES P3RERES P9RERES NARECONS NARENRES NAREMULT NAAG P3AG RSLNLTOT RSLNLS
NCRE NCCI NCCON NCRERES
DRLNLS CRLNLS NTLNLS NTRE NTCI NTCON NTCRCD NTAUTO NTRERES NTRECONS NTRENRES NTREMULT NTAG NTRELOC NTCONOTH NTLS
DRRE DRCI DRCON
RBCT1J RBCT1 RBCT2 RBC RWAJ RWAJT RBC1AAJ RBC1RWAJ RBCRWAJ RBCT1CER RBCT1C AVASSETJ
ROA ROE ROAPTX NIMY EEFFR INTINCY INTEXPY NONIIAY NONIXAY NOIJY LNLSDEPR NCLNLSR NTLNLSR LNATRESR ELNATRY ERNASTR
LNLSNTV DEPDASTR EQCDIVNTINC ASTEMPM NPERFV LNRESNCR EQV ASSTLT ASSTLTR IDERNCVR
NUMEMP OFFDOM OFFFOR TFRA NFAA UC UCLN UCCRCD UCCOMRE UCLOC LOCCOM OBSDIR
""".split()
BANK_FIRST = '2021-03'
BKCLASS = {'N': 'National bank (OCC)', 'SM': 'State member bank (Fed)', 'NM': 'State nonmember bank (FDIC)',
           'SB': 'Savings bank', 'SA': 'Savings association', 'SI': 'State stock savings bank', 'OI': 'Insured U.S. branch of foreign bank'}


class BankStore(_Base):
    kind = 'bank'
    root = os.path.join(WIDE, 'bank')

    def _scan(self):
        if not os.path.isdir(self.root):
            return []
        return sorted({f[:7] for f in os.listdir(self.root) if len(f) == 11 and f[4] == '-' and f[-4:] in ('.npy', '.pkl')})

    def _save(self, period, out):
        """One quarter = a column-major float matrix (memory-mapped on read) + a small attribute table."""
        fields = [c for c in out.columns if c not in _BANK_INFO_OUT]
        base = os.path.join(self.root, period)
        np.save(base + '.tmp.npy', np.asfortranarray(out[fields].to_numpy(dtype=float)))
        out[_BANK_INFO_OUT].to_pickle(base + '.info.pkl')
        with open(base + '.cols.json', 'w') as f:
            json.dump(fields, f)
        os.replace(base + '.tmp.npy', base + '.npy')
        if os.path.exists(base + '.pkl'):
            os.remove(base + '.pkl')

    def _frame(self, period):
        d = self._info.get(period)
        if d is None:
            base = os.path.join(self.root, period)
            if not os.path.exists(base + '.npy'):          # first-generation store: one pickle per quarter
                self._save(period, pd.read_pickle(base + '.pkl'))
            with open(base + '.cols.json') as f:
                cols = json.load(f)
            info = pd.read_pickle(base + '.info.pkl')
            d = {'info': info, 'ids': info.index.to_numpy(dtype=object), 'col_of': {c: i for i, c in enumerate(cols)},
                 'mat': np.load(base + '.npy', mmap_mode='r')}
            self._info[period] = d
        return d

    def ids(self, period):
        return self._frame(period)['ids']

    def has(self, period, code):
        return self.exists(period) and code in self._frame(period)['col_of']

    def col(self, period, code):
        key = (period, code)
        v = self._cols.get(key)
        if v is None:
            d = self._frame(period)
            j = d['col_of'].get(code)
            v = np.array(d['mat'][:, j], dtype=float) if j is not None else np.full(len(d['ids']), np.nan)
            v.setflags(write=False)
            if len(self._cols) > 9000:
                self._cols.clear()
            self._cols[key] = v
        return v

    def info(self, period):
        return self._frame(period)['info']
    def codes(self):
        path = os.path.join(self.root, 'fields.json')
        if os.path.exists(path):
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        return {c: ['', ''] for c in BANK_FIELDS}

    # ---- build
    @staticmethod
    def _get(url):
        for attempt in range(4):
            try:
                with urllib.request.urlopen(url, timeout=180) as r:
                    return json.load(r)
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(3 * (attempt + 1))

    def fetch_period(self, period):
        repdte = period.replace('-', '') + ('31' if period[5:] in ('03', '12') else '30')
        fields = list(dict.fromkeys(BANK_FIELDS))
        frames = []
        chunks = [BANK_INFO] + [['CERT'] + fields[i:i + 130] for i in range(0, len(fields), 130)]
        for ch in chunks:
            url = f'{FDIC_API}?filters=REPDTE:{repdte}&fields={",".join(ch)}&limit=10000&format=json'
            rows = [r['data'] for r in self._get(url).get('data', [])]
            if not rows:
                return None
            f = pd.DataFrame(rows).drop(columns=['ID'], errors='ignore')
            f['CERT'] = f['CERT'].astype(int).astype(str)
            frames.append(f.drop_duplicates('CERT').set_index('CERT'))
        df = frames[0].join(frames[1:], how='left')
        for c in fields:
            df[c] = pd.to_numeric(df.get(c), errors='coerce')
        dollars = [c for c in fields if c not in BANK_NON_DOLLAR]
        df[dollars] = df[dollars] * 1000.0
        out = pd.DataFrame({
            'CU_NAME': df['NAMEFULL'].astype(str).str.strip(), 'CITY': df['CITY'].astype(str).str.strip(),
            'STATE': df['STALP'].astype(str).str.strip(), 'ZIP_CODE': df['ZIP'].astype(str),
            'Peer_Group': df['SPECGRP'].astype(str).str.replace('.0', '', regex=False),
            'BKCLASS': df['BKCLASS'].astype(str).str.strip(), 'REGAGNT': df['REGAGNT'].astype(str).str.strip(),
            'CB': df['CB'].astype(str).str.replace('.0', '', regex=False),
            'MUTUAL': df['MUTUAL'].astype(str).str.replace('.0', '', regex=False),
            'SUBCHAPS': df['SUBCHAPS'].astype(str).str.replace('.0', '', regex=False),
            'CBSA': df['CBSANAME'].fillna('').astype(str).str.strip(),
            'STCNTY': df['STCNTY'].astype(str).str.replace('.0', '', regex=False).str.zfill(5),
            'YEAR_OPENED': df['ESTYMD'].astype(str).str[:4], 'HOLDCO': df['NAMEHCR'].fillna('').astype(str).str.strip(),
            'RSSD': df['RSSDID'].astype(str).str.replace('.0', '', regex=False),
            'REGION': df['FDICDBS'].astype(str).str.replace('.0', '', regex=False),
        }, index=df.index)
        out = out.join(df[fields])
        os.makedirs(self.root, exist_ok=True)
        self._info.pop(period, None)
        self._save(period, out)
        return len(out)

    def build(self, log=print, refresh_recent=False):
        """Fetch missing quarters (and, when asked, re-pull the newest two, which banks can amend)."""
        os.makedirs(self.root, exist_ok=True)
        today = date.today()
        q = (today.month - 1) // 3
        last = f'{today.year:04d}-{q * 3:02d}' if q else f'{today.year - 1:04d}-12'
        have = self.periods()
        recent = set(have[-2:]) if refresh_recent else set()
        cu_first = (STORES['cu'].periods() or [BANK_FIRST])[0]       # keep bank history as deep as credit union history
        built, y, m = [], *map(int, min(BANK_FIRST, cu_first).split('-'))
        while f'{y:04d}-{m:02d}' <= last:
            p = f'{y:04d}-{m:02d}'
            stale = p in have and not set(BANK_FIELDS) <= set(self._frame(p)['col_of'])
            if p not in have or p in recent or stale:
                log(f'Fetching FDIC call report data {p} ({len(BANK_FIELDS)} fields)...')
                try:
                    n = self.fetch_period(p)
                except Exception as e:
                    log(f'  FDIC {p} failed: {e}')
                    n = None
                if n:
                    built.append(p)
            m += 3
            if m > 12:
                y, m = y + 1, 3
        if built:
            self.reset()
        self._write_fields()
        return built

    def _write_fields(self):
        path = os.path.join(self.root, 'fields.json')
        if os.path.exists(path):
            return
        try:
            import re
            txt = urllib.request.urlopen('https://api.fdic.gov/banks/docs/risview_properties.yaml', timeout=60).read().decode('utf-8', 'replace')
            names, cur = {}, None
            for ln in txt.splitlines():
                mm = re.match(r'^ {6}(\w+):\s*$', ln)
                if mm:
                    cur = mm.group(1)
                    continue
                mm = re.match(r'^ {8}title:\s*(.*)$', ln)
                if mm and cur:
                    names[cur] = mm.group(1).strip().strip('\'"')
                    cur = None
            with open(path, 'w', encoding='utf-8') as f:
                json.dump({c: [names.get(c, c).capitalize(), 'FDIC'] for c in BANK_FIELDS}, f)
        except Exception:
            pass


_BANK_INFO_OUT = ['CU_NAME', 'CITY', 'STATE', 'ZIP_CODE', 'Peer_Group', 'BKCLASS', 'REGAGNT', 'CB', 'MUTUAL',
                  'SUBCHAPS', 'CBSA', 'STCNTY', 'YEAR_OPENED', 'HOLDCO', 'RSSD', 'REGION']

STORES = {'cu': CUStore(), 'bank': BankStore()}


def build_all(log=print, refresh_recent=False):
    with _LOCK:
        return {'cu': STORES['cu'].build(log=log), 'bank': STORES['bank'].build(log=log, refresh_recent=refresh_recent)}


if __name__ == '__main__':
    import sys
    t = time.time()
    if '--history' in sys.argv:
        download_history(sys.argv[sys.argv.index('--history') + 1])
    print(build_all())
    for k, s in STORES.items():
        print(k, s.periods()[:1], '...', s.latest(), len(s.ids(s.latest())) if s.latest() else 0)
    print(f'{time.time() - t:.0f}s')
