"""Interactive Peer Analyzer: peer groups, trends, rankings, scorecards, statements, mergers, member value.

Built on wide_store (every 5300 account / ~300 FDIC fields), formula.py and library.py. Works the same
for credit unions and banks, and lets a credit union be compared with bank groups (and the reverse).
"""
import json
import os
import re
import threading

import numpy as np
import pandas as pd

import bank_engine
import formula as F
import library
import peer_engine
import wide_store

HERE = os.path.dirname(os.path.abspath(__file__))
USER_DIR = os.path.join(HERE, 'data', 'user')
ENGINES = {'cu': peer_engine, 'bank': bank_engine}
_ULOCK = threading.RLock()

MODES = {'agg': 'Weighted average', 'mean': 'Simple average', 'median': 'Median', 'tmean': 'Trimmed mean (5-95%)',
         'top10': 'Top 10%', 'top25': 'Top quartile', 'bot25': 'Bottom quartile', 'bot10': 'Bottom 10%'}
DEFAULT_MODE = {'cu': 'agg', 'bank': 'tmean'}


def _num(v):
    """JSON-safe float."""
    if v is None:
        return None
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    return None if (np.isnan(v) or np.isinf(v)) else v


def _ord(n):
    n = int(round(n))
    return f'{n}{"th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")}'


def stars(pct):
    """Callahan's star scale from a percentile (100 = best)."""
    if pct is None:
        return None
    return 1 if pct <= 10 else 2 if pct < 40 else 3 if pct <= 60 else 4 if pct < 90 else 5


# --------------------------------------------------------------------------- saved user content

def _user_path(name):
    return os.path.join(USER_DIR, name + '.json')


def user_load(name):
    try:
        with open(_user_path(name), encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def user_save(name, data):
    with _ULOCK:
        os.makedirs(USER_DIR, exist_ok=True)
        tmp = _user_path(name) + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=1)
        os.replace(tmp, _user_path(name))


# --------------------------------------------------------------------------- analyzer

class Analyzer:
    _inst = {}

    @classmethod
    def get(cls, kind):
        kind = 'bank' if kind == 'bank' else 'cu'
        if kind not in cls._inst:
            cls._inst[kind] = cls(kind)
        return cls._inst[kind]

    @classmethod
    def reset_all(cls):
        for s in wide_store.STORES.values():
            s.reset()
        for a in cls._inst.values():
            a._v.clear(); a._u.clear(); a._valid.clear(); a._posmap.clear()

    def __init__(self, kind):
        self.kind = kind
        self.store = wide_store.STORES[kind]
        self.eng = ENGINES[kind]
        self.base = library.metrics(kind)
        self._f, self._v, self._u, self._valid, self._posmap = {}, {}, {}, {}, {}
        self.asset_code = '010' if kind == 'cu' else 'ASSET'

    # ---- metric definitions
    def custom(self):
        try:
            stamp = os.path.getmtime(_user_path('formulas'))
        except OSError:
            stamp = 0
        if getattr(self, '_custom_stamp', None) == stamp:
            return self._custom
        out = {}
        for c in user_load('formulas').get(self.kind, []):
            out[c['key']] = dict(key=c['key'], label=c['label'], folder='My formulas', fmt=c.get('fmt', 'pct'),
                                 hib=c.get('hib'), f=c['f'], custom=True, desc=c.get('desc', ''))
        self._custom, self._custom_stamp = out, stamp
        self._f.clear(); self._v.clear()
        return out

    def all_metrics(self):
        return {**self.base, **self.custom()}

    def mdef(self, key):
        if key.startswith('='):                      # ad-hoc formula typed in the UI
            return dict(key=key, label=key[1:].strip(), folder='Ad hoc', fmt='num2', hib=None, f=key[1:])
        m = self.base.get(key) or self.custom().get(key)
        if m is None:
            raise F.FormulaError(f'Unknown metric: {key}')
        return m

    def _lookup(self, key):
        m = self.base.get(key) or self.custom().get(key)
        return m['f'] if m else None

    def formula(self, text):
        f = self._f.get(text)
        if f is None:
            f = F.Formula(text, self._lookup)
            if len(self._f) > 4000:
                self._f.clear()
            self._f[text] = f
        return f

    def check_formula(self, text):
        """Validate a formula; returns (ok, message, unknown codes)."""
        try:
            f = F.Formula(text, self._lookup)
        except F.FormulaError as e:
            return False, str(e), []
        known = self.store.codes()
        latest = self.store.latest()
        bad = [c for c in f.codes if c not in known and not self.store.has(latest, c)]
        if bad:
            return False, 'Unknown account code: ' + ', '.join(bad), bad
        return True, '', []

    # ---- data
    def periods(self):
        return self.store.periods()

    def req_period(self, req):
        """The request's quarter, or the latest; a clear error for a quarter that is not loaded."""
        p = req.get('period') or self.store.latest()
        if not self.store.exists(p):
            raise ValueError(f'{p} is not available yet. Latest quarter: {self.store.latest()}.')
        return p

    def valid(self, period):
        v = self._valid.get(period)
        if v is None:
            a = self.store.col(period, self.asset_code)
            v = np.nan_to_num(a) > 0
            if self.kind == 'bank':                  # peers must report earnings (drops foreign branches)
                v &= ~np.isnan(self.store.col(period, 'NETINC'))
            self._valid[period] = v
        return v

    @staticmethod
    def _before(m, period):
        return bool(m.get('floor')) and period < m['floor']

    def values(self, key, period):
        m = self.mdef(key)
        if self._before(m, period):               # the underlying accounts do not exist yet
            return np.full(len(self.store.ids(period)), np.nan)
        ck = (m['f'], period)
        v = self._v.get(ck)
        if v is None:
            v = np.asarray(self.formula(m['f']).eval(F.VectorCtx(self.store, period)), dtype=float)
            if v.ndim == 0:
                v = np.full(len(self.store.ids(period)), float(v))
            v = np.where(np.isinf(v), np.nan, v)
            # ponytail: before `since`, nz() turns missing accounts into 0 for everyone; an all-zero column means
            # "not on the form yet", so make it NaN (screens must not pass it). Use floor= to cut a partial era too.
            if m.get('since') and period < m['since'] and not np.any(np.nan_to_num(v)):
                v = np.full(len(v), np.nan)
            if len(self._v) > 4000:
                self._v.clear()
            self._v[ck] = v
        return v

    def universe(self, period):
        u = self._u.get(period)
        if u is None:
            u = self.store.info(period).copy()
            u['assets'] = self.store.col(period, self.asset_code)
            if self.kind == 'cu':
                u['members'] = self.store.col(period, '083')
            self._u[period] = u
        return u

    def pos(self, period, inst_id):
        d = self._posmap.get(period)
        if d is None:
            d = {i: n for n, i in enumerate(self.store.ids(period))}
            self._posmap[period] = d
        return d.get(str(inst_id))

    def display_name(self, inst_id, period=None):
        for p in ([period] if period else []) + self.periods()[::-1]:
            i = self.pos(p, inst_id)
            if i is not None:
                return self.eng.display_name(self.universe(p).iloc[i])
        return str(inst_id)

    def search(self, q, limit=15, period=None):
        period = period or self.store.latest()
        u = self.universe(period)
        q = q.strip().lower()
        if not q:
            return []
        name = u['CU_NAME'].str.lower()
        hit = name.str.contains(q, regex=False) | (u.index == q)
        hit &= self.valid(period)
        r = u[hit].sort_values('assets', ascending=False).head(limit)
        return [{'id': i, 'name': x.CU_NAME, 'city': x.CITY, 'state': x.STATE, 'assets': _num(x.assets)} for i, x in r.iterrows()]

    # ---- subject (an institution or a hypothetical merger)
    def subject(self, s, period):
        """-> dict(ids, name, state, assets, merged)"""
        if not s:
            return None
        ids = [str(i) for i in (s.get('merge') or [s.get('id')]) if i not in (None, '')]
        if not ids:
            return None
        u = self.universe(period)
        rows = u[u.index.isin(ids)]
        if rows.empty:                               # not filing this quarter: fall back to its latest filing
            for p in self.periods()[::-1]:
                rows = self.universe(p)[self.universe(p).index.isin(ids)]
                if not rows.empty:
                    break
        if rows.empty:
            raise ValueError('Institution not found.')
        big = rows.sort_values('assets', ascending=False).iloc[0]
        merged = len(ids) > 1
        name = s.get('name') or (' + '.join(self.eng.display_name(r) for _, r in rows.sort_values('assets', ascending=False).iterrows())
                                 if merged else self.eng.display_name(big))
        return dict(ids=ids, name=name, state=big['STATE'], city=big['CITY'], assets=float(rows['assets'].sum()),
                    merged=merged, group=big.get('Peer_Group', ''), kind=self.kind)

    def subject_value(self, subj, key, period):
        if subj is None or period not in self.periods():
            return np.nan
        if self._before(self.mdef(key), period):
            return np.nan
        if subj['merged']:
            v = self.formula(self.mdef(key)['f']).eval(F.MergedCtx(self.store, period, subj['ids']))
            return float(v) if np.ndim(v) == 0 else np.nan
        i = self.pos(period, subj['ids'][0])
        return float(self.values(key, period)[i]) if i is not None else np.nan

    # ---- peer groups
    def tier(self, assets):
        return next(((lo, hi, lab) for lo, hi, lab in self.eng.TIERS if lo <= assets < hi), None)

    def resolve_spec(self, spec, subj, period):
        """Turn a preset (relative to the subject) into a concrete spec. Returns (spec, name, note).
        Performance conditions sent with a preset are kept on top of the preset's group."""
        out, name, note = self._resolve_preset(spec, subj, period)
        extra = (spec or {}).get('filters') if (spec or {}).get('preset') else None
        if extra:
            out = dict(out, filters=list(out.get('filters') or []) + list(extra))
        return out, name, note

    def _resolve_preset(self, spec, subj, period):
        spec = dict(spec or {})
        preset = spec.pop('preset', None)
        note = None
        inst = 'credit unions' if self.kind == 'cu' else 'banks'
        if not preset:
            return spec, spec.get('name') or self.describe(spec), note
        if preset == 'national':
            return {}, f'All U.S. {inst}', note
        if subj is None:
            raise ValueError('Pick an institution first: this peer group is defined relative to it.')
        t = self.tier(subj['assets'])
        tier_spec = {'assets': [t[0], None if t[1] == float('inf') else t[1]]} if t else {}
        if preset == 'tier':
            return tier_spec, f'{t[2]} {inst}, nationwide', note
        if preset == 'state':
            return {'states': [subj['state']]}, f'{subj["state"]} {inst}', note
        if preset == 'group':
            lab = (f'NCUA peer group {subj["group"]} ({peer_engine.NCUA_PEER_GROUPS.get(subj["group"], "?")})' if self.kind == 'cu'
                   else f'FDIC {bank_engine.SPECGRP.get(str(subj["group"]), "?").lower()} specialization')
            return {'groups': [subj['group']]}, lab, note
        if preset == 'nearest':
            n = int(spec.get('n') or 20)
            return {'rank': {'metric': 'assets', 'mode': 'closest', 'n': n}}, f'{n} {inst} closest in asset size, nationwide', note
        if preset == 'nearest_state':
            n = int(spec.get('n') or 10)
            return ({'states': [subj['state']], 'rank': {'metric': 'assets', 'mode': 'closest', 'n': n}},
                    f'{n} {subj["state"]} {inst} closest in asset size', note)
        if preset in ('default', 'state_tier'):
            from peer_report import MIN_DEFAULT_PEERS, STATE_NAMES, default_peer_steps
            steps = default_peer_steps(subj['state']) if preset == 'default' else [([subj['state']], subj['state'])]
            for i, (states, label) in enumerate(steps):
                s = dict(tier_spec, **({'states': states} if states else {}))
                n = int(self.peer_mask(s, period, subj).sum())
                if n >= MIN_DEFAULT_PEERS or i == len(steps) - 1:
                    break
            if i:
                home = STATE_NAMES.get(subj['state'], subj['state'])
                note = (f'{home} has fewer than {MIN_DEFAULT_PEERS} other {inst} in this asset tier, '
                        f'so the peer group was widened to {label}.')
            where = (label[4:] if label.startswith('the ') else label) if i else subj['state']
            return s, f'{where}, {t[2]} {inst}', note
        raise ValueError(f'Unknown peer preset: {preset}')

    def describe(self, spec):
        inst = 'credit unions' if self.kind == 'cu' else 'banks'
        parts = []
        if spec.get('only'):
            return f'Custom list of {len(spec["only"])} {inst}'
        if spec.get('states'):
            st = spec['states']
            parts.append('/'.join(st) if len(st) <= 6 else f'{len(st)} states')
        a = spec.get('assets')
        if a and (a[0] or a[1]):
            lo, hi = a[0] or 0, a[1]
            parts.append(f'{peer_engine._money(lo)}-{peer_engine._money(hi)} assets' if hi else f'> {peer_engine._money(lo)} assets')
        mb = spec.get('members')
        if mb and (mb[0] or mb[1]):
            cnt = lambda v: f'{v / 1e6:.1f}M' if v >= 1e6 else f'{v / 1e3:.0f}K' if v >= 1e3 else f'{v:.0f}'
            parts.append(f'{cnt(mb[0] or 0)}-{cnt(mb[1])} members' if mb[1] else f'> {cnt(mb[0])} members')
        if spec.get('charter'):
            names = wide_store.CU_TYPES if self.kind == 'cu' else wide_store.BKCLASS
            parts.append(' or '.join(str(names.get(str(c), c)).split(' (')[0] for c in spec['charter']))
        if spec.get('fom'):
            parts.append('/'.join(spec['fom']).lower())
        if spec.get('low_income') is not None:
            parts.append('low-income designated' if spec['low_income'] else 'not low-income designated')
        if spec.get('mdi'):
            parts.append('MDI')
        if spec.get('cb') is not None:
            parts.append('community banks' if spec['cb'] else 'non-community banks')
        if spec.get('subs'):
            parts.append('Subchapter S')
        if spec.get('groups'):
            parts.append(('NCUA peer group ' if self.kind == 'cu' else 'FDIC specialization ') + '/'.join(map(str, spec['groups'])))
        def mlab(key):
            return (self.base.get(key) or self.custom().get(key) or {}).get('label', key or '')
        for flt in spec.get('filters') or []:
            m = self.base.get(flt.get('metric')) or self.custom().get(flt.get('metric')) or {}
            pct = m.get('fmt') in ('pct', 'rate')
            usd = m.get('fmt') == 'usd'
            def show(v):
                v = float(v)
                if pct:
                    return f'{v * 100:.2f}%'
                if usd:
                    a = abs(v)
                    return ('-' if v < 0 else '') + (f'${a / 1e9:,.2f}B' if a >= 1e9 else f'${a / 1e6:,.1f}M' if a >= 1e6 else f'${a:,.0f}')
                return f'{v:,.4g}' if abs(v) < 1e6 else f'{v:,.0f}'
            lo, hi = (flt.get(k) if flt.get(k) not in (None, '') else None for k in ('min', 'max'))
            cond = (f'{show(lo)} to {show(hi)}' if lo is not None and hi is not None else
                    f'≤ {show(hi)}' if hi is not None else f'≥ {show(lo)}' if lo is not None else '')
            text = f'{mlab(flt.get("metric"))} {cond}'.strip()
            if cond and text not in parts:
                parts.append(text)
        r = spec.get('rank')
        if r:
            parts.append(f'{r.get("mode", "top")} {r.get("n")}{"%" if r.get("pct") else ""} by {mlab(r.get("metric"))}')
        return f'{inst[0].upper() + inst[1:]}: ' + ', '.join(parts) if parts else f'All U.S. {inst}'

    def peer_mask(self, spec, period, subj=None):
        """Boolean mask over store.ids(period). The subject is never its own peer."""
        spec = spec or {}
        u = self.universe(period)
        ids = u.index
        m = self.valid(period).copy()
        if spec.get('only'):
            m &= ids.isin([str(x).strip() for x in spec['only']])
        else:
            if spec.get('states'):
                m &= u['STATE'].isin([s.upper() for s in spec['states']]).to_numpy()
            if spec.get('regions'):
                m &= u['REGION'].isin([str(r) for r in spec['regions']]).to_numpy()
            a = spec.get('assets')
            if a:
                if a[0]:
                    m &= u['assets'].to_numpy() >= float(a[0])
                if a[1]:
                    m &= u['assets'].to_numpy() < float(a[1])
            mem = spec.get('members')
            if mem and self.kind == 'cu':
                if mem[0]:
                    m &= u['members'].to_numpy() >= float(mem[0])
                if mem[1]:
                    m &= u['members'].to_numpy() < float(mem[1])
            if spec.get('charter'):
                m &= u['CU_TYPE' if self.kind == 'cu' else 'BKCLASS'].isin([str(c) for c in spec['charter']]).to_numpy()
            if spec.get('groups'):
                m &= u['Peer_Group'].isin([str(g) for g in spec['groups']]).to_numpy()
            if self.kind == 'cu':
                if spec.get('fom'):
                    codes = {c for g in spec['fom'] for c in wide_store.TOM_GROUPS.get(g, [g])}
                    m &= u['TOM_CODE'].str.zfill(2).isin(codes).to_numpy()
                if spec.get('low_income') is not None:
                    m &= (u['LIMITED_INC'] == '1').to_numpy() == bool(spec['low_income'])
                if spec.get('mdi') is not None:
                    m &= (u['IsMDI'].str.lower() == 'true').to_numpy() == bool(spec['mdi'])
            else:
                if spec.get('cb') is not None:
                    m &= (u['CB'] == '1').to_numpy() == bool(spec['cb'])
                if spec.get('subs') is not None:
                    m &= (u['SUBCHAPS'] == '1').to_numpy() == bool(spec['subs'])
                if spec.get('mutual') is not None:
                    m &= (u['MUTUAL'] == '1').to_numpy() == bool(spec['mutual'])
                if spec.get('cbsa'):
                    m &= u['CBSA'].str.contains(spec['cbsa'], case=False, regex=False).to_numpy()
            if spec.get('city'):
                m &= (u['CITY'].str.lower() == spec['city'].strip().lower()).to_numpy()
            for flt in spec.get('filters') or []:
                key = flt.get('metric')
                if not key:
                    continue
                v = self.values(key, period)
                if flt.get('min') not in (None, ''):
                    m &= v >= float(flt['min'])
                if flt.get('max') not in (None, ''):
                    m &= v <= float(flt['max'])
        def screen(m):                                   # screen conditions applied on top of any group
            for flt in spec.get('post_filters') or []:
                if not flt.get('metric'):
                    continue
                v = self.values(flt['metric'], period)
                if flt.get('min') not in (None, ''):
                    m &= v >= float(flt['min'])
                if flt.get('max') not in (None, ''):
                    m &= v <= float(flt['max'])
            return m
        m = screen(m)
        sub_ids = set(subj['ids']) if subj else set()
        if sub_ids:
            m &= ~ids.isin(sub_ids)
        r = spec.get('rank')
        if r and r.get('n') and m.any():
            v = self.values(r.get('metric') or 'assets', period)
            n = float(r['n'])
            cand = np.flatnonzero(m & ~np.isnan(v))
            k = int(round(len(cand) * n / 100)) if r.get('pct') else int(n)
            k = max(min(k, len(cand)), 0)
            mode = r.get('mode', 'top')
            if mode == 'closest':
                if subj is None:
                    raise ValueError('"Closest to" needs an institution selected.')
                target = self.subject_value(subj, r.get('metric') or 'assets', period)
                order = cand[np.argsort(np.abs(v[cand] - target), kind='stable')]
            else:
                hib = self.mdef(r.get('metric') or 'assets').get('hib')
                best_high = (hib is not False)
                asc = (mode == 'top') != best_high
                order = cand[np.argsort(v[cand] if asc else -v[cand], kind='stable')]
            m = np.zeros(len(ids), dtype=bool)
            m[order[:k]] = True
        if spec.get('include'):
            m |= ids.isin([str(x).strip() for x in spec['include']]) & self.valid(period) & ~ids.isin(sub_ids)
        if spec.get('exclude'):
            m &= ~ids.isin([str(x).strip() for x in spec['exclude']])
        return np.asarray(screen(m), dtype=bool)          # screens also bind "always include" members

    def mask_of_ids(self, period, member_ids):
        self.pos(period, '')
        d = self._posmap[period]
        m = np.zeros(len(d), dtype=bool)
        hit = [d[i] for i in member_ids if i in d]
        m[hit] = True
        return m & self.valid(period)

    def roster(self, period, mask, limit=None):
        u = self.universe(period)[mask].sort_values('assets', ascending=False)
        if limit:
            u = u.head(limit)
        return [{'id': i, 'name': r.CU_NAME, 'city': r.CITY, 'state': r.STATE, 'assets': _num(r.assets)} for i, r in u.iterrows()]

    # ---- peer statistics
    def peer_value(self, key, period, mask, mode):
        m = self.mdef(key)
        if not mask.any() or self._before(m, period):
            return np.nan
        if mode == 'agg' and not m.get('mean'):
            f = self.formula(m['f'])
            ctx = F.AggCtx(self.store, period, mask, f.periods_used(period))
            if ctx.n == 0:
                return np.nan
            v = f.eval(ctx)
            v = float(v) if np.ndim(v) == 0 else np.nan
            return v / ctx.n if m.get('level') else v
        v = self.values(key, period)[mask]
        v = v[~np.isnan(v)]
        if not len(v):
            return np.nan
        if mode in ('agg', 'mean'):
            return float(v.mean())
        if mode == 'median':
            return float(np.median(v))
        if mode == 'tmean':
            return bank_engine.trimmed_mean(v)
        up = m.get('hib') is not False               # "top" = high values unless lower is better
        q = {'top10': 0.9, 'top25': 0.75, 'bot25': 0.25, 'bot10': 0.1}[mode]
        return float(np.quantile(v, q if up else 1 - q))

    def standing(self, key, period, mask, value):
        """Rank / percentile of `value` inside mask + itself (direction-aware; 100 = best)."""
        m = self.mdef(key)
        v = self.values(key, period)[mask]
        v = v[~np.isnan(v)]
        out = {'of': int(len(v)) + (0 if value is None or np.isnan(value) else 1), 'rank': None, 'pct': None, 'stars': None,
               'dist': None}
        if len(v):
            q = np.quantile(v, [0.1, 0.25, 0.5, 0.75, 0.9])
            out['dist'] = {'min': _num(v.min()), 'p10': _num(q[0]), 'p25': _num(q[1]), 'p50': _num(q[2]),
                           'p75': _num(q[3]), 'p90': _num(q[4]), 'max': _num(v.max())}
        hib = m.get('hib')
        if value is None or np.isnan(value):
            return out
        if not len(v):
            if hib is not None:
                out['rank'] = 1
            return out
        high = hib is not False
        better = int((v > value).sum() if high else (v < value).sum())
        worse = int((v < value).sum() if high else (v > value).sum())
        out['rank'] = better + 1
        out['pct'] = 100.0 * worse / max(len(v), 1)
        out['neutral'] = hib is None
        out['stars'] = None if hib is None else stars(out['pct'])
        return out

    # ---- period lists
    def period_list(self, period, years=5, freq='q'):
        ps = [p for p in self.periods() if p <= period]
        lo = F.shift(period, int(years) * 12)
        ps = [p for p in ps if p >= lo]
        if freq == 'a':
            ps = [p for p in ps if p[5:] == period[5:]]
        elif freq == 's':
            keep = {F.shift(period, 6 * i) for i in range(0, 60)}
            ps = [p for p in ps if p in keep]
        return ps


def get(kind):
    return Analyzer.get(kind)


# --------------------------------------------------------------------------- group handling (may cross industries)

def _cross_key(kind_from, key, kind_to):
    if kind_from == kind_to:
        return key
    i, j = (1, 2) if kind_from == 'cu' else (2, 1)
    for row in library.CROSS:
        if row[i] == key:
            return row[j]
    return None


def _build_groups(an, subj, specs, period, membership='fixed'):
    """Resolve each comparison group once at the base period. A group may be another institution
    ({'inst': id}), or a peer group of either industry ({'kind': 'bank', ...})."""
    groups = []
    for spec in specs or []:
        spec = dict(spec)
        gk = spec.pop('kind', an.kind)
        ga = get(gk)
        if spec.get('inst') or spec.get('merge'):
            s = ga.subject({'id': spec.get('inst'), 'merge': spec.get('merge'), 'name': spec.get('name')}, period)
            groups.append(dict(type='inst', an=ga, subj=s, name=s['name'], n=1, note=None, kind=gk))
            continue
        gsub = subj if gk == an.kind else None
        if gk != an.kind and spec.get('preset') and subj:
            # relative presets against the other industry use the subject's size and state
            gsub = dict(subj, ids=[], group='')
        concrete, name, note = ga.resolve_spec(spec, gsub, period)
        mask = ga.peer_mask(concrete, period, gsub)
        ids = ga.store.ids(period)[mask]
        groups.append(dict(type='group', an=ga, spec=concrete, name=spec.get('name') or name, note=note, kind=gk,
                           ids=ids, n=int(mask.sum()), mask0=mask, membership=membership, subj=gsub))
    return groups


def _group_mask(g, period, base_period):
    if period == base_period:
        return g['mask0']
    cache = g.setdefault('masks', {})
    m = cache.get(period)
    if m is None:
        m = (g['an'].peer_mask(g['spec'], period, g.get('subj')) if g.get('membership') == 'historical'
             else g['an'].mask_of_ids(period, g['ids']))
        cache[period] = m
    return m


def _group_value(g, an_kind, key, period, base_period, mode):
    k = _cross_key(an_kind, key, g['kind']) if not key.startswith('=') else (key if g['kind'] == an_kind else None)
    if k is None:
        return np.nan
    try:
        if g['type'] == 'inst':
            return g['an'].subject_value(g['subj'], k, period)
        if period not in g['an'].periods():
            return np.nan
        return g['an'].peer_value(k, period, _group_mask(g, period, base_period), mode)
    except F.FormulaError:
        return np.nan


# --------------------------------------------------------------------------- API: analyze

def analyze(req):
    """Trend + standing for a list of metrics: the primary vs each comparison group."""
    an = get(req.get('type'))
    period = an.req_period(req)
    mode = req.get('mode') or DEFAULT_MODE[an.kind]
    subj = an.subject(req.get('subject'), period)
    groups = _build_groups(an, subj, req.get('groups') or [{'preset': 'default' if subj else 'national'}], period,
                           req.get('membership', 'fixed'))
    periods = an.period_list(period, req.get('years', 5), req.get('freq', 'q'))
    primary = next((g for g in groups if g['type'] == 'group' and g['kind'] == an.kind), None)
    out_metrics = []
    for key in req.get('metrics') or []:
        try:
            m = an.mdef(key)
            row = dict(key=key, label=m['label'], fmt=m['fmt'], hib=m.get('hib'), folder=m.get('folder'),
                       formula=m['f'], desc=m.get('desc', ''), since=m.get('since'),
                       subject=[_num(an.subject_value(subj, key, p)) for p in periods] if subj else None,
                       groups=[[_num(_group_value(g, an.kind, key, p, period, mode)) for p in periods] for g in groups])
            if primary is not None:
                val = an.subject_value(subj, key, period) if subj else np.nan
                st = an.standing(key, period, primary['mask0'], val)
                st['value'] = _num(val)
                st['peer'] = _num(_group_value(primary, an.kind, key, period, period, mode))
                st['median'] = st['dist']['p50'] if st['dist'] else None
                if subj and len(periods) > 1:
                    py = F.shift(period, 12)
                    st['value_py'] = _num(an.subject_value(subj, key, py))
                    st['peer_py'] = _num(_group_value(primary, an.kind, key, py, period, mode))
                row['latest'] = st
            out_metrics.append(row)
        except (F.FormulaError, KeyError, ValueError) as e:
            out_metrics.append(dict(key=key, label=key, error=str(e)))
    return dict(
        type=an.kind, period=period, periods=periods, mode=mode, mode_label=MODES.get(mode, mode),
        subject=({k: subj[k] for k in ('ids', 'name', 'state', 'city', 'assets', 'merged')} if subj else None),
        groups=[dict(name=g['name'], n=g['n'], note=g['note'], kind=g['kind'], type=g['type'],
                     roster=(g['an'].roster(period, g['mask0'], 400) if g['type'] == 'group' else None)) for g in groups],
        metrics=out_metrics)


# --------------------------------------------------------------------------- API: tables (leader table, screener, comparison)

def table(req):
    """Institutions x metrics for one quarter: leader tables, screens and side-by-side comparisons."""
    an = get(req.get('type'))
    period = an.req_period(req)
    mode = req.get('mode') or DEFAULT_MODE[an.kind]
    subj = an.subject(req.get('subject'), period)
    spec, name, note = an.resolve_spec(req.get('spec') or {'preset': 'national'}, subj, period)
    if req.get('extra_filters'):
        spec = dict(spec, post_filters=req['extra_filters'])
    mask = an.peer_mask(spec, period, subj)
    cols = [k for k in (req.get('columns') or ['assets'])]
    defs = [an.mdef(k) for k in cols]
    sort = req.get('sort') or cols[0]
    if sort not in cols:
        cols.append(sort); defs.append(an.mdef(sort))
    ids = an.store.ids(period)
    full = mask.copy()
    sub_pos = [an.pos(period, i) for i in (subj['ids'] if subj and not subj['merged'] else [])]
    for i in sub_pos:
        if i is not None and req.get('include_subject', True):
            full[i] = True
    u = an.universe(period)
    data = {k: an.values(k, period) for k in cols}
    sv = data[sort]
    idx = np.flatnonzero(full & ~np.isnan(sv))
    hib = an.mdef(sort).get('hib')
    desc = req.get('desc')
    if desc is None:
        desc = hib is not False
    idx = idx[np.argsort(-sv[idx] if desc else sv[idx], kind='stable')]
    total = len(idx)
    rank_of = {int(i): r + 1 for r, i in enumerate(idx)}
    limit, offset = int(req.get('limit') or 50), int(req.get('offset') or 0)
    show = list(idx[offset:offset + limit])
    for i in sub_pos:                                   # always show the subject's own row
        if i is not None and i in rank_of and i not in show:
            show.append(i)
    rows = []
    for i in show:
        r = u.iloc[i]
        rows.append(dict(id=ids[i], name=r.CU_NAME, city=r.CITY, state=r.STATE, rank=rank_of[int(i)],
                         subject=bool(subj and ids[i] in subj['ids']), vals=[_num(data[k][i]) for k in cols]))
    stats = {'peer': [_num(an.peer_value(k, period, mask, mode)) for k in cols],
             'median': [_num(an.peer_value(k, period, mask, 'median')) for k in cols],
             'top25': [_num(an.peer_value(k, period, mask, 'top25')) for k in cols],
             'bot25': [_num(an.peer_value(k, period, mask, 'bot25')) for k in cols]}
    return dict(type=an.kind, period=period, name=name, note=note, n=int(mask.sum()), total=total, mode_label=MODES.get(mode, mode),
                columns=[dict(key=k, label=d['label'], fmt=d['fmt'], hib=d.get('hib')) for k, d in zip(cols, defs)],
                sort=sort, desc=bool(desc), rows=rows, stats=stats,
                subject=({'name': subj['name'], 'ids': subj['ids']} if subj else None))


def scatter(req):
    """Two (or three) metrics for every member of a group: the correlation chart."""
    an = get(req.get('type'))
    period = an.req_period(req)
    subj = an.subject(req.get('subject'), period)
    spec, name, note = an.resolve_spec(req.get('spec') or {'preset': 'national'}, subj, period)
    if req.get('extra_filters'):
        spec = dict(spec, post_filters=req['extra_filters'])
    mask = an.peer_mask(spec, period, subj)
    keys = [req['x'], req['y']] + ([req['size']] if req.get('size') else [])
    defs = [an.mdef(k) for k in keys]
    vals = [an.values(k, period) for k in keys]
    ok = mask & ~np.isnan(vals[0]) & ~np.isnan(vals[1])
    idx = np.flatnonzero(ok)
    if len(idx) > 2500:                                 # keep the chart light: largest institutions first
        a = an.universe(period)['assets'].to_numpy()
        idx = idx[np.argsort(-a[idx])][:2500]
    u = an.universe(period)
    pts = [dict(id=an.store.ids(period)[i], name=u['CU_NAME'].iat[i], state=u['STATE'].iat[i],
                v=[_num(v[i]) for v in vals]) for i in idx]
    sp = None
    if subj:
        sp = dict(name=subj['name'], v=[_num(an.subject_value(subj, k, period)) for k in keys])
    x, y = vals[0][idx], vals[1][idx]
    def fence(a):
        q1, q3 = np.nanpercentile(a, [25, 75])
        return (a >= q1 - 3 * (q3 - q1)) & (a <= q3 + 3 * (q3 - q1))
    keep = fence(x) & fence(y) if len(idx) > 2 else np.zeros(len(idx), bool)
    corr = _num(np.corrcoef(x[keep], y[keep])[0, 1]) if keep.sum() > 2 else None
    return dict(name=name, n=int(mask.sum()), period=period, corr=corr, points=pts, subject=sp,
                axes=[dict(key=k, label=d['label'], fmt=d['fmt']) for k, d in zip(keys, defs)])


# --------------------------------------------------------------------------- API: financial statements

_CU_BS = [
    ('Assets', None, 'h'),
    ('Cash and deposits', 'alt([AS0009], nz([730A]) + nz([730B]) + nz([730C]))', 0),
    ('Investments', 'alt([NV0158], [799I])', 0),
    ('Loans held for sale', '[003]', 0),
    ('Total loans and leases', '[025B]', 0),
    ('New vehicle', '[385]', 1), ('Used vehicle', '[370]', 1), ('Unsecured credit card', '[396]', 1),
    ('Other unsecured', '[397]', 1), ('1st-lien residential real estate', 'alt([703A], [703])', 1),
    ('Junior-lien residential real estate', 'alt([386A], [386])', 1), ('Other real estate', '[386B]', 1),
    ('Commercial', 'alt([400T1], [400T])', 1), ('Other secured, non-real-estate', '[698C]', 1),
    ('Less: allowance for loan / credit losses', f'0 - {library.ALLOW}', 0),
    ('Foreclosed and repossessed assets', '[798A]', 0),
    ('Land, building and other fixed assets', 'nz([007]) + nz([008])', 0),
    ('NCUSIF capitalization deposit', '[794]', 0),
    ('Other assets', '[AS0036]', 0),
    ('Total assets', '[010]', 't'),
    ('Liabilities, shares and equity', None, 'h'),
    ('Total shares and deposits', '[018]', 0),
    ('Share drafts', '[902]', 1), ('Regular shares', '[657]', 1), ('Money market shares', '[911]', 1),
    ('Share certificates', '[908C]', 1), ('IRA / Keogh', '[906C]', 1), ('All other shares', '[630]', 1),
    ('Non-member deposits', '[880]', 1),
    ('Borrowings', '[860C]', 0),
    ('Accrued dividends and interest payable', '[820A]', 0),
    ('Accounts payable and other liabilities', '[825]', 0),
    ('Undivided earnings', '[940]', 0),
    ('Other reserves', '[658]', 0),
    ('Unrealized gain (loss) on AFS securities', '[EQ0009]', 0),
    ('Total net worth', '[997]', 't'),
    ('Total liabilities, shares and equity', '[014]', 't'),
]
_CU_IS = [
    ('Interest income', None, 'h'),
    ('Interest on loans', '[110]', 0), ('Less: interest refunded', '0 - nz([119])', 0),
    ('Income from investments', '[120]', 0), ('Other interest income', '[IS0005]', 0),
    ('Total interest income', '[115]', 't'),
    ('Interest expense', None, 'h'),
    ('Dividends on shares', '[380]', 0), ('Interest on deposits', '[381]', 0), ('Interest on borrowed money', '[340]', 0),
    ('Total interest expense', '[350]', 't'),
    ('Net interest income', '[115] - [350]', 't'),
    ('Provision / credit loss expense', library.PROV, 0),
    ('Non-interest income', None, 'h'),
    ('Fee income', '[131]', 0), ('Other operating income', library.OOI, 0), ('Gain (loss) on sales of loans', '[IS0029]', 0),
    ('Gain (loss) on investments', 'nz([420]) + nz([IS0046]) + nz([IS0047])', 0),
    ('Gain (loss) on disposition of fixed assets', '[430]', 0), ('Other non-operating income (expense)', '[440]', 0),
    ('Total non-interest income', '[117]', 't'),
    ('Non-interest expense', None, 'h'),
    ('Employee compensation and benefits', '[210]', 0), ('Travel and conference', '[230]', 0),
    ('Office occupancy', '[250]', 0), ('Office operations', '[260]', 0), ('Educational and promotional', '[270]', 0),
    ('Loan servicing', '[280]', 0), ('Professional and outside services', '[290]', 0), ('Member insurance', '[310]', 0),
    ('Operating fees', '[320]', 0), ('Miscellaneous operating', '[360]', 0),
    ('Total non-interest expense', '[671]', 't'),
    ('Net income', '[661A]', 't'),
]
_BANK_BS = [
    ('Assets', None, 'h'),
    ('Cash and due from depository institutions', '[CHBAL]', 0), ('Securities', '[SC]', 0),
    ('Federal funds sold and reverse repos', '[FREPO]', 0),
    ('Total loans and leases', '[LNLSGR]', 0),
    ('1-4 family residential', '[LNRERES]', 1), ('Construction and land development', '[LNRECONS]', 1),
    ('Nonfarm nonresidential', '[LNRENRES]', 1), ('Multifamily', '[LNREMULT]', 1), ('Farmland', '[LNREAG]', 1),
    ('Commercial and industrial', '[LNCI]', 1), ('Consumer', '[LNCON]', 1), ('Agricultural production', '[LNAG]', 1),
    ('Less: allowance for credit losses', '0 - [LNATRES]', 0),
    ('Trading assets', '[TRADE]', 0), ('Premises and fixed assets', '[BKPREM]', 0), ('Other real estate owned', '[ORE]', 0),
    ('Goodwill and other intangibles', '[INTAN]', 0), ('Other assets', '[OA]', 0),
    ('Total assets', '[ASSET]', 't'),
    ('Liabilities and equity', None, 'h'),
    ('Total deposits', '[DEP]', 0),
    ('Noninterest-bearing', '[DEPNI]', 1), ('Interest-bearing', '[DEPI]', 1),
    ('Memo: money market', '[NTRSMMDA]', 1), ('Memo: other savings', '[NTRSOTH]', 1), ('Memo: time deposits', '[NTRTIME]', 1),
    ('Memo: brokered', '[BRO]', 1),
    ('Federal funds purchased and repos', '[FREPP]', 0), ('Other borrowed money', '[OTHBOR]', 0),
    ('Subordinated debt', '[SUBND]', 0), ('All other liabilities', '[ALLOTHL]', 0),
    ('Total liabilities', '[LIAB]', 't'),
    ('Total equity capital', '[EQTOT]', 't'),
    ('Total liabilities and equity', '[LIABEQ]', 't'),
]
_BANK_IS = [
    ('Interest income', None, 'h'),
    ('Loans and leases', '[ILNLS]', 0), ('Securities', '[ISC]', 0), ('Federal funds sold and repos', '[IFREPO]', 0),
    ('Balances due from banks', '[ICHBAL]', 0), ('Other interest income', '[IOTHII]', 0),
    ('Total interest income', '[INTINC]', 't'),
    ('Interest expense', None, 'h'),
    ('Deposits', '[EDEP]', 0), ('Federal funds purchased and repos', '[EFREPP]', 0),
    ('Other borrowed money and subordinated debt', '[EINTEXP] - nz([EDEP]) - nz([EFREPP])', 0),
    ('Total interest expense', '[EINTEXP]', 't'),
    ('Net interest income', '[NIM]', 't'),
    ('Provision for credit losses', '[ELNATR]', 0),
    ('Non-interest income', None, 'h'),
    ('Fiduciary activities', '[IFIDUC]', 0), ('Service charges on deposit accounts', '[ISERCHG]', 0),
    ('Net gains on loan sales', '[NETGNSLN]', 0), ('Servicing fees', '[ISERFEE]', 0),
    ('Insurance commissions and fees', '[IINSCOM]', 0), ('Other non-interest income', '[IOTNII]', 0),
    ('Total non-interest income', '[NONII]', 't'),
    ('Securities gains (losses)', '[IGLSEC]', 0),
    ('Non-interest expense', None, 'h'),
    ('Salaries and employee benefits', '[ESAL]', 0), ('Premises and equipment', '[EPREMAGG]', 0),
    ('All other non-interest expense', '[EOTHNINT]', 0),
    ('Total non-interest expense', '[NONIX]', 't'),
    ('Income before taxes', '[IBEFTAX]', 't'), ('Applicable income taxes', '[ITAX]', 0),
    ('Net income', '[NETINC]', 't'),
]
STATEMENTS = {'cu': {'bs': _CU_BS, 'is': _CU_IS, 'base': {'bs': '[010]', 'is': '[115] + [117]'}},
              'bank': {'bs': _BANK_BS, 'is': _BANK_IS, 'base': {'bs': '[ASSET]', 'is': '[INTINC] + [NONII]'}}}


def statements(req):
    """Balance sheet + income statement over time for an institution, a merger, or a peer group average,
    with common-size percentages (of assets / of total income)."""
    an = get(req.get('type'))
    period = an.req_period(req)
    years, freq = req.get('years', 3), req.get('freq', 'a')
    periods = an.period_list(period, years, freq)[-(int(years) * 4 if freq == 'q' else 12):]
    subj = an.subject(req.get('subject'), period)
    cmp_ctx = None
    cmp_name = None
    if req.get('spec') is not None:
        spec, cmp_name, _ = an.resolve_spec(req['spec'], subj, period)
        cmask = an.peer_mask(spec, period, subj)
        cids = an.store.ids(period)[cmask]

    def ctx_for(p, peer=False):
        if peer:
            return F.AggCtx(an.store, p, an.mask_of_ids(p, cids), {p})
        if subj['merged']:
            return F.MergedCtx(an.store, p, subj['ids'])
        return F.MergedCtx(an.store, p, subj['ids'])

    def evalf(text, ctx):
        v = an.formula(text).eval(ctx)
        return float(v) if np.ndim(v) == 0 else np.nan

    out = {}
    for part in ('bs', 'is'):
        base_f = STATEMENTS[an.kind]['base'][part]
        rows = []
        for label, f, style in STATEMENTS[an.kind][part]:
            if f is None:
                rows.append(dict(label=label, style='h'))
                continue
            vals = [_num(evalf(f, ctx_for(p))) for p in periods] if subj else None
            row = dict(label=label, style=style, formula=f, vals=vals)
            if subj:
                b = evalf(base_f, ctx_for(period))
                row['pct'] = _num(vals[-1] / b) if vals[-1] is not None and b else None
            if req.get('spec') is not None:
                c = ctx_for(period, peer=True)
                b = evalf(base_f, c)
                v = evalf(f, c)
                row['peer_pct'] = _num(v / b) if b else None
                row['peer_avg'] = _num(v / c.n) if c.n else None
            rows.append(row)
        out[part] = rows
    return dict(type=an.kind, periods=periods, period=period, subject=subj and subj['name'], compare=cmp_name,
                bs=out['bs'], **{'is': out['is']})


def callreport(req):
    """Every account the institution reported: the full call report viewer."""
    an = get(req.get('type'))
    period = an.req_period(req)
    subj = an.subject(req.get('subject'), period)
    if subj is None:
        raise ValueError('Pick an institution.')
    names = an.store.codes()
    py = F.shift(period, 12)
    cur, prev = F.MergedCtx(an.store, period, subj['ids']), F.MergedCtx(an.store, py, subj['ids'])
    q = (req.get('q') or '').strip().lower()
    rows = []
    codes = sorted(names) if an.kind == 'bank' else sorted(set(names) | set(an.store._meta(period)['col_of']))
    for code in codes:
        if not an.store.has(period, code):
            continue
        v = cur.get(code, period)
        if v is None or np.isnan(v) or (v == 0 and not q):
            continue
        nm = names.get(code, [code, ''])
        if q and q not in code.lower() and q not in nm[0].lower():
            continue
        pv = prev.get(code, py)
        rows.append(dict(code=code, name=nm[0], table=nm[1], value=_num(v), prior=_num(pv),
                         chg=_num((v - pv) / abs(pv)) if pv not in (None, 0) and not np.isnan(pv) else None))
    return dict(period=period, prior=py, subject=subj['name'], rows=rows[:3000], total=len(rows))


def code_search(kind, q, limit=40):
    """Find raw account codes by code or description (for the formula builder)."""
    an = get(kind)
    names = an.store.codes()
    q = q.strip().lower()
    latest = an.store.latest()
    out = []
    for code, (nm, tab) in names.items():
        if q in code.lower() or q in nm.lower():
            if an.store.has(latest, code):
                out.append(dict(code=code, name=nm, table=tab, exact=code.lower() == q))
    out.sort(key=lambda r: (not r['exact'], len(r['name'])))
    return out[:limit]


# --------------------------------------------------------------------------- API: Return of the Member

def rom(req):
    """Return of the Member: Callahan's published method (18 ratios, three groups, percentile-ranked in the
    comparison group). Credit unions only."""
    an = get('cu')
    period = an.req_period(req)
    subj = an.subject(req.get('subject'), period)
    spec, name, note = an.resolve_spec(req.get('spec') or {'preset': 'tier' if subj else 'national'}, subj, period)
    mask = an.peer_mask(spec, period, subj)
    full = mask.copy()
    spos = None
    if subj and not subj['merged']:
        spos = an.pos(period, subj['ids'][0])
        if spos is not None:
            full[spos] = True
    idx = np.flatnonzero(full)
    n = len(idx)
    if n < 3:
        raise ValueError('The comparison group is too small to score.')

    def pct_rank(v, hib):
        """Percentile (0-100, 100 best) of each value among the non-missing ones; missing -> NaN."""
        out = np.full(len(v), np.nan)
        ok = ~np.isnan(v)
        if ok.sum() > 1:
            r = pd.Series(v[ok]).rank(method='average', ascending=hib).to_numpy()
            out[ok] = 100.0 * (r - 1) / (ok.sum() - 1)
        return out

    total = np.zeros(n)
    wsum = np.zeros(n)
    parts = []
    for gname, weight, items in library.ROM:
        comp, detail = [], []
        for label, ftxt, hib in items:
            v = np.asarray(an.formula(ftxt).eval(F.VectorCtx(an.store, period)), dtype=float)[idx]
            v = np.where(np.isinf(v), np.nan, v)
            p = pct_rank(v, hib)
            comp.append(p)
            detail.append((label, v, p, hib, an.base.get(ftxt.strip('{}'), {}).get('fmt', 'pct')))
        score = np.nanmean(np.vstack(comp), axis=0)
        ok = ~np.isnan(score)
        total[ok] += weight * score[ok]
        wsum[ok] += weight
        parts.append((gname, weight, score, detail))
    raw = np.where(wsum > 0, total / np.where(wsum == 0, 1, wsum), np.nan)
    final = pct_rank(raw, True)
    u = an.universe(period)
    ids = an.store.ids(period)
    order = np.argsort(-np.nan_to_num(final, nan=-1))
    leaders = [dict(rank=r + 1, id=ids[idx[j]], name=u['CU_NAME'].iat[idx[j]], state=u['STATE'].iat[idx[j]],
                    assets=_num(u['assets'].iat[idx[j]]), rom=_num(final[j]),
                    parts=[_num(pct_rank(pt[2], True)[j]) for pt in parts],
                    subject=bool(spos is not None and idx[j] == spos)) for r, j in enumerate(order[:int(req.get('limit') or 50)])]
    me = None
    if spos is not None:
        j = int(np.flatnonzero(idx == spos)[0])
        me = dict(rom=_num(final[j]), rank=int((np.nan_to_num(final, nan=-1) > final[j]).sum()) + 1, of=n,
                  groups=[dict(name=g, weight=w, score=_num(pct_rank(sc, True)[j]),
                               items=[dict(label=l, value=_num(v[j]), pct=_num(p[j]), hib=h, fmt=fk,
                                           median=_num(np.nanmedian(v)) if (~np.isnan(v)).any() else None)
                                      for l, v, p, h, fk in det]) for g, w, sc, det in parts])
    return dict(period=period, name=name, note=note, n=int(mask.sum()), subject=subj and subj['name'], me=me,
                leaders=leaders, groups=[g for g, _, _, _ in parts])


# --------------------------------------------------------------------------- API: narrative

def narrative(result):
    """Plain-language read of an analyze() result: where the primary leads, trails, and what moved."""
    if not result.get('subject'):
        return []
    name = result['subject']['name']
    rows = [m for m in result['metrics'] if m.get('latest') and m['latest'].get('pct') is not None and m.get('hib') is not None]
    if not rows:
        return []

    def f(v, fmt):
        if v is None:
            return 'n/a'
        if fmt in ('pct', 'rate'):
            return f'{v * 100:.2f}%'
        if fmt == 'usd':
            return f'${v / 1e9:.2f}B' if abs(v) >= 1e9 else f'${v / 1e6:.1f}M' if abs(v) >= 1e6 else f'${v:,.0f}'
        if fmt == 'x':
            return f'{v:.2f}x'
        return f'{v:,.2f}' if fmt == 'num2' else f'{v:,.0f}'

    g = result['groups'][0]
    out = []
    best = sorted(rows, key=lambda m: -m['latest']['pct'])[:4]
    worst = sorted(rows, key=lambda m: m['latest']['pct'])[:4]
    top = [m for m in best if m['latest']['pct'] >= 67]
    low = [m for m in worst if m['latest']['pct'] <= 33]
    avg_pct = float(np.mean([m['latest']['pct'] for m in rows]))
    out.append(dict(kind='summary', text=(
        f'Across {len(rows)} ranked ratios, {name} sits at the {_ord(avg_pct)} percentile on average against '
        f'{g["n"]} peers ({g["name"]}). It is in the top third on {sum(m["latest"]["pct"] >= 67 for m in rows)} '
        f'and the bottom third on {sum(m["latest"]["pct"] <= 33 for m in rows)}.')))
    for m in top:
        L = m['latest']
        out.append(dict(kind='strength', text=f'{m["label"]}: {f(L["value"], m["fmt"])} vs {f(L["peer"], m["fmt"])} for peers '
                                             f'(rank {L["rank"]} of {L["of"]}, {_ord(L["pct"])} percentile).'))
    for m in low:
        L = m['latest']
        out.append(dict(kind='weakness', text=f'{m["label"]}: {f(L["value"], m["fmt"])} vs {f(L["peer"], m["fmt"])} for peers '
                                             f'(rank {L["rank"]} of {L["of"]}, {_ord(L["pct"])} percentile).'))
    movers = []
    for m in rows:
        L = m['latest']
        if None in (L.get('value'), L.get('value_py'), L.get('peer'), L.get('peer_py')):
            continue
        own, peer = L['value'] - L['value_py'], L['peer'] - L['peer_py']
        gap = (own - peer) * (1 if m['hib'] else -1)
        scale = abs(L['peer']) if m['fmt'] not in ('pct', 'rate') and L['peer'] else 1
        movers.append((gap / scale, m, own, peer))
    movers.sort(key=lambda t: t[0])
    for sign, pick in (('gain', movers[::-1][:2]), ('slip', movers[:2])):
        for score, m, own, peer in pick:
            if (sign == 'gain' and score <= 0) or (sign == 'slip' and score >= 0):
                continue
            unit = (lambda d: f'{d * 100:+.2f} pts') if m['fmt'] in ('pct', 'rate') else (lambda d: ('+' if d >= 0 else '-') + f(abs(d), m['fmt']))
            out.append(dict(kind=sign, text=f'{m["label"]} moved {unit(own)} over the past year while peers moved {unit(peer)}: '
                                            f'{"gaining ground" if sign == "gain" else "losing ground"} on the group.'))
    return out


# --------------------------------------------------------------------------- API: library + saved content

def lib(kind):
    an = get(kind)
    folders = {}
    for key, m in an.all_metrics().items():
        folders.setdefault(m['folder'], []).append(dict(key=key, label=m['label'], fmt=m['fmt'], hib=m.get('hib'),
                                                        formula=m['f'], desc=m.get('desc', ''), since=m.get('since'),
                                                        custom=bool(m.get('custom'))))
    saved = user_load('dashboards').get(an.kind, [])
    return dict(type=an.kind, folders=[dict(name=k, metrics=v) for k, v in folders.items()],
                scorecard=library.SCORECARD[an.kind], dashboards=saved, modes=MODES, default_mode=DEFAULT_MODE[an.kind],
                periods=an.periods(), tiers=[dict(lo=lo, hi=None if hi == float('inf') else hi, label=lab) for lo, hi, lab in an.eng.TIERS],
                cross=[r[1 if an.kind == 'cu' else 2] for r in library.CROSS],
                charters=(wide_store.CU_TYPES if an.kind == 'cu' else wide_store.BKCLASS),
                foms=list(wide_store.TOM_GROUPS) if an.kind == 'cu' else [],
                group_labels=(peer_engine.NCUA_PEER_GROUPS if an.kind == 'cu' else bank_engine.SPECGRP))


def save_formula(kind, item):
    an = get(kind)
    label = (item.get('label') or '').strip()
    ftxt = (item.get('f') or '').strip()
    if not label or not ftxt:
        raise ValueError('A custom formula needs a name and a formula.')
    ok, msg, _ = an.check_formula(ftxt)
    if not ok:
        raise ValueError(msg)
    key = item.get('key') or 'my.' + re.sub(r'[^a-z0-9]+', '_', label.lower()).strip('_')
    if key in an.base:
        key = 'my.' + key
    data = user_load('formulas')
    lst = [c for c in data.get(an.kind, []) if c['key'] != key]
    lst.append(dict(key=key, label=label, f=ftxt, fmt=item.get('fmt') or 'pct', hib=item.get('hib'), desc=item.get('desc', '')))
    data[an.kind] = lst
    user_save('formulas', data)
    return key


def delete_formula(kind, key):
    data = user_load('formulas')
    data[kind] = [c for c in data.get(kind, []) if c['key'] != key]
    user_save('formulas', data)


def saved_list(name, kind):
    return user_load(name).get(kind, [])


def saved_put(name, kind, item):
    if not (item.get('name') or '').strip():
        raise ValueError('Give it a name.')
    data = user_load(name)
    lst = [c for c in data.get(kind, []) if c['name'] != item['name']]
    lst.append(item)
    data[kind] = sorted(lst, key=lambda c: c['name'].lower())
    user_save(name, data)


def saved_delete(name, kind, item_name):
    data = user_load(name)
    data[kind] = [c for c in data.get(kind, []) if c['name'] != item_name]
    user_save(name, data)


def peers_preview(req):
    an = get(req.get('type'))
    period = an.req_period(req)
    subj = an.subject(req.get('subject'), period)
    spec, name, note = an.resolve_spec(req.get('spec') or {}, subj, period)
    mask = an.peer_mask(spec, period, subj)
    a = an.universe(period)['assets'].to_numpy()[mask]
    return dict(name=name, note=note, n=int(mask.sum()), spec=spec, roster=an.roster(period, mask, int(req.get('limit') or 500)),
                total_assets=_num(a.sum()) if len(a) else 0, median_assets=_num(np.median(a)) if len(a) else None)
