"""Peer benchmark report -> Excel + PDF, for credit unions (Callahan Peer-style, NCUA 5300)
or banks (S&P Capital IQ Pro-style, FDIC/FFIEC Call Report).

Examples
  python peer_report.py "LAMPCO"                              # credit union: same state + asset tier
  python peer_report.py "Keesler" --state MS,AL,LA --assets 1B-10B
  python peer_report.py --bank "Renasant"                     # bank: same state + UBPR asset band
  python peer_report.py --bank 6623 --tier                    # national UBPR asset band
  python peer_report.py --bank "LCNB" --state OH,IN,KY --assets 1B-5B
  python peer_report.py --bank 57576 --specialization         # same FDIC specialization group
"""
import argparse
import os
import sys
import re
import textwrap
from xml.sax.saxutils import escape
import tempfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from openpyxl import Workbook  # noqa: E402
from openpyxl.styles import Alignment, Font, PatternFill  # noqa: E402
from openpyxl.utils import get_column_letter  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.pagesizes import letter  # noqa: E402
from reportlab.lib.styles import ParagraphStyle  # noqa: E402
from reportlab.lib.units import inch  # noqa: E402
from reportlab.platypus import (CondPageBreak, Image, Paragraph, SimpleDocTemplate,  # noqa: E402
                                Spacer, Table, TableStyle)
from reportlab.platypus.flowables import Flowable  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bank_engine  # noqa: E402
import brand  # noqa: E402
import peer_engine  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ENGINES = {'cu': peer_engine, 'bank': bank_engine}

# AV's Peer Benchmark brand: midnight navy + champagne gold. RED is the primary (navy); GOLD is the accent.
RED, DARK_RED, AQUA, TEAL = '#14233A', '#9B3B3B', '#B08D57', '#8C6D3F'
GRAY, MID_GRAY, WARM_GRAY = '#535B67', '#8A909A', '#DDD8CE'
GREEN, AMBER = '#3F6E5A', '#C08A2E'
GOLD = '#B08D57'
ROSTER_ROWS = 20   # peer-group rows in the PDF; keeps the roster and Method on one page
BRAND = 'AV’s Peer Benchmark'


# --------------------------------------------------------------------------- formatting

def fmt(v, kind):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return 'n/a'
    if kind == 'pct':
        return f'{v * 100:.2f}%'
    if kind == 'usd':
        if abs(v) >= 1e9:
            return f'${v / 1e9:.2f}B'
        if abs(v) >= 1e6:
            return f'${v / 1e6:.1f}M'
        return f'${v:,.0f}'
    if kind == 'int':
        return f'{v:,.0f}'
    if kind == 'x':
        return f'{v:.2f}x'
    return f'{v:,.0f}'


def polish(name):
    """Last touches on source-cased names: McArthur, CFBank."""
    return re.sub(r'\bMc([a-z])(?=[a-z]{2})', lambda m: 'Mc' + m.group(1).upper(), name).replace('Cfbank', 'CFBank')


def method_paragraphs(lines):
    """Re-flow the hard-wrapped method notes: a line that continues a sentence joins the one before it."""
    out = []
    for raw in lines:
        line, deep = raw.strip(), len(raw) - len(raw.lstrip()) >= 3
        cont = out and (deep or (line[:1].islower() or line[:1] in '(')) and not out[-1].endswith(':')
        if cont:
            out[-1] += ' ' + line
        else:
            out.append(line)
    return out


def period_label(p):
    return f'Q{int(p[5:7]) // 3} {p[:4]}'


def pct_color(p):
    if p is None or np.isnan(p):
        return MID_GRAY
    return GREEN if p >= 67 else (AMBER if p >= 33 else DARK_RED)


def parse_assets(s):
    lo, hi = s.split('-')
    return (peer_engine.parse_money(lo),
            float('inf') if hi.strip() in ('', 'inf') else peer_engine.parse_money(hi))


STATE_NAMES = {
    'AL': 'Alabama', 'AK': 'Alaska', 'AZ': 'Arizona', 'AR': 'Arkansas', 'CA': 'California', 'CO': 'Colorado',
    'CT': 'Connecticut', 'DE': 'Delaware', 'DC': 'District of Columbia', 'FL': 'Florida', 'GA': 'Georgia',
    'HI': 'Hawaii', 'ID': 'Idaho', 'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa', 'KS': 'Kansas',
    'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MD': 'Maryland', 'MA': 'Massachusetts',
    'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi', 'MO': 'Missouri', 'MT': 'Montana',
    'NE': 'Nebraska', 'NV': 'Nevada', 'NH': 'New Hampshire', 'NJ': 'New Jersey', 'NM': 'New Mexico',
    'NY': 'New York', 'NC': 'North Carolina', 'ND': 'North Dakota', 'OH': 'Ohio', 'OK': 'Oklahoma',
    'OR': 'Oregon', 'PA': 'Pennsylvania', 'RI': 'Rhode Island', 'SC': 'South Carolina', 'SD': 'South Dakota',
    'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah', 'VT': 'Vermont', 'VA': 'Virginia', 'WA': 'Washington',
    'WV': 'West Virginia', 'WI': 'Wisconsin', 'WY': 'Wyoming', 'PR': 'Puerto Rico', 'GU': 'Guam',
    'VI': 'U.S. Virgin Islands', 'AS': 'American Samoa', 'MP': 'Northern Mariana Islands',
    'FM': 'Micronesia', 'MH': 'Marshall Islands', 'PW': 'Palau',
}
_BY_NAME = {v.lower(): k for k, v in STATE_NAMES.items()}


def parse_states(text):
    """Accept 'NJ, NY', 'nj ny', 'New Jersey; New York', 'NJ/NY' ... -> ['NJ', 'NY']. Unknown -> clear error."""
    import re
    out, bad = [], []
    for chunk in re.split(r'[,;/|]+', text or ''):
        chunk = chunk.strip().strip('.')
        if not chunk:
            continue
        if chunk.upper() in STATE_NAMES:
            out.append(chunk.upper())
        elif chunk.lower() in _BY_NAME:
            out.append(_BY_NAME[chunk.lower()])
        else:                                   # space-separated: 'NJ NY' or 'new jersey new york'
            words, i, found = chunk.split(), 0, []
            while i < len(words):
                for n in (3, 2, 1):
                    w = ' '.join(words[i:i + n])
                    code = w.upper() if w.upper() in STATE_NAMES else _BY_NAME.get(w.lower())
                    if code:
                        found.append(code)
                        i += n
                        break
                else:
                    bad.append(words[i])
                    i += 1
            out += found
    if bad:
        raise SystemExit(f'Unrecognized state: {", ".join(bad)}. Use two-letter codes (e.g. NJ, NY) or full names.')
    return list(dict.fromkeys(out))


# U.S. Census divisions and regions, used to widen a default peer group step by step.
DIVISIONS = {
    'New England': ['CT', 'ME', 'MA', 'NH', 'RI', 'VT'],
    'Middle Atlantic': ['NJ', 'NY', 'PA'],
    'East North Central': ['IL', 'IN', 'MI', 'OH', 'WI'],
    'West North Central': ['IA', 'KS', 'MN', 'MO', 'NE', 'ND', 'SD'],
    'South Atlantic': ['DE', 'DC', 'FL', 'GA', 'MD', 'NC', 'SC', 'VA', 'WV', 'PR', 'VI'],
    'East South Central': ['AL', 'KY', 'MS', 'TN'],
    'West South Central': ['AR', 'LA', 'OK', 'TX'],
    'Mountain': ['AZ', 'CO', 'ID', 'MT', 'NV', 'NM', 'UT', 'WY'],
    'Pacific': ['AK', 'CA', 'HI', 'OR', 'WA', 'GU', 'AS', 'MP', 'FM', 'MH', 'PW'],
}
REGIONS = {
    'Northeast': ['New England', 'Middle Atlantic'],
    'Midwest': ['East North Central', 'West North Central'],
    'South': ['South Atlantic', 'East South Central', 'West South Central'],
    'West': ['Mountain', 'Pacific'],
}
MIN_DEFAULT_PEERS = 10


def default_peer_steps(state):
    """Geography steps for the default peer group: state, Census division, Census region, national."""
    div = next((d for d, sts in DIVISIONS.items() if state in sts), None)
    steps = [([state], STATE_NAMES.get(state, state))]
    if div:
        steps.append((DIVISIONS[div], f'the {div} states ({", ".join(DIVISIONS[div])})'))
        reg = next(r for r, ds in REGIONS.items() if div in ds)
        steps.append(([st for d in REGIONS[reg] for st in DIVISIONS[d]], f'the {reg} region'))
    steps.append((None, 'the whole country'))
    return steps


# --------------------------------------------------------------------------- excel

def write_excel(eng, path, subj, period, peer_desc, bench, peers, trend_df, note=None):
    wb = Workbook()
    hdr_fill = PatternFill('solid', fgColor=RED[1:])
    white_bold = Font(bold=True, color='FFFFFF')
    name = eng.display_name(subj)

    def header(ws, row, n):
        for c in range(1, n + 1):
            ws.cell(row, c).fill = hdr_fill
            ws.cell(row, c).font = white_bold
            ws.cell(row, c).alignment = Alignment(wrap_text=True, vertical='top')

    ws = wb.active
    ws.title = 'Summary'
    ws['A1'] = name
    ws['A1'].font = Font(bold=True, size=16, color=RED[1:])
    ws['A2'] = f'Peer benchmark, {period_label(period)}: {subj["CITY"]}, {subj["STATE"]}'
    ws['A3'] = f'Peer group: {peer_desc} ({len(peers)} peers)' + (f'. {note}' if note else '')
    ws['A4'] = eng.FOOTNOTE + ' Rank includes the subject.'
    ws['A4'].font = Font(italic=True, color=GRAY[1:])
    cols = ['Section', 'Metric', name, eng.PEER_COL, 'Peer median', 'Rank', 'Of', 'Percentile']
    ws.append([])
    ws.append(cols)
    header(ws, 6, len(cols))
    b = bench.set_index('metric')
    numfmt = {'pct': '0.00%', 'usd': '$#,##0', 'int': '#,##0', 'num': '#,##0', 'x': '0.00"x"'}
    for section, keys in eng.SECTIONS:
        for k in keys:
            r = b.loc[k]
            ws.append([section, r['label'], _xl(r['value']), _xl(r['peer_value']), _xl(r['peer_median']),
                       None if r['rank'] is None or pd.isna(r['rank']) else int(r['rank']),
                       int(r['of']), None if pd.isna(r['percentile']) else r['percentile'] / 100])
            row = ws.max_row
            for c in (3, 4, 5):
                ws.cell(row, c).number_format = numfmt[r['fmt']]
            ws.cell(row, 8).number_format = '0%'
    _widths(ws, [22, 36, 18, 18, 16, 8, 8, 12])

    ws = wb.create_sheet('Trend')
    ws.append(['Quarter', 'Metric', name, eng.PEER_COL])
    header(ws, 1, 4)
    for _, r in trend_df.iterrows():
        ws.append([period_label(r['period']), eng.METRICS[r['metric']][0], _xl(r['value']), _xl(r['peer_value'])])
        ws.cell(ws.max_row, 3).number_format = ws.cell(ws.max_row, 4).number_format = '0.00%'
    _widths(ws, [10, 34, 18, 18])

    ws = wb.create_sheet('Peer roster')
    keys = list(eng.METRICS)
    ws.append([eng.ID_LABEL, eng.INST_WORD, 'City', 'State'] + [eng.METRICS[k][0] for k in keys])
    header(ws, 1, len(keys) + 4)
    roster = pd.concat([peers, pd.DataFrame([subj])]).sort_values('assets', ascending=False)
    for inst, r in roster.iterrows():
        ws.append([int(inst), r['CU_NAME'], r['CITY'], r['STATE']] + [_xl(r[k]) for k in keys])
        for i, k in enumerate(keys):
            ws.cell(ws.max_row, 5 + i).number_format = numfmt[eng.METRICS[k][1]]
        if str(inst) == str(subj.name):
            for c in range(1, len(keys) + 5):
                ws.cell(ws.max_row, c).font = Font(bold=True, color=RED[1:])
    ws.freeze_panes = 'C2'
    _widths(ws, [9, 30, 16, 6] + [14] * len(keys))

    ws = wb.create_sheet('Method')
    for line in eng.METHOD_LINES:
        ws.append([line])
    ws.column_dimensions['A'].width = 130
    brand.brand_workbook(wb)
    wb.save(path)


def _xl(v):
    return None if v is None or (isinstance(v, float) and np.isnan(v)) else float(v)


def _widths(ws, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w


# --------------------------------------------------------------------------- pdf

class PctBar(Flowable):
    def __init__(self, pct, width=1.1 * inch, height=8):
        super().__init__()
        self.pct, self.width, self.height = pct, width, height

    def draw(self):
        c = self.canv
        c.setFillColor(colors.HexColor(WARM_GRAY))
        c.rect(0, 0, self.width, self.height, stroke=0, fill=1)
        if self.pct is not None and not np.isnan(self.pct):
            c.setFillColor(colors.HexColor(pct_color(self.pct)))
            c.rect(0, 0, self.width * max(self.pct, 2) / 100, self.height, stroke=0, fill=1)


def trend_chart(eng, trend_df, short_name, path):
    fig, axes = plt.subplots(2, 3, figsize=(10, 5.2))
    periods = sorted(trend_df['period'].unique())
    x = range(len(periods))
    for ax, key in zip(axes.flat, eng.TREND_KEYS):
        t = trend_df[trend_df['metric'] == key].set_index('period').reindex(periods)
        ax.plot(x, t['value'] * 100, color=RED, lw=2.4, marker='o', ms=3.5, label=short_name)
        ax.plot(x, t['peer_value'] * 100, color=GRAY, lw=1.6, ls='--', label='Peers')
        ax.set_title(eng.METRICS[key][0], fontsize=9.5, color='#222', loc='left', fontweight='bold')
        ax.set_xticks(list(x))
        ax.set_xticklabels([f"Q{int(p[5:7]) // 3}\n'{p[2:4]}" for p in periods], fontsize=7)
        ax.tick_params(axis='y', labelsize=7.5, colors=GRAY)
        ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f'{v:.1f}%'))
        for s in ('top', 'right'):
            ax.spines[s].set_visible(False)
        for s in ('left', 'bottom'):
            ax.spines[s].set_color(WARM_GRAY)
        ax.grid(axis='y', color=WARM_GRAY, lw=0.6)
    axes.flat[0].legend(fontsize=7.5, frameon=False, loc='best')
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def write_pdf(eng, path, subj, period, peer_desc, bench, peers, trend_df, note=None):
    st = {
        'title': ParagraphStyle('t', fontName='Helvetica-Bold', fontSize=22, textColor=colors.HexColor(RED), leading=26),
        'sub': ParagraphStyle('s', fontName='Helvetica', fontSize=11, textColor=colors.HexColor(GRAY), leading=15),
        'h': ParagraphStyle('h', fontName='Helvetica-Bold', fontSize=12, textColor=colors.HexColor(RED),
                            spaceBefore=10, spaceAfter=4, keepWithNext=1),
        'cell': ParagraphStyle('cell', fontName='Helvetica', fontSize=7.3, leading=8.4),
        'th': ParagraphStyle('th', fontName='Helvetica-Bold', fontSize=8, textColor=colors.white, leading=9.5, alignment=2),
        'body': ParagraphStyle('b', fontName='Helvetica', fontSize=8.5, textColor=colors.HexColor('#222222'), leading=11.5),
        'small': ParagraphStyle('sm', fontName='Helvetica', fontSize=7, textColor=colors.HexColor(GRAY), leading=9),
    }
    name = eng.display_name(subj)
    short = name
    doc = SimpleDocTemplate(path, pagesize=letter, leftMargin=0.6 * inch, rightMargin=0.6 * inch,
                            topMargin=0.85 * inch, bottomMargin=0.6 * inch, title=f'{name}: Peer Benchmark')

    def chrome(c, d):
        c.saveState()
        c.setFillColor(colors.HexColor(RED))
        c.rect(0, letter[1] - 0.22 * inch, letter[0], 0.22 * inch, stroke=0, fill=1)
        c.setFillColor(colors.HexColor(GOLD))
        c.rect(0, letter[1] - 0.25 * inch, letter[0], 0.03 * inch, stroke=0, fill=1)
        c.setFont('Times-Italic', 11)
        av = 'AV’s '
        x = letter[0] - 0.6 * inch - c.stringWidth(av, 'Times-Italic', 11) - c.stringWidth('Peer Benchmark', 'Times-Roman', 11)
        c.drawString(x, letter[1] - 0.48 * inch, av)
        c.setFillColor(colors.HexColor(RED))
        c.setFont('Times-Roman', 11)
        c.drawString(x + c.stringWidth(av, 'Times-Italic', 11), letter[1] - 0.48 * inch, 'Peer Benchmark')
        if os.path.exists(brand.LOGO_NAVY):
            c.drawImage(brand.LOGO_NAVY, x - 0.36 * inch, letter[1] - 0.53 * inch, width=0.3 * inch, height=0.26 * inch, mask='auto', preserveAspectRatio=True)
        c.setFont('Helvetica', 7)
        c.setFillColor(colors.HexColor(MID_GRAY))
        c.drawString(0.6 * inch, 0.35 * inch,
                     f'Source: {eng.SOURCE_NOTE}, {period_label(period)}. Prepared with {BRAND}. {eng.METHOD_NOTE}')
        c.drawRightString(letter[0] - 0.6 * inch, 0.35 * inch, f'Page {d.page}')
        c.restoreState()

    story = [Paragraph(name, st['title']),
             Paragraph(f'Peer benchmark, {period_label(period)} &nbsp;·&nbsp; {str(subj["CITY"]).title()}, {subj["STATE"]} '
                       f'&nbsp;·&nbsp; {fmt(subj["assets"], "usd")} in assets', st['sub']),
             Paragraph(f'Compared with <b>{len(peers)}</b> peers: {peer_desc}.', st['sub'])]
    if note:
        story.append(Paragraph(note, ParagraphStyle('note', parent=st['body'], textColor=colors.HexColor(DARK_RED),
                                                     spaceBefore=3)))
    story += [
             Spacer(1, 8)]

    b = bench.dropna(subset=['percentile'])
    b = b[b['metric'] != 'assets']
    top, low = b.nlargest(3, 'percentile'), b.nsmallest(3, 'percentile')
    hl = [[Paragraph('<b>Where it leads its peers</b>', st['body']), Paragraph('<b>Where it trails</b>', st['body'])]]
    for (_, t), (_, l) in zip(top.iterrows(), low.iterrows()):
        hl.append([Paragraph(f'{t["label"]}: {fmt(t["value"], t["fmt"])} vs {fmt(t["peer_value"], t["fmt"])} '
                             f'(rank&nbsp;{int(t["rank"])}&nbsp;of&nbsp;{t["of"]})', st['body']),
                   Paragraph(f'{l["label"]}: {fmt(l["value"], l["fmt"])} vs {fmt(l["peer_value"], l["fmt"])} '
                             f'(rank&nbsp;{int(l["rank"])}&nbsp;of&nbsp;{l["of"]})', st['body'])])
    t = Table(hl, colWidths=[3.65 * inch, 3.65 * inch])
    t.setStyle(TableStyle([('LINEABOVE', (0, 0), (0, 0), 2, colors.HexColor(GREEN)),
                           ('LINEABOVE', (1, 0), (1, 0), 2, colors.HexColor(DARK_RED)),
                           ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 3),
                           ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]))
    story += [t, Spacer(1, 6)]

    bi = bench.set_index('metric')
    rows, style = [['Metric', Paragraph(escape(short), st['th']), eng.PEER_COL, 'Peer median', 'Rank', 'Percentile']], [
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(RED)),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('ALIGN', (1, 0), (4, -1), 'RIGHT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 1.7), ('BOTTOMPADDING', (0, 0), (-1, -1), 1.7),
    ]
    for section, keys in eng.SECTIONS:
        rows.append([section, '', '', '', '', ''])
        i = len(rows) - 1
        style += [('FONTNAME', (0, i), (-1, i), 'Helvetica-Bold'), ('TEXTCOLOR', (0, i), (-1, i), colors.HexColor(TEAL)),
                  ('LINEBELOW', (0, i), (-1, i), 0.5, colors.HexColor(WARM_GRAY))]
        for k in keys:
            r = bi.loc[k]
            rank = '' if r['rank'] is None or pd.isna(r['rank']) else f'{int(r["rank"])} / {r["of"]}'
            rows.append([r['label'], fmt(r['value'], r['fmt']), fmt(r['peer_value'], r['fmt']),
                         fmt(r['peer_median'], r['fmt']), rank, PctBar(r['percentile'])])
            style.append(('FONTNAME', (1, len(rows) - 1), (1, len(rows) - 1), 'Helvetica-Bold'))
    t = Table(rows, colWidths=[2.25 * inch, 1.05 * inch, 1.0 * inch, 1.0 * inch, 0.75 * inch, 1.25 * inch],
              repeatRows=1)
    t.setStyle(TableStyle(style))
    story += [t, Spacer(1, 4),
              Paragraph('Percentile bar: green = top third of the peer group, amber = middle third, dark red = bottom third '
                        '(direction-aware: lower is better for costs, expenses and credit losses; mix ratios with no '
                        'better direction are unranked). ' + eng.FOOTNOTE, st['small'])]

    story.append(CondPageBreak(4.2 * inch))   # trend heading + chart stay together; no half-empty pages
    story.append(Paragraph('Eight-quarter trend vs the same peer group', st['h']))
    with tempfile.TemporaryDirectory() as td:
        png = os.path.join(td, 'trend.png')
        trend_chart(eng, trend_df, short, png)
        story.append(Image(png, width=7.3 * inch, height=7.3 * inch * 5.2 / 10))
        story.append(Spacer(1, 6))

        story.append(Paragraph('Peer group', st['h']))
        if len(roster := peers.sort_values('assets', ascending=False)) > ROSTER_ROWS:
            story += [Paragraph(f'Largest {ROSTER_ROWS} of {len(roster)} peers shown; the full roster is in the Excel workbook.',
                                st['small']), Spacer(1, 4)]
        roster = peers.sort_values('assets', ascending=False)
        prow = [[eng.INST_WORD, 'City, state', 'Assets'] + [c for c, _ in eng.ROSTER_COLS]]
        for _, r in roster.head(ROSTER_ROWS).iterrows():
            prow.append([Paragraph(escape(polish(eng.display_name(r))), st['cell']), f'{polish(str(r["CITY"]).title())[:14]}, {r["STATE"]}',
                         fmt(r['assets'], 'usd')] + [fmt(r[k], eng.METRICS[k][1]) for _, k in eng.ROSTER_COLS])
        t = Table(prow, colWidths=[2.55 * inch, 1.15 * inch, 0.75 * inch, 0.65 * inch, 0.75 * inch, 0.75 * inch, 0.7 * inch],
                  repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(GRAY)),
                               ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                               ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                               ('FONTSIZE', (0, 0), (-1, -1), 7.3), ('ALIGN', (2, 0), (-1, -1), 'RIGHT'),
                               ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F2EFE8')]),
                               ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                               ('TOPPADDING', (0, 0), (-1, -1), 1.6), ('BOTTOMPADDING', (0, 0), (-1, -1), 1.6)]))
        t.setStyle(TableStyle([('TOPPADDING', (0, 1), (0, -1), 0), ('BOTTOMPADDING', (0, 1), (0, -1), 3.2)]))  # name Paragraph sits on the row baseline
        story.append(t)
        story += [Spacer(1, 8), Paragraph('Method', st['h'])]
        story += [Paragraph(escape(line), st['small']) for line in method_paragraphs(eng.METHOD_LINES)]
        doc.build(story, onFirstPage=chrome, onLaterPages=chrome)


# --------------------------------------------------------------------------- cli

def resolve_peers(eng, panel, period, metrics, subject, a):
    """Peer filters from the CLI args (or the widening default), then the benchmark against them."""
    subj = metrics.loc[subject]
    kw = dict(states=parse_states(a.state) or None if a.state else None,
              regions=a.region.split(',') if a.region and not a.bank else None,
              assets=parse_assets(a.assets) if a.assets else None,
              tier=a.tier, ncua_group=a.ncua_group,
              cu_list=a.cu_list.split(',') if a.cu_list else None)
    note = None
    if not any(kw.values()):
        # Default: same asset tier, same state; widen geography step by step until there are enough peers.
        steps = default_peer_steps(subj['STATE'])
        for i, (states, label) in enumerate(steps):
            kw.update(states=states, tier=True)
            n = len(eng.select_peers(metrics, subject, **kw))
            if n >= MIN_DEFAULT_PEERS or i == len(steps) - 1:
                break
        if i:
            home = STATE_NAMES.get(subj['STATE'], subj['STATE'])
            note = (f'{home} has fewer than {MIN_DEFAULT_PEERS} other {eng.INST_WORD.lower()}s in this asset tier, '
                    f'so the peer group was widened to {label}.')
            print(note)
    bench, peers, subj = eng.benchmark(panel, period, subject, kw)
    if len(peers) == 0:
        raise SystemExit(f'The peer definition matched no {eng.INST_WORD.lower()}s.')
    peer_desc = eng.describe_peer(subj, **kw)
    if note and kw.get('states'):   # name the widened geography instead of listing every state code
        peer_desc = peer_desc.replace('/'.join(kw['states']), label[4:] if label.startswith('the ') else label, 1)

    return kw, note, peer_desc, bench, peers, subj


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('inst', help='Charter / FDIC cert number or institution name')
    ap.add_argument('--bank', action='store_true', help='Benchmark a bank (FDIC data) instead of a credit union')
    ap.add_argument('--period', help='YYYY-MM quarter end (default: latest available)')
    ap.add_argument('--state', help='Comma-separated state codes, e.g. IN,OH')
    ap.add_argument('--region', help='Comma-separated NCUA region numbers (credit unions only)')
    ap.add_argument('--assets', help='Asset range, e.g. 250M-1B or 1B-inf')
    ap.add_argument('--tier', action='store_true', help='Same asset tier (CU: Callahan-style; bank: UBPR band)')
    ap.add_argument('--ncua-group', '--specialization', dest='ncua_group', action='store_true',
                    help='CU: same NCUA peer group. Bank: same FDIC specialization group')
    ap.add_argument('--cu-list', '--list', dest='cu_list', help='Comma-separated charter / cert numbers')
    ap.add_argument('--quarters', type=int, default=8, help='Trend length (default 8)')
    ap.add_argument('--out', default=os.path.join(HERE, 'output'))
    a = ap.parse_args(argv)
    eng = ENGINES['bank' if a.bank else 'cu']

    panel = eng.build_panel()
    period = a.period or sorted(panel['period'].unique())[-1]
    metrics = eng.cu_metrics(panel, period)
    subject = eng.find_cu(metrics, a.inst)
    subj = metrics.loc[subject]

    kw, note, peer_desc, bench, peers, subj = resolve_peers(eng, panel, period, metrics, subject, a)

    periods = [p for p in sorted(panel['period'].unique()) if p <= period][-a.quarters:]
    trend_df = eng.trend(panel, subject, list(peers.index), periods, eng.TREND_KEYS)

    os.makedirs(a.out, exist_ok=True)
    base = os.path.join(a.out, f'{eng.display_name(subj)} Peer Benchmark {period_label(period)}')
    write_excel(eng, base + '.xlsx', subj, period, peer_desc, bench, peers, trend_df, note)
    write_pdf(eng, base + '.pdf', subj, period, peer_desc, bench, peers, trend_df, note)
    print(f'{subj["CU_NAME"]} ({subject}) vs {len(peers)} peers: {peer_desc}')
    print(base + '.pdf')
    print(base + '.xlsx')
    return base


if __name__ == '__main__':
    main()
