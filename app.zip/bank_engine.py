"""S&P Capital IQ Pro-style bank peer benchmarking built on public FDIC/FFIEC Call Report data.

Data: FDIC BankFind Suite API (api.fdic.gov/banks/financials), one cached JSON per quarter.
Definitions follow S&P/SNL practice where published, else the FFIEC UBPR / FDIC QBP:
  - Income items     = YTD annualized (x * 4 / quarter number), like UBPR
  - Average balances = FDIC cumulative averages of quarter-ends YTD (ASSET5, EQ5, ERNAST5, LNLSGR5, DEP5);
                       (current + prior December) / 2 where the FDIC publishes no average
  - Efficiency       = FDIC efficiency expense / income (non-interest expense less intangible amortization,
                       over NII + non-interest income; securities gains are outside non-interest income)
  - NPAs             = nonaccrual loans + OREO (S&P "NPAs excl. restructured")
  - Peer value       = UBPR-style trimmed mean (drops below 5th / above 95th percentile), median alongside
"""
import json
import os
import time
import urllib.request
from datetime import date

import numpy as np
import pandas as pd

from peer_engine import _safe, annual_factor, prior_dec, prior_year, parse_money, _money  # noqa: F401

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, 'data', 'fdic')
PANEL_PATH = os.path.join(HERE, 'data', 'bank_panel.pkl')
API = 'https://api.fdic.gov/banks/financials'
FIRST_PERIOD = '2021-03'

KIND = 'bank'
INST_WORD = 'Bank'
ID_LABEL = 'FDIC cert'
PEER_COL = 'Peer avg'
SOURCE_NOTE = 'FDIC/FFIEC Call Report data'
METHOD_NOTE = 'S&P Capital IQ Pro-style definitions.'

INFO_FIELDS = ['CERT', 'REPDTE', 'NAMEFULL', 'CITY', 'STALP', 'RSSDID', 'SPECGRP']
NUM_FIELDS = [
    'ASSET', 'ASSET5', 'ERNAST5', 'EQ', 'EQ5', 'INTAN', 'DEP', 'DEP5', 'DEPDOM', 'COREDEP', 'DEPNI', 'BRO',
    'DEPUNINS', 'NTRSMMDA', 'NTRSOTH', 'NTRCDSMJ', 'NTRTMLGJ', 'OTHBOR', 'LNLSGR', 'LNLSGR5', 'LNATRES',
    'NCLNLS', 'NALNLS', 'ORE', 'NTLNLS', 'INTINC', 'EINTEXP', 'NONII', 'NONIX', 'NETINC', 'EEFF', 'IEFF',
    'EDEP', 'ESAVDP', 'EOTHTIME', 'ECD100', 'RBC1AAJ', 'RBCRWAJ', 'RBCT1CER', 'NUMEMP', 'OFFDOM',
    'DEPSMB',   # number of deposit accounts of $250K or less (RC-O memo; used by the opportunity score)
    # FDIC's own published ratios, kept for validation
    'ROA', 'ROE', 'NIMY', 'EEFFR',
]
DOLLAR_FIELDS = [f for f in NUM_FIELDS if f not in
                 ('RBC1AAJ', 'RBCRWAJ', 'RBCT1CER', 'NUMEMP', 'OFFDOM', 'DEPSMB', 'ROA', 'ROE', 'NIMY', 'EEFFR')]

# UBPR asset-size peer bands (2026 redesign).
TIERS = [(0, 50e6, '< $50M'), (50e6, 100e6, '$50M-$100M'), (100e6, 300e6, '$100M-$300M'),
         (300e6, 1e9, '$300M-$1B'), (1e9, 3e9, '$1B-$3B'), (3e9, 10e9, '$3B-$10B'),
         (10e9, 100e9, '$10B-$100B'), (100e9, float('inf'), '> $100B')]


# --------------------------------------------------------------------------- data

def _quarters(start, end):
    y, m = map(int, start.split('-'))
    out = []
    while f'{y:04d}-{m:02d}' <= end:
        out.append(f'{y:04d}-{m:02d}')
        m += 3
        if m > 12:
            y, m = y + 1, 3
    return out


def _fetch(period):
    repdte = period.replace('-', '') + ('31' if period[5:] in ('03', '12') else '30')
    fields = ','.join(INFO_FIELDS + NUM_FIELDS)
    url = f'{API}?filters=REPDTE:{repdte}&fields={fields}&limit=10000&format=json'
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=120) as r:
                payload = json.load(r)
            return [row['data'] for row in payload.get('data', [])]
        except Exception:
            if attempt == 2:
                raise
            time.sleep(2 * (attempt + 1))


def _has_fields(path):
    """True when a cached quarter was pulled with every field the metrics now need."""
    with open(path) as f:
        rows = json.load(f)
    keys = set().union(*(r.keys() for r in rows[:200])) if rows else set()
    return set(NUM_FIELDS) <= keys


def refresh_cache(verbose=True):
    """Download any quarter not yet cached (and re-pull the latest two, which banks can amend)."""
    os.makedirs(CACHE, exist_ok=True)
    today = date.today()
    last = f'{today.year:04d}-{((today.month - 1) // 3) * 3 or 12:02d}'
    if last.endswith('-12') and today.month <= 3:
        last = f'{today.year - 1:04d}-12'
    cached = sorted(f[:7] for f in os.listdir(CACHE) if f.endswith('.json'))
    recent = set(cached[-2:])
    changed = False
    for p in _quarters(FIRST_PERIOD, last):
        path = os.path.join(CACHE, f'{p}.json')
        if os.path.exists(path) and p not in recent and _has_fields(path):
            continue
        rows = _fetch(p)
        if not rows:            # not published yet
            continue
        with open(path, 'w') as f:
            json.dump(rows, f)
        changed = True
        if verbose:
            print(f'  FDIC {p}: {len(rows)} banks', flush=True)
    return changed


def build_panel(force=False, refresh=False):
    # A field added to NUM_FIELDS means older cached quarters must be re-pulled (checked only when the
    # cached panel lacks it, so the usual path stays fast).
    if not refresh and not os.path.isdir(CACHE) and os.path.exists(PANEL_PATH):
        return pd.read_pickle(PANEL_PATH)    # packaged build (website): the panel ships without the FDIC cache
    stale = (os.path.exists(PANEL_PATH) and not set(NUM_FIELDS) <= set(pd.read_pickle(PANEL_PATH).columns)
             and any(not _has_fields(os.path.join(CACHE, f)) for f in os.listdir(CACHE) if f.endswith('.json')))
    if refresh or stale or not os.path.isdir(CACHE) or not os.listdir(CACHE):
        force = refresh_cache() or force
    if not force and os.path.exists(PANEL_PATH):
        cached = pd.read_pickle(PANEL_PATH)
        files = {f[:7] for f in os.listdir(CACHE) if f.endswith('.json')}
        if set(cached['period'].unique()) == files and set(NUM_FIELDS) <= set(cached.columns):
            return cached
    frames = []
    for f in sorted(os.listdir(CACHE)):
        if not f.endswith('.json'):
            continue
        with open(os.path.join(CACHE, f)) as fh:
            df = pd.DataFrame(json.load(fh))
        df['period'] = f[:7]
        frames.append(df)
    panel = pd.concat(frames, ignore_index=True)
    for c in NUM_FIELDS:
        panel[c] = pd.to_numeric(panel.get(c), errors='coerce')
    panel[DOLLAR_FIELDS] = panel[DOLLAR_FIELDS] * 1000          # FDIC reports $ thousands
    panel['CU_NUMBER'] = panel['CERT'].astype(int).astype(str)  # shared id column name with the CU engine
    panel = panel.rename(columns={'NAMEFULL': 'CU_NAME', 'STALP': 'STATE'})
    panel['CU_NAME'] = panel['CU_NAME'].str.strip()
    panel['Peer_Group'] = panel['SPECGRP'].astype(str)
    panel['REGION'] = ''
    os.makedirs(os.path.dirname(PANEL_PATH), exist_ok=True)
    panel.to_pickle(PANEL_PATH)
    return panel


# --------------------------------------------------------------------------- metrics

def _avg2(c, d, col):
    return (c[col] + d[col].fillna(c[col])) / 2


def _pct(field):
    return lambda c, p, d, k: np.where(c[field] > 0, c[field] / 100, np.nan)


# name -> (label, format, higher_is_better, fn(cur, py, dec, ann))
METRICS = {
    'assets':          ('Total assets', 'usd', True, lambda c, p, d, k: c['ASSET']),
    'asset_growth':    ('Asset growth (YoY)', 'pct', True, lambda c, p, d, k: _safe(c['ASSET'] - p['ASSET'], p['ASSET'])),
    'loan_growth':     ('Loan growth (YoY)', 'pct', True, lambda c, p, d, k: _safe(c['LNLSGR'] - p['LNLSGR'], p['LNLSGR'])),
    'deposit_growth':  ('Deposit growth (YoY)', 'pct', True, lambda c, p, d, k: _safe(c['DEP'] - p['DEP'], p['DEP'])),
    'roaa':            ('ROAA', 'pct', True, lambda c, p, d, k: _safe(c['NETINC'] * k, c['ASSET5'])),
    'roae':            ('ROAE', 'pct', True, lambda c, p, d, k: _safe(c['NETINC'] * k, c['EQ5'])),
    'nim':             ('Net interest margin', 'pct', True,
                        lambda c, p, d, k: _safe((c['INTINC'] - c['EINTEXP']) * k, c['ERNAST5'])),
    'yield_ea':        ('Yield on earning assets', 'pct', True, lambda c, p, d, k: _safe(c['INTINC'] * k, c['ERNAST5'])),
    'cost_funding':    ('Cost of funding earning assets', 'pct', False,
                        lambda c, p, d, k: _safe(c['EINTEXP'] * k, c['ERNAST5'])),
    'nonint_income':   ('Non-interest income / avg assets', 'pct', True, lambda c, p, d, k: _safe(c['NONII'] * k, c['ASSET5'])),
    'nonint_expense':  ('Non-interest expense / avg assets', 'pct', False, lambda c, p, d, k: _safe(c['NONIX'] * k, c['ASSET5'])),
    'efficiency':      ('Efficiency ratio', 'pct', False, lambda c, p, d, k: _safe(c['EEFF'], c['IEFF'])),
    'tce_ta':          ('Tangible equity / tangible assets', 'pct', True,
                        lambda c, p, d, k: _safe(c['EQ'] - c['INTAN'].fillna(0), c['ASSET'] - c['INTAN'].fillna(0))),
    'leverage':        ('Tier 1 leverage ratio', 'pct', True, _pct('RBC1AAJ')),
    'cet1':            ('CET1 ratio', 'pct', True, _pct('RBCT1CER')),
    'total_rbc':       ('Total risk-based capital ratio', 'pct', True, _pct('RBCRWAJ')),
    'loans_deposits':  ('Loans / deposits', 'pct', None, lambda c, p, d, k: _safe(c['LNLSGR'], c['DEP'])),
    'npa_assets':      ('NPAs / assets', 'pct', False,
                        lambda c, p, d, k: _safe(c['NALNLS'].fillna(0) + c['ORE'].fillna(0), c['ASSET'])),
    'noncurrent':      ('Noncurrent loans / loans', 'pct', False, lambda c, p, d, k: _safe(c['NCLNLS'], c['LNLSGR'])),
    'reserves_loans':  ('Reserves / loans', 'pct', None, lambda c, p, d, k: _safe(c['LNATRES'], c['LNLSGR'])),
    'nco':             ('Net charge-offs / avg loans', 'pct', False, lambda c, p, d, k: _safe(c['NTLNLS'] * k, c['LNLSGR5'])),
    'texas':           ('Texas ratio', 'pct', False,
                        lambda c, p, d, k: _safe(c['NCLNLS'].fillna(0) + c['ORE'].fillna(0),
                                                 c['EQ'] - c['INTAN'].fillna(0) + c['LNATRES'].fillna(0))),
    'nib_share':       ('Noninterest-bearing / deposits', 'pct', True, lambda c, p, d, k: _safe(c['DEPNI'], c['DEP'])),
    'mmda_share':      ('Money market / deposits', 'pct', None, lambda c, p, d, k: _safe(c['NTRSMMDA'], c['DEP'])),
    'savings_share':   ('Other savings / deposits', 'pct', None, lambda c, p, d, k: _safe(c['NTRSOTH'], c['DEP'])),
    'time_small_share': ('Time deposits <= $250K / deposits', 'pct', None, lambda c, p, d, k: _safe(c['NTRCDSMJ'], c['DEP'])),
    'time_large_share': ('Time deposits > $250K / deposits', 'pct', None, lambda c, p, d, k: _safe(c['NTRTMLGJ'], c['DEP'])),
    'core_share':      ('Core deposits / deposits', 'pct', True, lambda c, p, d, k: _safe(c['COREDEP'], c['DEP'])),
    'brokered_share':  ('Brokered / deposits', 'pct', False, lambda c, p, d, k: _safe(c['BRO'], c['DEP'])),
    'uninsured_share': ('Uninsured / domestic deposits*', 'pct', None,
                        lambda c, p, d, k: _safe(c['DEPUNINS'], c['DEPDOM'])),
    'borrowings_assets': ('Other borrowings / assets', 'pct', None, lambda c, p, d, k: _safe(c['OTHBOR'], c['ASSET'])),
    'cost_deposits':   ('Cost of total deposits', 'pct', False, lambda c, p, d, k: _safe(c['EDEP'] * k, c['DEP5'])),
    'cost_ib_deposits': ('Cost of interest-bearing deposits', 'pct', False,
                         lambda c, p, d, k: _safe(c['EDEP'] * k, ((c['DEP'] - c['DEPNI']) + (d['DEP'] - d['DEPNI']).fillna(c['DEP'] - c['DEPNI'])) / 2)),
    'cost_savings_mmda': ('Cost of savings & MMDA', 'pct', False,
                          lambda c, p, d, k: _safe(c['ESAVDP'] * k, ((c['NTRSMMDA'] + c['NTRSOTH']) + (d['NTRSMMDA'] + d['NTRSOTH']).fillna(c['NTRSMMDA'] + c['NTRSOTH'])) / 2)),
    'cost_cd_small':   ('Cost of CDs <= $250K', 'pct', False, lambda c, p, d, k: _safe(c['EOTHTIME'] * k, _avg2(c, d, 'NTRCDSMJ'))),
    'cost_cd_large':   ('Cost of CDs > $250K', 'pct', False, lambda c, p, d, k: _safe(c['ECD100'] * k, _avg2(c, d, 'NTRTMLGJ'))),
    'employees':       ('Full-time equivalent employees', 'int', None, lambda c, p, d, k: c['NUMEMP']),
    'offices':         ('Domestic offices', 'int', None, lambda c, p, d, k: c['OFFDOM']),
    'assets_per_emp':  ('Assets per employee', 'usd', True, lambda c, p, d, k: _safe(c['ASSET'], c['NUMEMP'])),
    'deposits_per_office': ('Deposits per office', 'usd', True, lambda c, p, d, k: _safe(c['DEP'], c['OFFDOM'])),
}

SECTIONS = [
    ('Financial highlights', ['roaa', 'roae', 'nim', 'efficiency', 'nonint_income', 'nonint_expense']),
    ('Growth', ['asset_growth', 'loan_growth', 'deposit_growth']),
    ('Capital', ['tce_ta', 'leverage', 'cet1', 'total_rbc']),
    ('Asset quality', ['npa_assets', 'noncurrent', 'reserves_loans', 'nco', 'texas']),
    ('Deposit profile', ['loans_deposits', 'nib_share', 'mmda_share', 'savings_share', 'time_small_share',
                         'time_large_share', 'core_share', 'brokered_share', 'uninsured_share', 'borrowings_assets']),
    ('Cost of funds', ['yield_ea', 'cost_funding', 'cost_deposits', 'cost_ib_deposits', 'cost_savings_mmda',
                       'cost_cd_small', 'cost_cd_large']),
    ('Scale & productivity', ['employees', 'offices', 'assets_per_emp', 'deposits_per_office']),
]
TREND_KEYS = ['roaa', 'nim', 'efficiency', 'cost_deposits', 'deposit_growth', 'nib_share']
ROSTER_COLS = [('ROAA', 'roaa'), ('NIM', 'nim'), ('Efficiency', 'efficiency'), ('Cost of dep.', 'cost_deposits')]
FOOTNOTE = ('Peer avg = UBPR-style trimmed mean of peer ratios (drops values below the 5th and above the 95th '
            'percentile). * Uninsured deposits are estimated by banks filing the 031/041 forms; small 051 filers '
            'report none. NIM and efficiency are not tax-equivalent adjusted.')
METHOD_LINES = [
    'Source: FDIC BankFind Suite API (FFIEC Call Report data as processed by the FDIC). FDIC field names in brackets.',
    'Definitions follow S&P Capital IQ Pro (SNL) practice where published, otherwise the FFIEC UBPR / FDIC QBP:',
    '  Income items: year-to-date x 4 / quarter number. Averages: FDIC cumulative average of quarter-end balances',
    '  (prior December through the current quarter: [ASSET5], [EQ5], [ERNAST5], [LNLSGR5], [DEP5]);',
    '  (current + prior December) / 2 where no FDIC average exists. Growth: year over year vs the same quarter.',
    '  Peer value: trimmed mean of each peer ratio, 5th-95th percentile (UBPR); peer median shown alongside.',
    'Definitions:',
    '  ROAA = annualized net income [NETINC] / avg assets; ROAE = annualized net income / avg equity [EQ5]',
    '  NIM = annualized (interest income [INTINC] - interest expense [EINTEXP]) / avg earning assets [ERNAST5]',
    '  Efficiency = non-interest expense less intangible amortization [EEFF] / (NII + non-interest income) [IEFF]',
    '     (securities gains are excluded because the Call Report keeps them outside non-interest income)',
    '  Tangible equity / tangible assets = (equity [EQ] - intangibles [INTAN]) / (assets [ASSET] - intangibles)',
    '  Capital ratios as reported: leverage [RBC1AAJ], CET1 [RBCT1CER], total risk-based [RBCRWAJ]',
    '     (community bank leverage ratio filers report no risk-based ratios)',
    '  NPAs / assets = (nonaccrual loans [NALNLS] + OREO [ORE]) / assets (S&P "NPAs excl. restructured")',
    '  Noncurrent loans [NCLNLS] / gross loans [LNLSGR]; Reserves [LNATRES] / gross loans',
    '  Net charge-offs = annualized [NTLNLS] / avg loans [LNLSGR5]',
    '  Texas ratio = (noncurrent loans + OREO) / (tangible equity + reserves)',
    '  Deposit mix: [DEPNI], [NTRSMMDA], [NTRSOTH], time <= $250K [NTRCDSMJ], > $250K [NTRTMLGJ], core [COREDEP],',
    '     brokered [BRO], each / total deposits [DEP]; uninsured [DEPUNINS] / domestic deposits [DEPDOM]',
    '  Cost of deposits = annualized deposit interest [EDEP] / avg deposits [DEP5]; by type: savings & MMDA [ESAVDP],',
    '     CDs <= $250K [EOTHTIME], CDs > $250K [ECD100] over the average of current and prior-December balances',
    'Peers exclude institutions that report no earnings (e.g. U.S. branches of foreign banks).',
    'Validation: balances, income, Tier 1 leverage and loans/deposits tie to FedFis Bank Reports for 20 banks;',
    '     ROAA, NIM and efficiency match the FDIC published ratios for every bank. Average-balance ratios differ from',
    '     FedFis/UBPR by ~1-3% because UBPR uses Schedule RC-K daily averages, which the FDIC API does not publish.',
]


def cu_metrics(panel, period):
    cur, py, dec = _frames(panel, period)
    k = annual_factor(period)
    out = pd.DataFrame(index=cur.index)
    for key, (_, _, _, fn) in METRICS.items():
        out[key] = np.asarray(fn(cur, py, dec, k), dtype=float)
    info = panel[panel['period'] == period].set_index('CU_NUMBER')[['CU_NAME', 'CITY', 'STATE', 'Peer_Group', 'REGION']]
    return info.join(out)


def _frames(panel, period, index=None):
    def get(p):
        f = panel[panel['period'] == p].set_index('CU_NUMBER')[NUM_FIELDS]
        f = f[~f.index.duplicated()]
        return f.reindex(index) if index is not None else f
    cur = get(period)
    idx = cur.index if index is None else index
    return cur, get(prior_year(period)).reindex(idx), get(prior_dec(period)).reindex(idx)


def trimmed_mean(s):
    s = pd.Series(s, dtype=float).dropna()
    if len(s) >= 20:
        lo, hi = s.quantile(0.05), s.quantile(0.95)
        s = s[(s >= lo) & (s <= hi)]
    return float(s.mean()) if len(s) else np.nan


def peer_values(metrics_df, members):
    m = metrics_df.loc[metrics_df.index.intersection(members)]
    return {k: trimmed_mean(m[k]) for k in METRICS}


# --------------------------------------------------------------------------- peers

def tier_of(assets):
    for lo, hi, label in TIERS:
        if lo <= assets < hi:
            return label
    return None


def select_peers(metrics, subject, states=None, assets=None, tier=False, ncua_group=False,
                 cu_list=None, regions=None):
    # Peers must report earnings (drops U.S. branches of foreign banks and non-filers).
    m = metrics.dropna(subset=['assets', 'roaa'])
    if cu_list:
        m = m[m.index.isin([str(x).strip() for x in cu_list])]
    if states:
        m = m[m['STATE'].isin([s.strip().upper() for s in states])]
    if assets:
        lo, hi = assets
        m = m[(m['assets'] >= lo) & (m['assets'] < hi)]
    subj = metrics.loc[subject]
    if tier:
        label = tier_of(subj['assets'])
        lo, hi = next((a, b) for a, b, l in TIERS if l == label)
        m = m[(m['assets'] >= lo) & (m['assets'] < hi)]
    if ncua_group:   # for banks: same FDIC asset-concentration specialization group
        m = m[m['Peer_Group'] == subj['Peer_Group']]
    return m.drop(index=subject, errors='ignore')


SPECGRP = {'1': 'International', '2': 'Agricultural', '3': 'Credit card', '4': 'Commercial lending',
           '5': 'Mortgage lending', '6': 'Consumer lending', '7': 'Other specialized <$1B',
           '8': 'All other <$1B', '9': 'All other >$1B'}


def describe_peer(subj_row, states=None, assets=None, tier=False, ncua_group=False, cu_list=None, regions=None):
    parts = []
    if cu_list:
        parts.append('custom list')
    if states:
        parts.append('/'.join(s.strip().upper() for s in states))
    if assets:
        lo, hi = assets
        parts.append(f'{_money(lo)}-{_money(hi)} assets' if hi != float('inf') else f'> {_money(lo)} assets')
    if tier:
        parts.append(f'{tier_of(subj_row["assets"])} asset band')
    if ncua_group:
        parts.append(f'FDIC {SPECGRP.get(str(subj_row["Peer_Group"]), "?").lower()} specialization')
    if not parts:
        parts.append('all U.S. FDIC-insured')
    return ', '.join(parts) + ' banks'


def find_cu(metrics, query):
    q = str(query).strip()
    if q in metrics.index:
        return q
    hits = metrics[metrics['CU_NAME'].str.contains(q, case=False, na=False, regex=False)]
    if len(hits) == 1:
        return hits.index[0]
    exact = hits[hits['CU_NAME'].str.upper() == q.upper()]
    if len(exact) == 1:
        return exact.index[0]
    if hits.empty:
        raise SystemExit(f'No bank matches "{q}".')
    listing = '\n'.join(f'  {i}  {r.CU_NAME} ({r.CITY}, {r.STATE})' for i, r in hits.head(20).iterrows())
    raise SystemExit(f'"{q}" matches {len(hits)} banks; pass the FDIC cert number:\n{listing}')


def display_name(subj):
    # Title-case, but keep vowel-less abbreviations (LCNB, FSB, N.A.) in capitals.
    out = []
    for i, w in enumerate(str(subj['CU_NAME']).split()):
        if i and w.lower() in ('of', 'and', 'the', 'in'):
            out.append(w.lower())
        elif w.upper() in ('ST.', 'MT.', 'FT.'):
            out.append(w.title())
        elif not any(ch in 'AEIOUY' for ch in w.upper()):
            out.append(w)
        else:
            out.append(w.title().replace("'S", "'s"))
    return ' '.join(out)


# --------------------------------------------------------------------------- benchmark

def benchmark(panel, period, subject, peer_kwargs):
    metrics = cu_metrics(panel, period)
    peers = select_peers(metrics, subject, **peer_kwargs)
    pv = peer_values(metrics, peers.index)
    group = pd.concat([peers, metrics.loc[[subject]]])
    rows = []
    for key, (label, fmt, hib, _) in METRICS.items():
        v = metrics.at[subject, key]
        col = group[key].dropna()
        rank = pct = None
        if hib is not None and not np.isnan(v) and len(col):
            rank = int((col > v).sum() if hib else (col < v).sum()) + 1
            worse = (col < v).sum() if hib else (col > v).sum()
            pct = 100.0 * worse / max(len(col) - 1, 1)
        rows.append({'metric': key, 'label': label, 'fmt': fmt, 'higher_is_better': hib,
                     'value': v, 'peer_value': pv[key], 'peer_median': peers[key].median(),
                     'rank': rank, 'of': len(col), 'percentile': pct})
    return pd.DataFrame(rows), peers, metrics.loc[subject]


def trend(panel, subject, peer_ids, periods, keys):
    out = []
    for p in periods:
        m = cu_metrics(panel, p)
        if subject not in m.index:
            continue
        pv = peer_values(m, peer_ids)
        for k in keys:
            out.append({'period': p, 'metric': k, 'value': m.at[subject, k], 'peer_value': pv[k]})
    return pd.DataFrame(out)
